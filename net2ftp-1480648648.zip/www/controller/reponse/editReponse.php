<?php
include_once "../../config/db.php";

$id_reponse = $_POST["id_reponse"];
$valeur_reponse = $_POST["valeur_reponse"];


$statment = $db->prepare("update opora2016.reponse set texte =:valeur_reponse
						 where id_reponse=:id_reponse");
$statment->bindValue(":id_reponse", $id_reponse);
$statment->bindValue(":valeur_reponse", $valeur_reponse);
$statment->execute();

echo json_encode(true);



