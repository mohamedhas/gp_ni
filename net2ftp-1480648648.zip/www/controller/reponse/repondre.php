<?php

include_once "../../config/db.php";
include_once "../joueur/addXP.php";

$valeur_reponse = $_POST["valeur_reponse"];
$id_question = $_POST["id_question"];
$id_facebook = $_POST["id_facebook"];

if($valeur_reponse != "") {
	
	$rep = $db->prepare("insert into opora2016.reponse (texte, id_question, id_facebook) values (:valeur_reponse, :id_question, :id_facebook)");
	$rep->bindValue(":valeur_reponse", $valeur_reponse);
	$rep->bindValue(":id_question", $id_question);
	$rep->bindValue(":id_facebook", $id_facebook);
	$rep->execute();
	
	addXP($id_facebook);
}

echo json_encode(true);