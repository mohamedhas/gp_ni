<?php
session_start();
include_once "../../config/db.php";


if (isset($_POST["id_reponse"]) && isset($_POST["id_facebook"])) {

	$id_reponse = $_POST["id_reponse"];
	$id_facebook = $_POST["id_facebook"];


	$statment = $db->prepare("insert into opora.reponse_abusive(id_reponse, id_facebook)
								values (:idrep, :idface)");
	$statment->bindValue(":idrep", $id_reponse);
	$statment->bindValue(":idface", $id_facebook);
	$statment->execute();
	
	//-----------------------------------------
	//-----------------------------------------
	//2016
	
	$statment = $db->prepare("update opora2016.reponse set id_facebook_declare_abusive = :idface
								where id_reponse = :idrep");
	$statment->bindValue(":idrep", $id_reponse);
	$statment->bindValue(":idface", $id_facebook);
	$statment->execute();


	echo json_encode(true);

}
else 
	echo json_encode(false);


