<?php 
session_start();
include_once "../../config/db.php";
$id_facebook = $_POST["id_facebook"];
$id_reponse = $_POST["id_reponse"];
$id_voteur = $_POST['id_voteur'];

$str = $db->prepare("select * from a_vote_pour_reponse where id_facebook =:id_facebook and id_reponse = :id_reponse");
$str->bindValue(":id_facebook",$id_facebook);
$str->bindValue(":id_reponse",$id_reponse);
$str->execute();
$rows = $str->fetchAll();
if(count($rows) < 0 ){
	echo json_encode(true);
}
else{
	echo json_encode(false);
}