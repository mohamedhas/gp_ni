<?php 

include_once "../../config/db.php";
$id_question = $_POST["id_question"];

	//Verifier requete
	
	$str = $db->prepare("select *
	from opora2016.reponse r
		join opora2016.internaute i on r.id_facebook = i.id_facebook
		join opora2016.titre t on t.id_titre=i.id_titre
		join opora2016.niveau n on i.num_niveau = n.num_niveau
		where id_question = :id_question
		order by r.id_reponse");

	$str->bindValue(":id_question",$id_question);
	$str->execute();

echo json_encode($str->fetchAll());


