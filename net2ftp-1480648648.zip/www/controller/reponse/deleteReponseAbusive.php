<?php
session_start();
include_once "../../config/db.php";
include_once "../joueur/looseXP.php";
include_once "../joueur/loosePointPlayer.php";

$id_reponse = $_POST["id_reponse"];

$rep = $db->prepare("select r.id_facebook, count(avpr.id_facebook) \"votes\" from opora2016.reponse r 
					left join opora2016.a_vote_pour_reponse avpr on avpr.id_reponse = r.id_reponse 
					where r.id_reponse=:reponse group by r.id_facebook");
$rep->bindValue(":reponse", $id_reponse);
$rep->execute();
$row = $rep->fetch(PDO::FETCH_ASSOC);
$idfb = $row['id_facebook'];
$nbVotes = $row['votes'];

for($i = 0; $i <= $nbVotes; $i++){	//Supprime les points des votes, + ceux de la reponse
	looseXP($idfb);
	loosePointPlayer($idfb);
}
$statment = $db->prepare("delete from opora2016.a_vote_pour_reponse
						  where id_reponse=:id");
$statment->bindValue(":id", $id_reponse);
$statment->execute();

$statment = $db->prepare("delete from opora2016.reponse
						  where id_reponse=:id");
$statment->bindValue(":id", $id_reponse);
$statment->execute();


echo json_encode(true);