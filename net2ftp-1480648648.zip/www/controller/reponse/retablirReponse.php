<?php
session_start();
include_once "../../config/db.php";
$id_reponse = $_POST["id_reponse"];

//----------------------------------------
//----------------------------------------
//2016
//Renommer en retablirReponseAbusive.php

$statment = $db->prepare("update opora2016.reponse set id_facebook_declare_abusive = null
						  where id_reponse=:id");
$statment->bindValue(":id", $id_reponse);
$statment->execute();

