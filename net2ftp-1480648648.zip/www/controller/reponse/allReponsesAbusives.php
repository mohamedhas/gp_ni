<?php 
session_start();
include_once "../../config/db.php";

	
	$str = $db->prepare("
		select * from opora2016.reponse r
		join opora2016.internaute i on r.id_facebook = i.id_facebook
		where id_facebook_declare_abusive is not null
		order by id_reponse");

	$str->execute();

echo json_encode($str->fetchAll());


