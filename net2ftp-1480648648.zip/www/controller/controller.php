<?php
//Inclusion des controllers



// On importe bien le SDK Facebook
require 'lib/src/facebook.php';
// Vous devez impérativement créer une instance d'application en y
// paramétrant votre AppID et votre clé secrète disponible
// dans le tableau de bord de votre application
$facebook = new Facebook(array(
  'appId'  => '1716554568577064',
  'secret' => '7077647d6c17770bdf0ae2a75dde91cf'
));
$loginUrl = $facebook->getLoginUrl(array(
	'display' => 'popup',
    'redirect_uri' => 'https://apps.facebook.com/opora-univ/index.php',
	'scope'     => ''
  ));
// On essaye ensuite de récupérer l'utilisateur identifié au moyen de
// la méthode getUser()
$user = $facebook->getUser();
// Si l'objet $user est défini, cela veut dire que l'utilisateur est
// bien identifié sur facebook, reste à déterminer s'il est identifié
// sur notre application
if ($user) {
  try {
    // On va tenter de récupérer les données de l'utilisateur au moyen
    // de la méthode api()
    // Les données publiques
    $user_profile = $facebook->api('/me');
    // La photo de profil
    $user_picture = $facebook->api('/me/picture?redirect=false&height=128&type=normal&width=128');
    // La photo de couverture
    $user_cover = $facebook->api('/me?fields=cover');
  } catch (FacebookApiException $e) {
    // Si l'utilisateur n'est pas authentifié sur notre application,
    // une exception est remontée.
    error_log($e);
    $user = null;
  }
}
else {
	echo "<script>window.top.location = \"".$loginUrl."\";</script>";
	//header('location:'. $loginUrl);
}
// En fonction du statut de connexion de l'utilisateur, on récupère
// une URL de connexion ou de déconnexion
if ($user) {
  // On passe en paramètre l'URL absolue de la page vers laquelle
  // l'utilisateur est redirigé après déconnexion, arbitrairement
  // l'accueil de Facebook
  $logoutUrl = $facebook->getLogoutUrl(array(
    'next' => 'https://www.facebook.com'
  ));
} else {
  // On passe en paramètre l'URL absolue de la page vers laquelle
  // l'utilisateur est redirigé après connexion, ici notre app
  $loginUrl = $facebook->getLoginUrl(array(
	'display' => 'popup',
    'redirect_uri' => 'https://opora-univ.com/index.php'
  ));
}
?>

<script>
var idfacebook;
var connect;
  window.fbAsyncInit = function() {
    FB.init({
      appId      : '1716554568577064',
      xfbml      : true,
      version    : 'v2.4'
    });

  function onLogin(response) {
  if (response.status == 'connected') {
	  $('#bg').remove();
	  $('#btn-connexion').remove();
    FB.api('/me', function(data) {
      console.log(data);
      var identite = data.name;
	  idfacebook = data.id;
      infos = identite.split(" ");
      verifExistence(infos[1], infos[0]);
	  init();
    });
  }
}

connect = function(){FB.getLoginStatus(function(response) {
	  // Check login status on load, and if the user is
	  // already logged in, go directly to the welcome message.
	 console.log(response.status);
	  if (response.status == 'connected') {
		onLogin(response);
	  } else {
		// Otherwise, show Login dialog first.
		// var coButton = $('#btn-connexion');
		// $('body').append(coButton);
		// coButton.click(function(){
			// coButton.remove();
			// $('#btn-connexion').click();
			// FB.login(function(response) {
			  // onLogin(response);
			// }, { auth_type : 'reauthenticate', scope: 'user_friends'});
		// });
	  }
	});
}
connect();

  };
  
/*
  (function(d, s, id){
     var js, fjs = d.getElementsByTagName(s)[0];
     if (d.getElementById(id)) {return;}
     js = d.createElement(s); js.id = id;
     js.src = "//connect.facebook.net/en_US/sdk.js";
     fjs.parentNode.insertBefore(js, fjs);
   }(document, 'script', 'facebook-jssdk'));
   */
   
</script>
<div id="fb-root"></div>
<div id='bg'></div>
<div id="btn-connexion" class="fb-login-button" data-max-rows="1" data-size="xlarge" data-show-faces="true" onLogin='connect();' data-auto-logout-link="false"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/fr_FR/sdk.js#xfbml=1&version=v2.8&appId=1716554568577064";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>