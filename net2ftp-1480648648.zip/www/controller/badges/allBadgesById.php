<?php

include_once "../../config/db.php";

if(isset($_POST["idfacebook"])){
	$id = $_POST["idfacebook"];
	$statment = $db->prepare("select * from opora2016.badge b join opora2016.possede_badge pb on b.id_badge = pb.id_badge where id_facebook = :idfb;");
	$statment->BindValue(":idfb", $id);
	$statment->execute();


	echo json_encode($statment->fetchAll(PDO::FETCH_ASSOC));
}




