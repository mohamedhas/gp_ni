<div class="divNewBadge">
     <span class="libelle_badge">
          <label> Titre du nouveau badge </label>
     </span>
     <input id="inputTitre" class="validate[required,custom[onlyLetter],length[0,100]] feedback-input" type="text">
     <br>
     <span class="libelle_desc">
          <label> Description du badge </label>
     </span>
     <textarea style="height:150px; width:300px" class="validate[required,custom[onlyLetter],length[0,100]] feedback-input" id="textareaDescr"></textarea>
     <br>
     <span class="image_badge">
          <label class="label_imageBadge"> Image du nouveau badge : </label>
          <input type="file" id="_file" accept="image/*" class="btn_imageRecompense">
          <img src="#" id="previewImage" style="display: none;">
     </span>
     <br>
     <span class="libelle_badge">
          <label> Condition d'obtention </label>
     </span>
     <div class="divConditions">
          <div class="uneCondition">
               <select id="metrique0">
                    <option value="">Caracteristique � comparer</option>
                    <option value="1">Niveau</option>
                    <option value="2">XP</option>
                    <option value="3">Points</option>
                    <option value="5">Anniversaire</option>
                    <option value="8">Nombre de questions/r�ponses</option>
                    <option value="7">Nombre de questions</option>
                    <option value="6">Nombre de r�ponses</option>
                    <option value="4">Date</option>
               </select>
               <select id="compare0" style="display: none;">
               </select>
               <input type="text" placeholder="valeur � comparer" id="value0" style="display: none;">
          </div>
          <button> Ajouter une condition </button>
     </div>
     <button class="btn_gestionBadge"> Sauvegarder </button>
</div>