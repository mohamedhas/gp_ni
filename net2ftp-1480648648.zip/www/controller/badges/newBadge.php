<?php
//session_start();
include_once "../../config/db.php";

if(isset($_POST["libelle_badge"]) && isset($_POST["description"]) && isset($_POST["photo"]))
{
	$libelle_badge = $_POST["libelle_badge"];
	$description = $_POST["description"];
	$photo = $_POST["photo"];

	$new = $db->prepare("insert into opora2016.badge (libelle_badge, photo_badge, description_badge) values (:libelle_badge, :photo, :description)");
	$new->bindValue(":libelle_badge",$libelle_badge);
	$new->bindValue(":photo",$photo);
	$new->bindValue(":description",$description);
	$new->execute();
	
	
	$new = $db->prepare("select last_value from opora2016.\"Badge_id_badge_seq\"");
	$new->execute();
	$newID = $new->fetch()[0];


	echo $newID;
}
else
{
	echo "NO BADGE..:";
}

