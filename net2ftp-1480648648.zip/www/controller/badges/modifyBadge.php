<?php
//session_start();
include_once "../../config/db.php";

if(isset($_POST['id_badge']) && isset($_POST["libelle_badge"]) && isset($_POST["description"]) && isset($_POST["photo"]))
{
	$libelle_badge = $_POST["libelle_badge"];
	$description = $_POST["description"];
	$photo = $_POST["photo"];
	$id_badge = $_POST['id_badge'];

	$new = $db->prepare("update opora2016.badge set libelle_badge=:libelle_badge, photo_badge=:photo, description_badge=:description where id_badge=:id_badge");
	$new->bindValue(":libelle_badge",$libelle_badge);
	$new->bindValue(":photo",$photo);
	$new->bindValue(":description",$description);
	$new->bindValue(":id_badge",$id_badge);
	$new->execute();
	
	$del = $db->prepare("delete from opora2016.condition_obtention_badge where id_badge=:id_badge");
	$del->bindValue(":id_badge",$id_badge);
	$del->execute();
	
	$newID = $id_badge;


	echo $newID;
}
else
{
	echo "NO BADGE..:";
}

