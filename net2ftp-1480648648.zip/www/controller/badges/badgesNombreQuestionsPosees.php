<?php

include_once "../../config/db.php";

$id_facebook = $_POST["id_facebook"];

///////// RECUPERATION NOMBRE QUESTION //////////////////////////////
$count_question = $db->prepare("select count(id_question) from opora.question where id_facebook =:id_facebook");
	$count_question->bindValue(":id_facebook",$id_facebook);
	$count_question->execute();
	$count_question = $count_question->fetch();
	echo ($count_question[0]);

// switch($count_question[0]+1) {
// 		case 10 :  	
// 					$new_titre = $db->prepare("insert into opora.affecte_a (id_facebook, id_titre) values (:id_facebook, 10)");
// 					$new_titre->bindValue(":id_facebook",$id_facebook);
// 					$new_titre->execute();


// 		break;
// 		case 100 : $new_titre = $db->prepare("insert into opora.affecte_a (id_facebook, id_titre) values (:id_facebook, 11)");
// 					$new_titre->bindValue(":id_facebook",$id_facebook);
// 					$new_titre->execute();
// 		break;
// 		case 500 : $new_titre = $db->prepare("insert into opora.affecte_a (id_facebook, id_titre) values (:id_facebook, 12)");
// 					$new_titre->bindValue(":id_facebook",$id_facebook);
// 					$new_titre->execute();
// 		break;
// 		case 1000 : $new_titre = $db->prepare("insert into opora.affecte_a (id_facebook, id_titre) values (:id_facebook, 14)");
// 					$new_titre->bindValue(":id_facebook",$id_facebook);
// 					$new_titre->execute();
// 		break;
// 	}
// echo $count_question[0]+1;