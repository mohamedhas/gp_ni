<?php
session_start();
include_once "../../config/db.php";


if (isset($_POST["id_facebook"]) && isset($_POST["id_badge"])) {

	$id_facebook = $_POST["id_facebook"];
	$id_badge = $_POST["id_badge"];


	$statment = $db->prepare("insert into opora.associe_a_un
								(id_facebook, id_badge) 
								values(:idface, :idB)");
	$statment->bindValue(":idB", $id_badge);
	$statment->bindValue(":idface", $id_facebook);
	$statment->execute();

	
	echo json_encode(true);

}
else 
	echo json_encode(false);


