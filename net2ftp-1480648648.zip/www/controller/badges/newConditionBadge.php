<?php

include_once "../../config/db.php";

if(isset($_POST["id_badge"]) && isset($_POST["id_metrique"]) && isset($_POST["id_comparaison"]) && isset($_POST["value"]))
{
	$badge = $_POST["id_badge"];
	$met = $_POST["id_metrique"];
	$comp = $_POST["id_comparaison"];
	$val = $_POST["value"];
	
	echo "OJ";
	$statment = $db->prepare("insert into opora2016.condition_obtention(id_metrique, id_comparaison, valeur_seuil) values (:metrique, :comparaison, :valeur) returning id_obtention;");
	$statment->bindValue(":metrique", $met);
	$statment->bindValue(":comparaison", $comp);
	$statment->bindValue(":valeur", $val);
	$statment->execute();
    $idCondition = $statment->fetch()[0];
	
	echo $idCondition;
	
	$statment = $db->prepare("insert into opora2016.condition_obtention_badge (id_badge, id_obtention) values (:badge, :cond);");
	$statment->bindValue(":badge", $badge);
	$statment->bindValue(":cond", $idCondition);
	$statment->execute(); 
	
	echo "insert into opora2016.condition_obtention_badge (id_badge, id_obtention) values ($badge, $idCondition);";
}

