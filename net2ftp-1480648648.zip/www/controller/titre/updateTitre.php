<?php

include_once "../../config/db.php";

if (isset($_GET["idtitre"]) && isset($_GET["idfacebook"]))
{
	
	$statment = $db->prepare("update opora2016.internaute set id_titre = :idtitre where id_facebook = :idfacebook");
	$statment->bindValue(":idtitre", $_GET["idtitre"]);
	$statment->bindValue(":idfacebook", $_GET["idfacebook"]);
	$statment->execute();
	
	echo json_encode(true);
}


