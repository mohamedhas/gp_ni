<?php
//session_start();
include_once "../../config/db.php";

if(isset($_POST['id_titre']) && isset($_POST["libelle_titre"]))
{
	$libelle_titre = $_POST["libelle_titre"];
	$id_titre = $_POST['id_titre'];

	$new = $db->prepare("update opora2016.titre set libelle_titre=:libelle_titre where id_titre=:id_titre");
	$new->bindValue(":libelle_titre",$libelle_titre);
	$new->bindValue(":id_titre",$id_titre);
	$new->execute();
	
	$del = $db->prepare("delete from opora2016.condition_obtention_titre where id_titre=:id_titre");
	$del->bindValue(":id_titre",$id_titre);
	$del->execute();
	
	$newID = $id_titre;


	echo $newID;
}
else
{
	echo "NO TITRE..:";
}

