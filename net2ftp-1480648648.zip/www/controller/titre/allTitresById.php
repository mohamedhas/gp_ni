<?php

include_once "../../config/db.php";

if(isset($_POST["idfacebook"])){
	$id = $_POST["idfacebook"];
	$statment = $db->prepare("select * from opora2016.titre b join opora2016.possede_titre pb on b.id_titre = pb.id_titre where id_facebook = :idfb;");
	$statment->BindValue(":idfb", $id);
	$statment->execute();


	echo json_encode($statment->fetchAll(PDO::FETCH_ASSOC));
}




