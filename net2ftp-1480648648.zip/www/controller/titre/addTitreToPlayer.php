<?php
session_start();
include_once "../../config/db.php";


if (isset($_POST["id_facebook"]) && isset($_POST["id_titre"])) {

	$id_facebook = $_POST["id_facebook"];
	$id_titre = $_POST["id_titre"];


	$statment = $db->prepare("insert into opora2016.possede_titre
								(id_facebook, id_titre) 
								values(:idface, :idTitre)");
	$statment->bindValue(":idTitre", $id_titre);
	$statment->bindValue(":idface", $id_facebook);
	$statment->execute();

	
	echo json_encode(true);

}
else 
	echo json_encode(false);


