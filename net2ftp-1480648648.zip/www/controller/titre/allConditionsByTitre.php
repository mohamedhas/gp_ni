<?php

include_once "../../config/db.php";

if(isset($_POST["id_titre"])){
	$id = $_POST["id_titre"];
	$statment = $db->prepare("select * from opora2016.titre b
		join opora2016.condition_obtention_titre cob on cob.id_titre = b.id_titre
		join opora2016.condition_obtention co on co.id_obtention = cob.id_obtention
		join opora2016.metrique m on m.id_metrique = co.id_metrique
		join opora2016.comparaison c on c.id_comparaison = co.id_comparaison
		where b.id_titre = :id;");
	$statment->BindValue(":id", $id);
	$statment->execute();


	echo json_encode($statment->fetchAll(PDO::FETCH_ASSOC));
}




