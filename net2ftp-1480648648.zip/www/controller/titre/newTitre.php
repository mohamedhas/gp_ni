<?php
//session_start();
include_once "../../config/db.php";

if(isset($_POST["libelle_titre"]))
{
	$libelle_titre = $_POST["libelle_titre"];

	$new = $db->prepare("insert into opora2016.titre (libelle_titre) values (:libelle_titre) returning id_titre");
	$new->bindValue(":libelle_titre",$libelle_titre);
	$new->bindValue(":photo",$photo);
	$new->bindValue(":description",$description);
	$new->execute();
	$newID = $new->fetch()[0];


	echo $newID;
}
else
{
	echo "NO TITRE..:";
}

