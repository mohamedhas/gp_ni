<?php

include_once "../../config/db.php";

if(isset($_POST["id_titre"]) && isset($_POST["id_metrique"]) && isset($_POST["id_comparaison"]) && isset($_POST["value"]))
{
	$titre = $_POST["id_titre"];
	$met = $_POST["id_metrique"];
	$comp = $_POST["id_comparaison"];
	$val = $_POST["value"];
	
	echo "OJ";
	$statment = $db->prepare("insert into opora2016.condition_obtention(id_metrique, id_comparaison, valeur_seuil) values (:metrique, :comparaison, :valeur) returning id_obtention;");
	$statment->bindValue(":metrique", $met);
	$statment->bindValue(":comparaison", $comp);
	$statment->bindValue(":valeur", $val);
	$statment->execute();
    $idCondition = $statment->fetch()[0];
	
	echo $idCondition;
	
	$statment = $db->prepare("insert into opora2016.condition_obtention_titre (id_titre, id_obtention) values (:titre, :cond);");
	$statment->bindValue(":titre", $titre);
	$statment->bindValue(":cond", $idCondition);
	$statment->execute(); 
	
}

