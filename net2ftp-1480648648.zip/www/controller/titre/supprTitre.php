<?php
include_once "../../config/db.php";

$id = $_POST['id'];


$statment = $db->prepare("update opora2016.internaute set id_titre = 1 where id_titre = :id");
$statment->bindValue(':id', $id);
$statment->execute();

$statment = $db->prepare("delete from opora2016.possede_titre where id_titre = :id");
$statment->bindValue(':id', $id);
$statment->execute();

echo "delete from opora2016.possede_titre where id_titre = :id";
echo "delete from opora2016.titre where id_titre = :id";
$statment = $db->prepare("delete from opora2016.titre where id_titre = :id");
$statment->bindValue(':id', $id);
$statment->execute();


