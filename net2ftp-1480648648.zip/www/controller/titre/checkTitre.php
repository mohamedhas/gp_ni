<?php
include_once "../../config/db.php";


if(isset($_POST['id_facebook']))
{
        
	$id = $_POST['id_facebook'];
        $query = "select * from opora2016.titre where id_titre not in (select id_titre from opora2016.possede_titre where id_facebook = ". $id . ")";
	$statment = $db->prepare($query); 
	$statment->execute();
	$titres = $statment->fetchAll(PDO::FETCH_ASSOC);
	
        $titreADonner = array();
        
	foreach($titres as $titre)
	{
		$obtenable = true;
		
		$statment = $db->prepare("select * from opora2016.condition_obtention_titre cb
			join opora2016.condition_obtention co on cb.id_obtention = co.id_obtention
			join opora2016.metrique m on m.id_metrique = co.id_metrique
			join opora2016.comparaison c on c.id_comparaison = co.id_comparaison where cb.id_titre = ". $titre['id_titre']);
		$statment->execute();
		$conditions = $statment->fetchAll(PDO::FETCH_ASSOC);
		foreach($conditions as $condition)
		{
			$comparaison = $condition['id_comparaison'];
			switch($condition['id_metrique']){
				case 1 : if(!check(getNiveau($id), $comparaison, $condition['valeur_seuil']))
								$obtenable = false;					//Niveau
					break;
				case 2 : if(!check(getXP($id), $comparaison, $condition['valeur_seuil']))
								$obtenable = false;					//XP
					break;
				case 3 : if(!check(getPoints($id), $comparaison, $condition['valeur_seuil']))
								$obtenable = false;					//Points
					break;
				case 4 : if(!checkForDate($comparaison, $condition['date_seuil']))
					$obtenable = false;					//Date
					break;
				case 5 : if(!checkForDate(1, getBirth($id)))
								$obtenable = false;					//Anniversaire
					break;
				case 6 : if(!check(getNBReponses($id), $comparaison, $condition['valeur_seuil']))
								$obtenable = false;					//Nb reponses
					break;
				case 7 : if(!check(getNBQuestions($id), $comparaison, $condition['valeur_seuil']))
								$obtenable = false;					//Nb questions
					break;
				case 8 : if(!check(getNBQR($id), $comparaison, $condition['valeur_seuil']))
								$obtenable = false;					//Nb Q&R
					break;
				
			}
		}

                if($obtenable)
                {
                      array_push($titreADonner, $titre['libelle_titre']);

 
	              $statment2 = $db->prepare("insert into opora2016.possede_titre
								(id_facebook, id_titre) 
								values(:idface, :idB)");
	              $statment2->bindValue(":idB", $titre['id_titre']);
	              $statment2->bindValue(":idface", $id);
	              $statment2->execute();
               }
                
	}
 
	echo json_encode($titreADonner);
}
else {
	echo json_encode(false);
}


function check($valeur, $compar, $seuil)
{
	switch($compar)
	{
		case 1 :return $valeur == $seuil;
			break;
		case 2 : return $valeur < $seuil;
			break;
		case 3 :return $valeur <= $seuil;
			break;
		case 4 : return $valeur > $seuil;
			break;
		case 5 : return $valeur >= $seuil;
			break;
	}
}
function checkForDate($compar, $seuil)
{
	$valeur = new DateTime('now');
	$seuil = new DateTime($seuil);
	switch($compar)
	{
		case 1 : return $valeur == $seuil;
			break;
		case 2 : return $valeur < $seuil;
			break;
		case 3 : return $valeur <= $seuil;
			break;
		case 4 : return $valeur > $seuil;
			break;
		case 5 : return $valeur >= $seuil;
			break;
	}
}

function getXP($id)
{
        include "../../config/db.php";

	$st = $db->prepare("select num_niveau, experience from opora2016.internaute where id_facebook=".$id);
	$st->execute();
	$inter = $st->fetch(PDO::FETCH_ASSOC);
	$exp_inter = $inter['experience'];
	$niv_inter = $inter['num_niveau'];
	
	$st = $db->prepare("select exp_requis from opora2016.niveau where num_niveau <= ".$niv_inter);
	$st->execute();
	$nivs = $st->fetchAll(PDO::FETCH_ASSOC);
	$exp_nivs = 0;
	foreach($nivs as $niveau)
		$exp_nivs += $niveau['exp_requis'];
	
	$experience_totale = $exp_inter + $exp_nivs;
	return $experience_totale;
}
function getNiveau($id)
{
        include "../../config/db.php";

	$st = $db->prepare("select num_niveau from opora2016.internaute where id_facebook=".$id);
	$st->execute();
	$inter = $st->fetch(PDO::FETCH_ASSOC);
	
	return $inter['num_niveau'];
}

function getPoints($id)
{
        include "../../config/db.php";

	$st = $db->prepare("select points from opora2016.internaute where id_facebook=".$id);
	$st->execute();
	$inter = $st->fetch(PDO::FETCH_ASSOC);
	
	return $inter['points'];
}

function getNBReponses($id)
{
        include "../../config/db.php";

	$st = $db->prepare("select count(*) \"nb\" from opora2016.reponse where id_facebook=".$id);
	$st->execute();
	$inter = $st->fetch(PDO::FETCH_ASSOC);
	
	return $inter['nb'];
}

function getNBQuestions($id)
{
        include "../../config/db.php";

	$st = $db->prepare("select count(*) \"nb\" from opora2016.question where id_facebook=".$id);
	$st->execute();
	$inter = $st->fetch(PDO::FETCH_ASSOC);
	
	return $inter['nb'];
}

function getNBQR($id)
{
	return getNBQuestions($id) + getNBReponses($id);
}

	