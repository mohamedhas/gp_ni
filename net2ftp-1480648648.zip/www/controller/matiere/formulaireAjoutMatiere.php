<?php 
include_once "../../config/db.php";

$statement = $db->prepare("select * from opora2016.categorie");
$statement->execute();
$categories = $statement->fetchAll(PDO::FETCH_ASSOC);
?>

<section id="contenu">
	<img src="icon/backButton.png" class="backButton">
	<div style="background-color: #" id="div_titre">
		<h1 style="background-color: #" class="titre_main">Ajouter UNE MATIERE</h1>
	</div>
	<div class="divNewBadge">
		<span class="libelle_categorie"><label> Nom de la matière </label></span>
		<input id="nom_categorie" name="nom_categorie" class="validate[required,custom[onlyLetter],length[0,100]] feedback-input" type="text" value='' />
		<br>
		<span class="listeDept"><label> Catégories associées </label>
		<?php 
		foreach($categories as $cat){
			echo "<input type='checkbox' name='categorie' data-id='". $cat['id_categorie'] ."' class='checkCategorie' id='cat". $cat['id_categorie'] ."' /><label for='cat". $cat['id_categorie'] ."'>".$cat['libelle_categorie'] . "</label></br>";
		}?>
		</span>
		<br/>
		<button class="btn_gestionMatiere"> Ajouter </button>
	</div>
</section>