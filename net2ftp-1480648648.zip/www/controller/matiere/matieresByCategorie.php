<?php
include_once "../../config/db.php";

$id_categorie = $_POST['id_categorie'];

$statment = $db->prepare("select * from opora2016.matiere_appartient_a_categorie mc 
join opora2016.matiere m on mc.id_matiere=m.id_matiere 
where id_categorie=:id");
$statment->bindValue(":id", $id_categorie);
$statment->execute();

echo json_encode($statment->fetchAll());



