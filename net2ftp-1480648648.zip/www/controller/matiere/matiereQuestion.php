<?php
include_once "../../config/db.php";


if(isset($_POST["id_categ"]) && !empty($_POST["id_categ"])){
	$id_categ = $_POST["id_categ"];
/*
	$statment1 = $db->prepare("select * from opora.est_lie_a e join opora.matiere m on e.id_matiere = m.id_matiere where id_categorie=:id_categ");
	$statment1->bindValue(":id_categ", $id_categ);
	$statment1->execute();
*/
	
	//----------------------------------------------
	//----------------------------------------------
	//2016
	
	$statment1 = $db->prepare("select * from opora2016.matiere_appartient_a_categorie mc 
				join opora2016.matiere m on mc.id_matiere = m.id_matiere 
				where mc.id_categorie=:id_categ");
  
	$statment1->bindValue(":id_categ", $id_categ);
	$statment1->execute();


	echo json_encode($statment1->fetchAll());

}
else{
echo "no";
}







