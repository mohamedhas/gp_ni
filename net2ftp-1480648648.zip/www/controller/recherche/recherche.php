<?php

ini_set('display_errors', '1');
include_once "recherche_profil.php";
include "recherche_question.php";

$search = strtolower($_POST["valeur"]);
$page = $_POST["page"];

$matches_question = 0;
echo '<div id="banniere_recherche">';
echo "<p id='titre_recherche' >Résultat de la recherche</p>";
echo '</div>';
echo '<div id="recherche_question">';
if($search != ""){
	$questions = Recherche_question($search, $page);
	$matches_question = count($questions);
	if($matches_question > 0){
		$nbPages = ceil(nbQuestions($idfb)/10); //10 Questions by pages 
		
		echo '<ul id="questions_recherche">';
		foreach($questions as $question)
		{
			 echo '<li class="myquestion" data-question="'.$question['id_question'].'">
							<table class="contenu_question">
								<tbody>
									<tr>
										<td rowspan="2" class="profil_question">
											<img src="https://graph.facebook.com/'. $question['id_facebook'] . '/picture?type=large" class="imageQuestion">
										</td>
										<td class="titre">
											'. $question['libelle_matiere'] .' : '. htmlentities($question['titre']) . '
										</td>
										<td rowspan="2" class="nbreponse">
											Nombre de reponses : '. nbResponsesByQuestion($question['id_question']) .'
										</td>
									</tr>
									<tr>
										<td class="dept_libelle_'. $question['libelle_dept'] . '">
											'. $question['libelle_dept'] .'
										</td>
									</tr>
									<tr>
										<td class="date">
											'. $question['date_post'] . '
										</td>
									</tr>
								</tbody>
							</table>
						</li>';
		}
		paginate($nbPages, $page);
		echo '</ul>';
	}
}
if($matches_question == 0 || $search == ""){
	echo "<p>Oh noooon :( Aucun post ne correspond à votre recherche!</p>";
}
echo '</div>';

$matches_profil = 0;

echo '
<div id="recherche_profil">';
if($search != ""){
	$profils = Recherche_profil($search, $page);
	$matches_profil = count($profils);
	if($matches_profil > 0){
		// $nbPages = ceil(nbProfils($search)/10); //10 profils by pages 
		echo '<ul id="profils_recherche">';
		foreach($profils as $profil)
		{
			echo '<div class="profil_recherche">';
			 echo '<li class="myprofil" data-profil="'.$profil['id_facebook'].'">
							<table class="contenu_profil">
								<tbody>
									<tr>
										<td class="img_profil">
											<img src="https://graph.facebook.com/'. $profil['id_facebook'] . '/picture?type=large" class="imageprofil">
										</td>
									</tr>
									<tr>
										<td class="dept_libelle_'. $profil['libelle_dept'] . '">
											'. $profil['libelle_dept'] .'
										</td>
									</tr>
									<tr>
										<td class="pseudo">
											'. $profil['pseudo'] . '
										</td>
									</tr>
								</tbody>
							</table>
						</li>';
			echo '</div>';
		}
		paginate($nbPages, $page);
		echo '</ul>';
	}
}
if($matches_profil == 0 || $search == ""){
	echo "<p>Oh noooon :( Aucun joueur ne correspond à votre recherche!</p>";
}
echo '</div>';





function nbResponsesByQuestion($id)
{
	include "../../config/db.php";


	$statment = $db->prepare(" select count(*) from opora2016.reponse where id_question = ".$id);
	$statment->execute();

	return $statment->fetch()[0];

}
function nbQuestions($search){
	include "../../config/db.php";

	
	$statment = $db->prepare("select count(*) from opora2016.question  q
			join opora2016.reponse r on r.id_question = q.id_question
			where q.titre LIKE '%".$search."%' OR q.texte LIKE '%".$search."%' OR r.texte LIKE '%".$search."%'");
	$statment->execute();
	

	return $statment->fetch()[0];
}


function paginate($total, $current, $adj=3) {
	
	// Initialisation des variables
	$prev = $current - 1; // numéro de la page précédente
	$next = $current + 1; // numéro de la page suivante
	$penultimate = $total - 1; // numéro de l'avant-dernière page
	$pagination = ''; // variable retour de la fonction : vide tant qu'il n'y a pas au moins 2 pages
 
	if ($total > 1) {
		// Remplissage de la chaîne de caractères à retourner
		$pagination .= "<div id=\"pagination\">\n";
 
		/* =================================
		 *  Affichage du bouton [précédent]
		 * ================================= */
		if ($current != 1) {
			// la page courante est supérieure à 1, le bouton renvoie sur la page dont le numéro est immédiatement inférieur
			$pagination .= "<span id='{$prev}'>◄</span>";
		}
		// } else {
			// dans tous les autres, cas la page est 1 : désactivation du bouton [précédent]
			// $pagination .= '<span class="inselected">◄</span>';
		// }
 
		/**
		 * Début affichage des pages, l'exemple reprend le cas de 3 numéros de pages adjacents (par défaut) de chaque côté du numéro courant
		 * - CAS 1 : il y a au plus 12 pages, insuffisant pour faire une troncature
		 * - CAS 2 : il y a au moins 13 pages, on effectue la troncature pour afficher 11 numéros de pages au total
		 */
 
		/* ===============================================
		 *  CAS 1 : au plus 12 pages -> pas de troncature
		 * =============================================== */
		if ($total < 7 + ($adj * 2)) {
			
			for ($i=1; $i<=$total; $i++) {
				if ($i == $current) {
					// Le numéro de la page courante est mis en évidence (cf. CSS)
					$pagination .= "<span class=\"selected\">{$i}</span>";
				} else {
					// Les autres sont affichées normalement
					$pagination .= "<span id=\"{$i}\">{$i}</span>";
				}
			}
		}
		/* =========================================
		 *  CAS 2 : au moins 13 pages -> troncature
		 * ========================================= */
		else {
			/**
			 * Troncature 1 : on se situe dans la partie proche des premières pages, on tronque donc la fin de la pagination.
			 * l'affichage sera de neuf numéros de pages à gauche ... deux à droite
			 * 1 2 3 4 5 6 7 8 9 … 16 17
			 */
			if ($current < 2 + ($adj * 2)) {
				for ($i = 1; $i < 4 + ($adj * 2); $i++) {
					if ($i == $current) {
						$pagination .= "<span class=\"selected\">{$i}</span>";
					} else {
						$pagination .= "<span id=\"{$i}\">{$i}</span>";
					}
				}
 
				// ... pour marquer la troncature
				$pagination .= '&hellip;';
 
				// et enfin les deux derniers numéros
				$pagination .= "<span id=\"{$penultimate}\">{$penultimate}</span>";
				$pagination .= "<span id=\"{$total}\">{$total}</span>";
			}
			/**
			 * Troncature 2 : on se situe dans la partie centrale de notre pagination, on tronque donc le début et la fin de la pagination.
			 * l'affichage sera deux numéros de pages à gauche ... sept au centre ... deux à droite
			 * 1 2 … 5 6 7 8 9 10 11 … 16 17
			 */
			elseif ( (($adj * 2) + 1 < $current) && ($current < $total - ($adj * 2)) ) {
				// Affichage des numéros 1 et 2
				$pagination .= "<span id='1'>1</span>";
				$pagination .= "<span id='2'>2</span>";
				$pagination .= '&hellip;';
 
				// les pages du milieu : les trois précédant la page courante, la page courante, puis les trois lui succédant
				for ($i = $current - $adj; $i <= $current + $adj; $i++) {
					if ($i == $current) {
						$pagination .= "<span class=\"selected\">{$i}</span>";
					} else {
						$pagination .= "<span id=\"{$i}\">{$i}</span>";
					}
				}
 
				$pagination .= '&hellip;';
 
				// et les deux derniers numéros
				$pagination .= "<span id=\"{$penultimate}\">{$penultimate}</span>";
				$pagination .= "<span id=\"{$total}\">{$total}</span>";
			}
			/**
			 * Troncature 3 : on se situe dans la partie de droite, on tronque donc le début de la pagination.
			 * l'affichage sera deux numéros de pages à gauche ... neuf à droite
			 * 1 2 … 9 10 11 12 13 14 15 16 17
			 */
			else {
				// Affichage des numéros 1 et 2
				$pagination .= "<span id='1'>1</span>";
				$pagination .= "<span id=\"2\">2</span>";
				$pagination .= '&hellip;';
 
				// puis des neuf derniers numéros
				for ($i = $total - (2 + ($adj * 2)); $i <= $total; $i++) {
					if ($i == $current) {
						$pagination .= "<span class=\"selected\">{$i}</span>";
					} else {
						$pagination .= "<span id=\"{$i}\">{$i}</span>";
					}
				}
			}
		}
 
		/* ===============================
		 *  Affichage du bouton [suivant]
		 * =============================== */
		// if ($current == $total)
			// $pagination .= "<span class=\"inselected\">►</span>\n";
		// else
		if($current != $total)
			$pagination .= "<span id=\"{$next}\">►</span>\n";
 
		// Fermeture de la <div> d'affichage
		$pagination .= "</div>\n";
	}
 
	return ($pagination);
}

