<?php

ini_set('display_errors', '1');
include "../../config/db.php";




function Recherche_profil($search, $page){
	
	include "../../config/db.php";
	
	$search = strtoupper($search);
	
	if($search != ""){
		
		$profils_by_page = 10;
		$offset = $profils_by_page * ($page-1);
		
		$statment = $db->prepare("select i.id_facebook, i.pseudo, d.libelle_dept from opora2016.internaute i
								join opora2016.departement d on i.id_dept = d.id_dept
								where i.pseudo ILIKE '%".$search."%' OR i.prenom ILIKE '%".$search."%' OR i.nom ILIKE '%".$search."%'
								limit ".$profils_by_page." offset ".$offset);
		$statment->execute();
		
		return $statment->fetchAll(PDO::FETCH_ASSOC);
	}
	
}
