<?php

ini_set('display_errors', '1');
include "../../config/db.php";


function Recherche_question($search, $page){ini_set('display_errors', '1');
	
	include "../../config/db.php";
	
	$search = strtolower($search);
	 if($search != ""){
		$questions_by_page = 10;
		$offset = $questions_by_page * ($page-1);
		
		$statment = $db->prepare("select distinct(q.id_question), q.id_facebook, m.libelle_matiere, q.titre, d.libelle_dept, q.date_post,
								case (select count(*) from opora2016.reponse where id_question = q.id_question) when 0 then q.date_post
								else (select MAX(date_post) from opora2016.reponse where id_question = q.id_question)
								end 
								as \"last\" from opora2016.reponse r
								full join opora2016.question q on r.id_question = q.id_question
								join opora2016.matiere m on m.id_matiere = q.id_matiere
								join opora2016.departement d on q.id_dept = d.id_dept
								where q.titre ILIKE '%".$search."%' OR q.texte ILIKE '%".$search."%' OR r.texte ILIKE '%".$search."%'
								order by last desc limit ".$questions_by_page." offset ".$offset);
		$statment->execute();
		
		return $statment->fetchAll(PDO::FETCH_ASSOC);
	}
	else{
	}
}

