<?php 
session_start();
include_once "../../config/db.php";
include_once "../joueur/addPointPlayer.php";
include_once "../joueur/addXP.php";
$id_facebook = $_POST["id_facebook"];
$id_reponse = $_POST["id_reponse"];
$id_voteur = $_POST['id_voteur'];

///!\\\ Attention : id_voteur = celui qui vote,
///!\\\ Attention : id_facebook = celui qui a posté la question

$str = $db->prepare("select * from a_vote_pour_reponse where id_facebook =:id_facebook and id_reponse = :id_reponse");
$str->bindValue(":id_facebook",$id_voteur);
$str->bindValue(":id_reponse",$id_reponse);
$str->execute();
$rows = $str->fetchAll();
if(count($rows) == 0 ){
	addPointPlayer($id_facebook);
	addXP($id_facebook);

	$str2 = $db->prepare("
		update opora2016.reponse set points_reponse = points_reponse + 1
		where id_reponse =:id_reponse");
	$str2->bindValue(":id_reponse",$id_reponse);
	$str2->execute();
	
	$str3 = $db->prepare("
		insert into opora2016.a_vote_pour_reponse(id_facebook, id_reponse) values(:id_facebook, :id_reponse)");
	$str3->bindValue(":id_reponse",$id_reponse);
	$str3->bindValue(":id_facebook",$id_voteur);
	$str3->execute();
	

echo json_encode("insert into opora2016.a_vote_pour_reponse(id_facebook, id_reponse) values($id_voteur, $id_reponse)");
}
else{
	echo json_encode("Deja vote");
}
