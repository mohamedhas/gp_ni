<?php


if (!file_exists('resetPoints.php') OR date('M', filemtime('resetPoints.php')) != date('M')) {

	include_once "../../config/db.php";

	$query = $db->prepare("update opora2016.internaute
							Set points = '0',
							xp_hebdo = '0'");
	$query->execute();

	touch('resetPoints.php');
}

echo json_encode(true);

