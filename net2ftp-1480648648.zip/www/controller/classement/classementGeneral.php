<?php

include_once "classementInternauteFullHebdo.php";

if(isset($_POST['classement']))
{
if($_POST['classement'] == 'Hebdo')
     $classement = classementInternauteFullHebdo();
if($_POST['classement'] == 'Total')
     $classement = classementInternauteFull();

echo '<div class="div_classement_main">
	<table style="width:100%;">
		<tbody>
			<tr id="head">
				<td class="tableRang">Rang</td>
                                <td></td>
				<th class="tableProfil">Profil</td>
				<th class="tableHebdo">KM Hebdomadaires &#8681;</td>
				<th class="tableTotal">KM Generaux &#8681;</td>
				</tr>';
foreach($classement as $internaute)
{
	$place = $internaute['rank'];
	$classePlace = ($place==1?'first_position':($place==2?'second_position':($place==3?'third_position':'other_position')));
	$id = $internaute['id_facebook'];
	$pseudo= $internaute['pseudo'];
	//$prenom = $internaute['prenom' ];
	$pointsHebdo = $internaute['xp_hebdo'];
	$pointsTotal = $internaute['experience'];
	echo '<tr id="classement" data-id="'. $id .'" >
			<td class="position_classementFull">
				<h1 class="'. $classePlace .'">'. $place .'</h1>
			</td>  
			<td>
				<img src="https://graph.facebook.com/'. $id .'/picture?type=large" style="width:3vw; height:3vw;" class="image_classementFull"> 
                        </td>
                        <td>
				<span class="pseudoInternauteFull">'.$pseudo.'</span>
			</td>  
			<td class="pointsInternauteHebdo">
				'.$pointsHebdo*100 .' Km
			</td>  
			<td class="pointsInternauteFull">
				'.$pointsTotal*100 .' Km
			</td>
		</tr>';
}
echo '</tbody></table></div>';
}