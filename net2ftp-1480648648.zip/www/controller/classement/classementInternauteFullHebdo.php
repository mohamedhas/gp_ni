<?php

/*
include_once "../../config/db.php";


$query = $db->prepare("select *, rank () over (order by points Desc) as Rank, 
rank () over (order by total_points Desc) as Rank2 
from opora2016.internaute order by Rank, Rank2");
$query->execute();

echo json_encode($query->fetchAll());
*/
function classementInternauteFullHebdo()
{
include "../../config/db.php";


$query = $db->prepare("select *, rank () over (order by xp_hebdo Desc) as Rank, 
rank () over (order by experience Desc) as Rank2 
from opora2016.internaute order by Rank, Rank2");
$query->execute();

return $query->fetchAll();
}


function classementInternauteFull()
{
include "../../config/db.php";


$query = $db->prepare("select *, rank () over (order by experience Desc) as Rank, 
rank () over (order by xp_hebdo Desc) as Rank2 
from opora2016.internaute order by Rank, Rank2");
$query->execute();

return $query->fetchAll();
}