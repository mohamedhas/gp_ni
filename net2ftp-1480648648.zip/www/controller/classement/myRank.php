<?php
include_once "../../config/db.php";


$query = $db->prepare("select *, rank () over (order by points Desc) as Rank
						from opora2016.internaute");
$query->execute();



echo json_encode($query->fetchAll());