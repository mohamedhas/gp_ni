<?php
include_once "../../config/db.php";

$query = $db->prepare("select *, rank () over (order by total_points Desc) as Rank 
						from opora2016.internaute order by total_points desc  limit 5");
$query->execute();


echo json_encode($query->fetchAll());
