<?php 
if(isset($_POST['place']) && isset($_POST['idfacebook']) && isset($_POST['nom']) && isset($_POST['prenom']) && isset($_POST['pointsHebdo']) && isset($_POST['pointsTotal'])){

$place = $_POST['place'];
$classePlace = ($place==1?'first_position':($place==2?'second_position':($place==3?'third_position':'other_position')));
$id = $_POST['idfacebook'];
$nom = $_POST['nom'];
$prenom = $_POST['prenom' ];
$pointsHebdo = $_POST['pointsHebdo'];
$pointsTotal = $_POST['pointsTotal'];



echo '<tr>';
echo '  <td class="position_classementFull"><h1 class="'.$classePlace.'">'.$place.'</h1></td>';
echo '  <td><img src="https://graph.facebook.com/'.$id.'/picture?type=large" style="width:3vw; height:3vw;" class="image_classementFull" >';
echo '  <span class="nomInternauteFull">'.$nom.'</span><span class="prenomInternauteFull">'.$prenom.'</span></td>';
echo '  <td class="pointsInternauteHebdo">'.$pointsHebdo.' Points</td>';
echo '  <td class="pointsInternauteFull">'.$pointsTotal.' Points</td>';
echo '</tr>';


}
else{
echo 'No';
}