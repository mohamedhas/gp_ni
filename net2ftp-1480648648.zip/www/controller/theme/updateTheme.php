<?php

include_once "../../config/db.php";

if (isset($_GET["theme"]) && isset($_GET["idfacebook"]))
{
	
	$statment = $db->prepare("update opora2016.internaute set theme = :theme where id_facebook = :idfacebook");
	$statment->bindValue(":theme", $_GET["theme"]);
	$statment->bindValue(":idfacebook", $_GET["idfacebook"]);
	$statment->execute();
	
	echo json_encode(true);
}
else echo json_encode(false);
