<?php
include_once "../../config/db.php";

$id_facebook = $_POST['idfacebook'];


$statment = $db->prepare("select * from opora2016.internaute where id_facebook=:id and est_admin = true");
$statment->bindValue(":id", $id_facebook);
$statment->execute();

echo json_encode($statment->fetchAll());


