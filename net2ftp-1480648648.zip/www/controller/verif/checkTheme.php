<?php
include_once "../../config/db.php";

$id_facebook = $_GET['idfacebook'];

$statment = $db->prepare("select theme from opora2016.internaute where id_facebook=:id");
$statment->bindValue(":id", $id_facebook);
$statment->execute();

echo json_encode($statment->fetchAll());
