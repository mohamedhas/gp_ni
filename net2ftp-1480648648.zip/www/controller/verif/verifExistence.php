<?php

include_once "../../config/db.php";


$statment = $db->prepare("select nom, est_nouveau from opora2016.internaute where id_facebook = :idfacebook");
$statment->bindValue(":idfacebook", $_GET["idfacebook"]);
$statment->execute();

echo json_encode($statment->fetchAll());


