<?php 
$image = $_POST['image'];
$place = $_POST['place'];
if($place == 1) $place.='er';
else $place .= 'eme';
?>
<div class='recompense'>
    <p><?php echo $place; ?> au classement <img src="./icon/supprimer.png"></p>
    <table>
		<tr>
			<td rowspan=2>
				<div class='selectImage'>
					<label>Image : </label>
					<img src='<?php echo $image; ?>' class='imageRecompense' style='display:none'/>
					<input type="file" id="_file" accept="image/*" class="btn_imageRecompense">
				</div>
			</td>
			<td>
				<p>
					<label>Nom :</label>
					<input type='text' id='nomRecompense'/>
				</p>
			</td>
		</tr>
		<tr>
			<td>
				<p>
					<label>Description :</label>
					<textarea id='descRecompense'></textarea>
				</p>
			</td>
		</tr>
	</table>
</div>