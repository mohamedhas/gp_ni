<?php
include_once "../../config/db.php";

if(isset($_POST["semaine"]) && isset($_POST['annee'])){
	$semaine = $_POST["semaine"];
        $anneee = $_POST['annee'];
	$statment = $db->prepare("select * from opora2016.recompense where semaine=:semaine and annee=:annee order by place_necessaire");
	$statment->BindValue(":semaine", $semaine);
	$statment->BindValue(":annee", $annee);
	$statment->execute();

	echo json_encode($statment->fetchAll(PDO::FETCH_ASSOC));
}