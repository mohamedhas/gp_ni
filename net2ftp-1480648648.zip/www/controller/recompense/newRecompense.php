<?php
session_start();
include_once "../../config/db.php";

	$libelle_recompense = $_POST["libelle_recompense"];
	$photo_recompense = $_GET["photo_recompense"];

	//A faire : recuperer id du posteur facebook (id_posteur)
	
	$new = $db->prepare("insert into opora2016.recompense (libelle_recompense, photo_recompense) values (:libelle_recompense, :photo_recompense)");
	$new->bindValue(":libelle_recompense",$libelle_badge);
	$new->bindValue(":photo_recompense",$photo_recompense);
	$new->execute();


	echo json_encode(true);


