<?php
include_once "../../config/db.php";

	$statment = $db->prepare("select * from opora.recompense");
	$statment->execute();
	
	//-----------------------
	//-----------------------
	//2016
	//Renommer en AllRecompenses.php et modifier les js qui vont avec
	
	$statment = $db->prepare("select * from opora2016.recompense");
	$statment->execute();


	echo json_encode($statment->fetchAll(PDO::FETCH_ASSOC));
