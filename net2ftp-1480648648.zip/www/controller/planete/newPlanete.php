<?php
//session_start();

ini_set('display_errors', 'On');
error_reporting(e_all);

include_once "../../config/db.php";


if(isset($_POST["nom_planete"]) && isset($_POST["descr_planete"]) && isset($_POST["img"]) && isset($_POST["coordXPlanete"]) && isset($_POST["coordYPlanete"]) && isset($_POST["bonus_xp"]) && isset($_POST["bonus_points"]) && isset($_POST["id_planete"]))
{

	$nom_planete = $_POST["nom_planete"];
	$descr_planete = $_POST["descr_planete"];
	$photo_planete = $_POST["img"];
	$coordX_planete = $_POST["coordXPlanete"];
	$coordY_planete = $_POST["coordYPlanete"];
	$requis = round(sqrt($coordX_planete*$coordX_planete + $coordY_planete*$coordY_planete));
	$bonus_xp_planete = $_POST["bonus_xp"];
	$bonus_points_planete = $_POST["bonus_points"];
	$id_planete = $_POST["id_planete"];

	
	$newLvl = $db->prepare("insert into opora2016.niveau (exp_requis) values (:exp_requis)");
	$newLvl->bindValue(":exp_requis", $requis);
	$newLvl->execute();
	
	
	$new = $db->prepare("insert into opora2016.planete (id_planete, nom_planete, descr_planete, image_planete, coordonnee_x, coordonnee_y, bonus_xp, bonus_points, niveau_requis) 
					values (:id, :nom, :descr, :img, :coordX, :coordY, :xp, :points, :niveau)");

	$new->bindValue(":id",$id_planete);
	$new->bindValue(":nom",$nom_planete);
	$new->bindValue(":descr",$descr_planete);
	$new->bindValue(":img",$photo_planete);
	$new->bindValue(":coordX",$coordX_planete);
	$new->bindValue(":coordY",$coordY_planete);
	$new->bindValue(":xp",$bonus_xp_planete);
	$new->bindValue(":points",$bonus_points_planete);
	$new->bindValue(":niveau",$id_planete);
	$new->execute();
	
	echo "insert into opora2016.planete (id_planete, nom_planete, descr_planete, image_planete, coordonnee_x, coordonnee_y, bonus_xp, bonus_points, niveau_requis) 
					values ('$id_planete', '$nom_planete', '$descr_planete', '$photo_planete', '$coordX_planete', '$coordY_planete', '$bonus_xp_planete', '$bonus_points_planete', '$id_planete')";

	echo json_encode(true);
}
else
{
        echo json_encode(false);
}


	