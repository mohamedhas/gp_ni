<?php
//session_start();

ini_set('display_errors', 'On');
error_reporting(e_all);

include_once "../../config/db.php";


if(isset($_POST["nom_planete"]) && isset($_POST["descr_planete"]) && isset($_POST["img"]) && isset($_POST["coordXPlanete"]) && isset($_POST["coordYPlanete"]) && isset($_POST["bonus_xp"]) && isset($_POST["bonus_points"]) && isset($_POST["id_planete"]))
{

	$nom_planete = $_POST["nom_planete"];
	$descr_planete = $_POST["descr_planete"];
	$photo_planete = $_POST["img"];
	$coordX_planete = $_POST["coordXPlanete"];
	$coordY_planete = $_POST["coordYPlanete"];
	$requis = round(sqrt($coordX_planete*$coordX_planete + $coordY_planete*$coordY_planete));
	$bonus_xp_planete = $_POST["bonus_xp"];
	$bonus_points_planete = $_POST["bonus_points"];
	$id_planete = $_POST["id_planete"];

	
	$newLvl = $db->prepare("update opora2016.niveau exp_requis = :exp_requis where num_niveau = :num_niveau");
	$newLvl->bindValue(":exp_requis", $requis);
	$newLvl->bindValue(":num_niveau", $id_planete);
	$newLvl->execute();
	
	$new = $db->prepare("update opora2016.planete set nom_planete = :nom, descr_planete = :descr, ".($photo_planete != ""?"image_planete = :img,":"")." 
					coordonnee_x = :coordX, coordonnee_y = :coordY, bonus_xp = :xp, bonus_points = :points
					where id_planete = :id");

	$new->bindValue(":id",$id_planete);
	$new->bindValue(":nom",$nom_planete);
	$new->bindValue(":descr",$descr_planete);
	$new->bindValue(":img",$photo_planete);
	$new->bindValue(":coordX",$coordX_planete);
	$new->bindValue(":coordY",$coordY_planete);
	$new->bindValue(":xp",$bonus_xp_planete);
	$new->bindValue(":points",$bonus_points_planete);
	$new->bindValue(":niveau",$id_planete);
	$new->execute();
	
	echo json_encode(true);
}
else
{
        echo json_encode(false);
}


	