<?php
include_once "../../config/db.php";
 
 
if(isset($_POST['id_facebook'])){
  $id = $_POST['id_facebook'];
  $statment = $db->prepare("select * from opora2016.planete p join opora2016.internaute_possede_planete ipp on ipp.id_planete = p.id_planete where ipp.id_facebook=".$id);
  $statment->execute();
 
  echo json_encode($statment->fetchAll(PDO::FETCH_ASSOC));
}
else
{
  echo 'No';
}