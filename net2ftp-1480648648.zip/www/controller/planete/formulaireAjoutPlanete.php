<?php 
include_once "../../config/db.php";

$statement = $db->prepare("select id_planete from opora2016.planete where id_planete >= all(select id_planete from opora2016.planete)");
$statement->execute();
$last_id = $statement->fetch(PDO::FETCH_ASSOC)['id_planete'] + 1;
?>


	<img src="icon/backButton.png" class="backButton">
	<div style="background-color: #" id="div_titre">
		<h1 style="background-color: #" class="titre_main">NOUVELLE PLANÈTE</h1>
	</div>
	<div class="divNewBadge">
		<span class="libelle_planete"><label> Nom de la planète </label></span>
		<input id="nom_planete" name="nom_planete" class="validate[required,custom[onlyLetter],length[0,100]] feedback-input" type="text">
		<br>
		<span class="libelle_desc"><label> Description de la planète </label></span>
		<textarea style="height:150px; width:300px" class="validate[required,custom[onlyLetter],length[0,100]] feedback-input" id="descr_planete" name="descr_planete"></textarea>
		<br>
		<span class="image_planete"><label class="label_imagePlanete"> Image de la planète : </label>
		<input type="file" id="_file" accept="image/*" class="btn_imageRecompense">
		<img src="#" id="previewImage" style="display: none;"></span>
		<br>
		<span class="num_planete"><label> Numero de planète </label></span>
		<input type='text' value='<?php echo $last_id; ?>' disabled  name='id_planete' id='id_planete'/>
		<br>
		<span class="bonus_km"><label> Bonus de KM par sauvetage </label></span>
		<input type='number' name='bonus_xp' id='bonus_xp'/>
		<br>
		<span class="bonus_argent"><label> Bonus d'argent par sauvetage </label></span>
		<input type='number' name='bonus_points' id='bonus_points'/>
		<br>
		<span class='position_planete'><label style='text-align:center'> Les planetes </label><br/>
		<canvas id='canvas_planetes' width='800' height='800'></canvas> <br />
		<label>Coordonnées X : </label><input type='number' step='100' id='coordXPlanete' value='0.0'/><br/>
		<label>Coordonnées Y : </label><input type='number' step='100' id='coordYPlanete' value='0.0'/><br/>
		<label>Nombre de Km : </label><input type='text' id='nombreKM' disabled /><br/>
		<button class="btn_gestionPlanete"> Sauvegarder </button>
	</div>
