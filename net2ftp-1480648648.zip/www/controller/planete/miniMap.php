<div id='bg_planete' style='position:fixed;width:100%;height:100%'></div>
<span class='position_planete'>
	<label style='text-align:center'> Les planetes </label><br/>
	<canvas id='canvas_planetes' width='800' height='800'></canvas>
</span>