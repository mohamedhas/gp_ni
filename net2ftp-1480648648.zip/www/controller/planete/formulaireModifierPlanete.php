<?php 
include_once "../../config/db.php";

$id_planete = $_POST['id_planete'];

$statement = $db->prepare("select * from opora2016.planete where id_planete = " . $id_planete);
$statement->execute();
$planete = $statement->fetch(PDO::FETCH_ASSOC);
$x = $planete['coordonnee_x']*100;
$y = $planete['coordonnee_y']*100;
?>

<section id="contenu">
	<img src="icon/backButton.png" class="backButton">
	<div style="background-color: #" id="div_titre">
		<h1 style="background-color: #" class="titre_main">MODIFIER UNE PLANETE PLANÈTE</h1>
	</div>
	<div class="divNewBadge">
		<span class="libelle_planete"><label> Nom de la planète </label></span>
		<input id="nom_planete" name="nom_planete" class="validate[required,custom[onlyLetter],length[0,100]] feedback-input" type="text" value='<?php echo $planete['nom_planete']; ?>' />
		<br>
		<span class="libelle_desc"><label> Description de la planète </label></span>
		<textarea style="height:150px; width:300px" class="validate[required,custom[onlyLetter],length[0,100]] feedback-input" id="descr_planete" name="descr_planete"><?php echo $planete['descr_planete']; ?></textarea>
		<br>
		<span class="image_planete"><label class="label_imagePlanete"> Image de la planète : </label>
		<input type="file" id="_file" accept="image/*" class="btn_imageRecompense"/>
		<img src="#" id="previewImage" style="display: none;"></span>
		<br>
		<span class="num_planete"><label> Numero de planète </label></span>
		<input type='text'  value='<?php echo $planete['id_planete']; ?>' disabled  name='id_planete' id='id_planete'/>
		<br>
		<span class="bonus_km"><label> Bonus de KM par sauvetage </label></span>
		<input type='number' name='bonus_xp' id='bonus_xp'  value='<?php echo $planete['bonus_xp']; ?>' />
		<br>
		<span class="bonus_argent"><label> Bonus d'argent par sauvetage </label></span>
		<input type='number' name='bonus_points' id='bonus_points' value='<?php echo $planete['bonus_points']; ?>' />
		<br>
		<span class='position_planete'><label style='text-align:center'> Les planetes </label><br/>
		<canvas id='canvas_planetes' width='800' height='800'></canvas> <br />
		<label>Coordonnées X : </label><input type='number' step='100' id='coordXPlanete' value='<?php echo $x; ?>' /><br/>
		<label>Coordonnées Y : </label><input type='number' step='100' id='coordYPlanete' value='<?php echo $y; ?>' /><br/>
		<label>Nombre de Km : </label><input type='text' id='nombreKM'  value='<?php echo round(sqrt($x*$x + $y*$y)); ?>'  disabled /><br/>
		<button class="btn_gestionPlanete"> Sauvegarder </button>
	</div>
</section>