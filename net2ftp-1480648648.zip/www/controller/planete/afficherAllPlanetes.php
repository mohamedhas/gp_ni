<?php 
include_once "../../config/db.php";

$statement = $db->prepare("select * from opora2016.planete");
$statement->execute();
$planetes = $statement->fetchAll(PDO::FETCH_ASSOC);
?>

<section id="contenu">
	<img src="icon/backButton.png" class="backButton">
	<div style="background-color: #" id="div_titre">
		<h1 style="background-color: #" class="titre_main">TOUTES LES PLANÈTES</h1>
	</div>
	<div class='allPlanetes'>
		<table>
			<tr>
				<th>
					Niveau
				</th>
				<th>
					Nom
				</th>
				<th>
					Description
				</th>
				<th>
					Bonus
				</th>
				<th>
					Position
				</th>
				<th>
					Image
				</th>
				<th>
					Gestion
				</th>
			</tr>
		<?php
			foreach($planetes as $planete)
			{
				$x = $planete['coordonnee_x']*100;
				$y = $planete['coordonnee_y']*100;
				echo "<tr>
						<td>" . $planete['id_planete'] ."
						</td><td>". $planete['nom_planete'] . "
						</td><td>". $planete['descr_planete'] ."
						</td><td>Bonus de KM : ". $planete['bonus_xp'] . "<br/>Bonus de $ :" . $planete['bonus_points'] ."
						</td><td>X : ". $x ."<br/>Y : ". $y . "<br/>Distance : ". round(sqrt($x*$x + $y*$y)) ." km
						</td><td><img class='planeteImg' src='". $planete['image_planete'] . "'/>
						</td><td><button class='modifier' data-planete='". $planete['id_planete'] . "'>Modifier</button>
					</tr>";
			}?>
		</table>
	</div>
</section>