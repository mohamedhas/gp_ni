<!doctype html>
<html lang="fr">
<meta charset="utf-8">
<head>


<?php

include_once "config/db.php";
include_once "controller/controller.php";

session_start();



$idfb = $user_profile["id"];//;
echo "ID : ". $idfb;
$theme = $db->prepare("select couleur_dept from opora2016.internaute i join opora2016.departement d on d.id_dept = i.id_dept where id_facebook =:idfb");
$theme->bindValue(":idfb",$idfb);
$theme->execute();
$theme = $theme->fetch();
/*$color = array(
  0 => "",
  1 => ""
);

$_session["user"]["theme"] = $color;
$_session["user"]["theme"][0] = $theme[0];
switch($_session["user"]["theme"][0])
{
  case 'c3272b':
    $_session["user"]["theme"][1] = "f73c3c"; //couleur theme info
  break;
  case '8e44ad':
     $_session["user"]["theme"][1] = "bc76df"; //couleur theme gea
  break;
   case '2980b9' :
      $_session["user"]["theme"][1] = "52b3d9"; //couleur theme opora
  break;

}*/
$themeColor1 = $theme[0];//"#".$_session["user"]["theme"][0];
$themeColor2 = $theme[0];//"#".$_session["user"]["theme"][1];
//
echo "<script>idfacebook='".$idfb."';
color1 = \"#'".$theme[0]/*$_session["user"]["theme"][0]*/."'\";
color2 = \"#'".$theme[0]/*$_session["user"]["theme"][1]*/."'\";
themeColor1 = \"style='background-color: #".$theme[0]/*$_session["user"]["theme"][0]*/."'\";
themeColor2 = \"style='background-color: #".$theme[0]/*$_session["user"]["theme"][1]*/."'\";
      </script>";

//phpinfo();
?>


<!--echo $_SERVER['HTTP_USER_AGENT'] . "\n\n";

$browser=get_browser(null, true);
var_dump ($browser); 
if($browser['browser'] == "Chrome")
{
		?>
		<link href="css/badge.css" rel="stylesheet" type="text/css"/>
		<link href="css/profil.css" rel="stylesheet" type="text/css"/>
		<link href="css/style1.css" rel="stylesheet" type="text/css"/>
		<link href="css/style.css" rel="stylesheet" type="text/css"/>
		<link href="css/point.css" rel="stylesheet" type="text/css"/>
		<link href="css/reponse.css" rel="stylesheet" type="text/css"/>
		<link href="css/question.css" rel="stylesheet" type="text/css"/>
		<link href="css/recherche.css" rel="stylesheet" type="text/css"/>
		<link href="css/recompense.css" rel="stylesheet" type="text/css"/>
		<link href="css/nav_menu.css" rel="stylesheet" type="text/css"/>
		<link href="css/header.css" rel="stylesheet" type="text/css"/>
		<link href="css/formulaire.css" rel="stylesheet" type="text/css"/>
		<link href="css/gestion.css" rel="stylesheet" type="text/css"/>
		<link href="css/classement.css" rel="stylesheet" type="text/css"/>
		<link href="css/contenu.css" rel="stylesheet" type="text/css"/>
		<link href="css/categorie_matiere.css" rel="stylesheet" type="text/css"/>
		<link href="css/button.css" rel="stylesheet" type="text/css"/>
		<link rel="stylesheet" href="./css/progress_bar.css" />
		<link type="text/css" rel="stylesheet" href="css/simplePagination.css"/>
		<link rel="icon" href="./icon/icon_nav.ico" />
		break;
}
?>-->

<link href="css/badge.css" rel="stylesheet" type="text/css"/>
<link href="css/profil.css" rel="stylesheet" type="text/css"/>
<link href="css/style1.css" rel="stylesheet" type="text/css"/>
<link href="css/style.css" rel="stylesheet" type="text/css"/>
<link href="css/point.css" rel="stylesheet" type="text/css"/>
<link href="css/reponse.css" rel="stylesheet" type="text/css"/>
<link href="css/question.css" rel="stylesheet" type="text/css"/>
<link href="css/recherche.css" rel="stylesheet" type="text/css"/>
<link href="css/recompense.css" rel="stylesheet" type="text/css"/>
<link href="css/nav_menu.css" rel="stylesheet" type="text/css"/>
<link href="css/header.css" rel="stylesheet" type="text/css"/>
<link href="css/formulaire.css" rel="stylesheet" type="text/css"/>
<link href="css/gestion.css" rel="stylesheet" type="text/css"/>
<link href="css/classement.css" rel="stylesheet" type="text/css"/>
<link href="css/contenu.css" rel="stylesheet" type="text/css"/>
<link href="css/categorie_matiere.css" rel="stylesheet" type="text/css"/>
<link href="css/button.css" rel="stylesheet" type="text/css"/>
<link rel="stylesheet" href="./css/progress_bar.css" />
<link type="text/css" rel="stylesheet" href="css/simplePagination.css"/>
<link rel="icon" href="./icon/icon_nav.ico" />

<link href='https://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
<link href='https://fonts.googleapis.com/css?family=Maven+Pro:500,700' rel='stylesheet' type='text/css'>
<link href='https://fonts.googleapis.com/css?family=Righteous' rel='stylesheet' type='text/css'>
<link href='https://fonts.googleapis.com/css?family=Lato' rel='stylesheet' type='text/css'>

    <title>Opora - Outil de soutien universitaire</title>

    <meta charset="utf-8">
  </head>
  <body>
  <div id="ohsnap"></div>

    <header class="header" style="background:<?php echo "#".$_session["user"]["theme"][0];?>">
		
       <div class="panel" >

		  <div class="home_profile">
				  <!-- On affiche les informations de l\utilisateur -->
							<div id="photo_profil">
									<img id='photo_once' src="<?php echo $user_picture['data']['url'] ?>"/>

							</div>
							<div id="info_profile_home">
								<div class="progressbar-back">
									<div class="progressbar-front"></div>
								</div>
							
							<!--
							   <div class="progress-pie-chart" data-percent="43">
								<div class="ppc-progress">
								  <div class="ppc-progress-fill"></div>
								</div>
								<div class="ppc-percents">
								  <div class="pcc-percents-wrapper">
									<span>%</span>
								  </div>
								</div>
							  </div>
							  -->
							</div>
			</div>
			<ul class="boutons-menu">
				
				<li>
					<img src="icon\gestion_pic.png" alt="Gestion" id="btnInterfaceGestion"/>
				</li>
				<li class="profil">
					<img src="icon\profile_pic2.png" alt="Modifier mon profil"/>
				</li>
				<li>
					<img src="icon\notif_pic.png" alt="Notifications" class="notification"/>
				</li>
				<!--<li>
					<img src="icon\notifications.png" alt="Notifications"/>
				</li>
				<li>
					<img src="icon\parametre.png" alt="Paramètres"/>
				</li>-->
			</ul>
		</div>
		<!--<div id="hidden_profile_lines">
			<button type="button" class="profil">Voir le profil complet</button>
			<button type="button" id="my_questions">Accéder à mes questions</button>
			<button type="button" id="my_questions">Bouton test</button>
		   <div id="developper_profil">
				<img id="image_developper" src="icon/fleche_bas.png" alt="developer"/>
			</div>
       </div>-->
       <!--<div id="recompenses">

       </div>
       <div id="logo">
        <p class="accueil"></p>
       </div>-->
	   
	   <div id="barre_recherche">
			<!--<input id='input_search' type='search' placeholder='Rechercher'/><button id='btn_search'></button>-->
		</div>
		<ul id='main-menu'>
			<li class="accueil">
				Accueil
			</li><li id="categories">
				Questions par categories
			</li><li id="classements">
				Classement des élèves
			</li>
		</ul>
    </header>


          <div id="primary"><!--
            <div id="home_nav">
              <nav id="side_button">
                <ul id="liste_index">
                  <!--<li id="" class="puce_menu accueil">ACCUEIL</li>-->
                  <!--<li class="profil" class="puce_menu">PROFIL</li>
                    <li id="poster_question" class="puce_menu">POSER UNE QUESTION</li>
                     <li id="my_questions" class="puce_menu">MES QUESTIONS</li>
                    <li id="nav-departement" class="puce_menu">QUESTIONS PAR CATEGORIES</li>
                    <li id="all_questions" class="puce_menu"> TOUTES LES QUESTIONS</li>
                    <li id="btnInterfaceGestion" class="puce_menu" style='display:none;'>GESTION</li>
                  </ul>
              </nav>

            </div>-->
                <section id="contenu">



                    <div id="contenu_div_index"></div>



                </section><!--
                <div id="classement">

                  </div>-->
            </div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.2/jquery.min.js"></script>


<script type="text/javascript" src="js/jquery-ui.min.js"></script>
<script src="js/jMouseWheel-1.0.min.js"></script>
<script type="text/javascript" src="js/index.js"></script>
<script src="js/ohsnap.js"></script>
<script type="text/javascript" src="ckeditor.js"></script>-
<script type="text/javascript" src="js/popup.js"></script>
<script type="text/javascript" src="js/nouveauxInscrits.js"></script>
<script type="text/javascript" src="js/profil.js"></script>
<script type="text/javascript" src="js/titres.js"></script>
<script type="text/javascript" src="js/badges.js"></script>
<script type="text/javascript" src="js/theme.js"></script>
<script type="text/javascript" src="js/categories.js"></script>
<script type="text/javascript" src="js/questions.js"></script>
<script type="text/javascript" src="js/question_abusive.js"></script>
<script type="text/javascript" src="js/departement.js"></script>
<script type="text/javascript" src="js/gestionQuestion.js"></script>
<script type="text/javascript" src="js/matieres.js"></script>
<script type="text/javascript" src="js/recompenses.js"></script>
<script type="text/javascript" src="js/reponse.js"></script>
<script type="text/javascript" src="js/reponse_abusive.js"></script>
<script type="text/javascript" src="js/resetPoints.js"></script>
<script type="text/javascript" src="js/verif.js"></script>
<script type="text/javascript" src="js/classementInternaute.js"></script>
<script type="text/javascript" src="js/parameters.js"></script>
<script type="text/javascript" src="js/resetPoints.js"></script>
<script type="text/javascript" src="js/gestionDesDroits.js"></script>
<script type="text/javascript" src="js/interfaceGestion.js"></script>
<script type="text/javascript" src="js/main.js"></script>
<script type="text/javascript" src="js/recherche.js"></script>
<script type="text/javascript" src="js/tuto.js"></script>
<script type="text/javascript" src="js/notifications.js"></script>
<script type="text/javascript" src="js/niveau.js"></script>
<script async src="//assets.codepen.io/assets/embed/ei.js"></script>
<script type="text/javascript" src="js/jquery.simplePagination.js"></script>



</body>
</html>



