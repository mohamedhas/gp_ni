<?php 

include "../../config/db.php";

$idfb = $_GET['id_facebook'];

$usr = $db->prepare('select * from opora2016.notification where id_facebook = :idfb');
$usr->bindValue(':idfb', $idfb);
$usr->execute();
$usr = $usr->fetchAll(PDO::FETCH_ASSOC);

echo json_encode($usr);