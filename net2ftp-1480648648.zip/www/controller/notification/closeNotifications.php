<?php 

include "../../config/db.php";

$idfb = $_GET['id_facebook'];

$usr = $db->prepare('delete from opora2016.notification where id_facebook = :idfb');
$usr->bindValue(':idfb', $idfb);
$usr->execute();