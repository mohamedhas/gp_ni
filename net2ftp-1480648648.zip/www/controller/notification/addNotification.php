<?php 

include "../../config/db.php";

$question = $_GET['id_question'];
$id_facebook = $_GET['id_posteur'];
$date = date('Y-m-d H:i:s');

$usr = $db->prepare('select id_facebook from opora2016.question where id_question = :quest and id_facebook != :idfb
					union 
					select distinct(id_facebook) from opora2016.reponse r where id_question = :quest and id_facebook != :idfb');
$usr->bindValue(':quest', $question);
$usr->bindValue(':idfb', $id_facebook);
$usr->execute();
$usr = $usr->fetchAll(PDO::FETCH_ASSOC);

foreach($usr as $i){
	$del = $db->prepare('delete from opora2016.notification where id_question = :quest and id_facebook = :fb');
	$del->bindValue(':quest', $question);
	$del->bindValue(':fb', $i['id_facebook']);
	$del->execute();

	$new = $db->prepare('insert into opora2016.notification (id_question, id_facebook, date_notif) values(:quest, :fb, :date)');
	$new->bindValue(':quest', $question);
	$new->bindValue(':fb', $i['id_facebook']);
	$new->bindValue(':date', $date);
	$new->execute();
	
	$response = $facebook->api( '/'.$i['id_facebook'].'/notifications', 'POST', array(

                'template' => 'Du nouveau vous attend sur Opora!',

                'href' => 'RELATIVE URL',

                'access_token' => 'fa55acd9bfe518b15ef2d6d4ec96c937'
            ) );   
	echo "Reponse :";
	print_r($response);
}