<?php
include_once "../../config/db.php";


$statment = $db->prepare("select * from opora2016.comparaison");
$statment->execute();

echo json_encode($statment->fetchAll(PDO::FETCH_ASSOC));



