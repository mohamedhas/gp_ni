<?php

$path = '../' . $_POST["path"];
// Output JSON
function outputJSON($msg, $status = 'error'){
    header('Content-Type: application/json');
    die(json_encode(array(
        'data' => $msg,
        'status' => $status
    )));
}

// Check for errors
if($_FILES['SelectedFile']['error'] > 0){
    outputJSON('An error ocurred when uploading.');
}

if(!getimagesize($_FILES['SelectedFile']['tmp_name'])){
    outputJSON('Please ensure you are uploading an image.');
}

// Check filesize
if($_FILES['SelectedFile']['size'] > 500000){
    outputJSON('File uploaded exceeds maximum upload size.');
}

// Check if the file exists
$i = 0;
$originalPath = $_FILES['SelectedFile']['name'];
$newPath = $path.$originalPath;
while(file_exists($newPath))
{
	$i++;
	$newPath = $path."cpy".$i."_".$originalPath;
}

// Upload file
if(!move_uploaded_file($_FILES['SelectedFile']['tmp_name'], '../'.$newPath)){
    outputJSON('Error uploading file - check destination is writeable.');
}

// Success!
outputJSON(substr($newPath, 3), 'success');