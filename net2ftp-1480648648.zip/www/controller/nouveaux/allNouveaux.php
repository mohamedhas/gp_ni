<?php
include_once "../../config/db.php";


$statment = $db->prepare("select * from opora2016.internaute where est_nouveau = true");
$statment->execute();

echo json_encode($statment->fetchAll(PDO::FETCH_ASSOC));



