<?php

include_once "../../config/db.php";

if(isset($_POST["id"]))
{
	$id = $_POST["id"];
	$statment = $db->prepare("update opora2016.internaute set est_nouveau = false where id_facebook = :id");
	$statment->bindValue(":id", $id);
	$statment->execute();
}