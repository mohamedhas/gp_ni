<?php
include_once "../../config/db.php";

if(isset($_POST["id_dept"])){
	$id = $_POST["id_dept"];

	$statment = $db->prepare("select * from opora2016.internaute where est_nouveau=true and id_dept=:id_dept");
	$statement->BindValue(":id_dept", $id);
	$statment->execute();

	echo json_encode($statment->fetchAll(PDO::FETCH_ASSOC));
}



