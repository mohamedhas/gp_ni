<?php

include_once "../../config/db.php";

if(isset($_POST["id"]))
{
	$id = $_POST["id"];
	$statment = $db->prepare("update opora2016.internaute set est_nouveau = true where id_facebook = :id");
	$statment->bindValue(":id", $id);
	$statment->execute();
	
	$statment = $db->prepare("delete from opora2016.internaute where id_facebook = :id");
	$statment->bindValue(":id", $id);
	$statment->execute();
}