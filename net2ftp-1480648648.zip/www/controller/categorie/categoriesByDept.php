<?php
include_once "../../config/db.php";

$id_departement = $_POST['id_departement'];

$statment = $db->prepare("select * from opora2016.categorie_appartient_a_dept d 
join opora2016.categorie c on d.id_categorie=c.id_categorie 
where id_dept=:id");
$statment->bindValue(":id", $id_departement);
$statment->execute();


echo json_encode($statment->fetchAll());

