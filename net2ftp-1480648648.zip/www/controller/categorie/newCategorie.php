<?php 

include "../../config/db.php";

$nom = $_POST['nom'];
$depts = $_POST['depts'];
$mat = $_POST['matiere'];
$matieres = $_POST['listeMatieres'];


$statement = $db->prepare("insert into opora2016.categorie(libelle_categorie) values ('$nom') returning id_categorie");
$statement->execute();
$id = $statement->fetch()[0];

foreach($depts as $dept)
{
	$statement2 = $db->prepare("insert into opora2016.categorie_appartient_a_dept(id_categorie, id_dept) values ($id, $dept)");
	$statement2->execute();
}

if(!empty($mat))
{
	$statement3 = $db->prepare("insert into opora2016.matiere(libelle_matiere) values ('$mat') returning id_matiere");
	$statement3->execute();
	$id_matiere = $statement3->fetch()[0];
	$statement3 = $db->prepare("insert into opora2016.matiere_appartient_a_categorie(id_categorie, id_matiere) values ($id, $id_matiere)");
	$statement3->execute();
}
foreach($matieres as $matiere)
{
	echo "insert into opora2016.matiere_appartient_a_categorie(id_categorie, id_matiere) values ($id, $matiere)";
	$statement3 = $db->prepare("insert into opora2016.matiere_appartient_a_categorie(id_categorie, id_matiere) values ($id, $matiere)");
	$statement3->execute();
}

?>