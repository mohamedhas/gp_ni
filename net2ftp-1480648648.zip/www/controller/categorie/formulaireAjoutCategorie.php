<?php 
include_once "../../config/db.php";

$statement = $db->prepare("select * from opora2016.departement");
$statement->execute();
$depts = $statement->fetchAll(PDO::FETCH_ASSOC);

$statement = $db->prepare("select * from opora2016.matiere");
$statement->execute();
$matieres = $statement->fetchAll(PDO::FETCH_ASSOC);
?>

<section id="contenu">
	<img src="icon/backButton.png" class="backButton">
	<div style="background-color: #" id="div_titre">
		<h1 style="background-color: #" class="titre_main">MODIFIER UNE PLANETE PLANÈTE</h1>
	</div>
	<div class="divNewBadge">
		<span class="libelle_categorie"><label> Nom de la categorie </label></span>
		<input id="nom_categorie" name="nom_categorie" class="validate[required,custom[onlyLetter],length[0,100]] feedback-input" type="text" value='' />
		<br>
		<span class="listeDept"><label> Departements associés </label>
		<?php 
		foreach($depts as $dept){
			echo "<input type='checkbox' name='dept' data-id='". $dept['id_dept'] ."' class='checkDept' id='dept". $dept['id_dept'] ."' /><label for='dept". $dept['id_dept'] ."'>".$dept['libelle_dept'] . "</label></br>";
		}?>
		</span>
		<br/>
		<table>
		<?php 
                $i = 0;
		foreach($matieres as $matiere)
		{
			if($i == 0) {echo "<tr>";}

			echo "<td><input type='checkbox' class='checkMat' name='categories' id='".$matiere['id_matiere']."' style='float:left' />". $matiere['libelle_matiere'] ."</td>";
		    

			if($i == 2) {echo "</tr>";}
                        $i++;
                        if($i == 3){$i = 0;}
		}?>
		</table>
		<span class="libelle_matiere"><label> Créer une nouvelle matière? (facultatif) </label></span>
		<input id="nom_matiere" name="nom_categorie" class="validate[required,custom[onlyLetter],length[0,100]] feedback-input" type="text" value='' />
		<br>
		<button class="btn_gestionCategorie"> Ajouter </button>
	</div>
</section>