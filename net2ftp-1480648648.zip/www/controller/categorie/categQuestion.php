<?php
include_once "../../config/db.php";
	

if(isset($_POST["id_dept"]) && !empty($_POST["id_dept"])){
	$id_dept = $_POST["id_dept"];

	$statment = $db->prepare("select * from opora2016.categorie_appartient_a_dept d 
				join opora2016.categorie c on d.id_categorie = c.id_categorie 
				where id_dept=:id_dept");
	$statment->bindValue(":id_dept", $id_dept);
	$statment->execute();

	echo json_encode($statment->fetchAll(PDO::FETCH_ASSOC));
}





