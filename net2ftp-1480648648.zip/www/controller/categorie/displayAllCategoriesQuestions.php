<?php

include "../../config/db.php";

$st = $db->prepare("select * from opora2016.departement");
$st->execute();
$depts = $st->fetchAll(PDO::FETCH_ASSOC);

echo "<table class='allCategories'>
	<tr>";

foreach($depts as $dept){
	
	echo "<th>".$dept['libelle_dept'] . "</th>";
}
echo "</tr><tr>";
foreach($depts as $dept){
	$st = $db->prepare("select * from opora2016.categorie c 
						join opora2016.categorie_appartient_a_dept caad on caad.id_categorie = c.id_categorie
						where id_dept = :dept");
	$st->bindValue(":dept", $dept['id_dept']);
	$st->execute();
	$categories = $st->fetchAll(PDO::FETCH_ASSOC);
	
	echo "<td><ul id='menucat'>";
	foreach($categories as $cat){
		echo "<li class='categorie' id='". $cat['id_categorie'] ."'>" . $cat['libelle_categorie'] . "</li>";
	}
	echo "</ul></td>";
	
	
}
echo "</tr>
</table>";