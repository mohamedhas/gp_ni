<?php 
include_once "../../config/db.php";

$statement = $db->prepare("select * from opora2016.categorie");
$statement->execute();
$categories = $statement->fetchAll(PDO::FETCH_ASSOC);

?>
<section id="contenu">
	<img src="icon/backButton.png" class="backButton">
	<div style="background-color: #" id="div_titre">
		<h1 style="background-color: #" class="titre_main">LES CATEGORIES</h1>
	</div>
	<div class='allMatieres'>
		<table>
		<?php 
                $i = 0;
		foreach($categories as $categorie)
		{
			if($i == 0) {echo "<tr>";}

			echo "<td>". $categorie['libelle_categorie'] ."</td>";
		        echo "<td><button data-id='". $categorie['id_categorie'] ."' class='modifier'>Modifier</button><button data-id='". $categorie['id_categorie'] ."' class='suppress'>Supprimer</button></td>";

			if($i == 2) {echo "</tr>";}
                        $i++;
                        if($i == 3){$i = 0;}
		}?>
		</table>
	</div>
</section>