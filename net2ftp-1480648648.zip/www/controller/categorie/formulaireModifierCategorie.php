<?php 
include_once "../../config/db.php";

ini_set('display_errors', 'on');
error_reporting(e_all);

$id = $_POST['id'];

$statement = $db->prepare("select * from opora2016.categorie where id_categorie = ".$id);
$statement->execute();
$categorie = $statement->fetch(PDO::FETCH_ASSOC);

$statement = $db->prepare("select * from opora2016.departement");
$statement->execute();
$depts = $statement->fetchAll(PDO::FETCH_ASSOC);

$statement = $db->prepare("select * from opora2016.matiere");
$statement->execute();
$matieres = $statement->fetchAll(PDO::FETCH_ASSOC);

$statement = $db->prepare("select id_dept from opora2016.departement where id_dept in (select id_dept from opora2016.categorie_appartient_a_dept where id_categorie =".$id.")");
$statement->execute();
$mes_depts = $statement->fetchAll(PDO::FETCH_ASSOC);

$statement = $db->prepare("select id_matiere from opora2016.matiere where id_matiere in (select id_matiere from opora2016.matiere_appartient_a_categorie where id_categorie =".$id.")");
$statement->execute();
$mes_matieres = $statement->fetchAll(PDO::FETCH_ASSOC);

?>

<section id="contenu">
	<img src="icon/backButton.png" class="backButton">
	<div style="background-color: #" id="div_titre">
		<h1 style="background-color: #" class="titre_main">MODIFIER UNE CATEGORIE</h1>
	</div>
	<div class="divNewBadge">
		<span class="libelle_categorie"><label> Nom de la categorie </label></span>
		<input id="nom_categorie" name="nom_categorie" class="validate[required,custom[onlyLetter],length[0,100]] feedback-input" type="text" value='<?php echo $categorie['libelle_categorie'];?>' />
		<br>
		<span class="listeDept"><label> Departements associés </label>
		<?php 
		foreach($depts as $dept){
			$checked = false;
			foreach($mes_depts as $md)
				if($md['id_dept'] == $dept['id_dept'])
					$checked = true;
			echo "<input type='checkbox' name='dept' data-id='". $dept['id_dept'] ."' ".($checked? "checked" : "")." class='checkDept' id='dept". $dept['id_dept'] ."' /><label for='dept". $dept['id_dept'] ."'>".$dept['libelle_dept'] . "</label></br>";
		}?>
		</span>
		<br/>
		<span class="libelle_matiere"><label> Créer une nouvelle matière? (facultatif) </label></span>
		<input id="nom_matiere" name="nom_categorie" class="validate[required,custom[onlyLetter],length[0,100]] feedback-input" type="text" value='' />
		<br>
		<span class="listeDept"><label> Matières associées </label>
		<?php
		foreach($matieres as $mat){
			$checked = false;
			foreach($mes_matieres as $mm)
				if($mm['id_matiere'] == $mat['id_matiere'])
					$checked = true;
			echo "<input type='checkbox' name='matiere' data-id='". $mat['id_matiere'] ."' ".($checked? "checked" : "")." class='checkMat' id='dept". $mat['id_matiere'] ."' /><label for='dept". $mat['id_matiere'] ."'>".$mat['libelle_matiere'] . "</label></br>";
		}?>
		</span>
		<br/>
		<button class="btn_gestionCategorie"> Enregistrer </button>
	</div>
</section>