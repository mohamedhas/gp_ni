<?php 

function loosePointPlayer($id){
	
	include "../../config/db.php";
	
	$bonus = $db->prepare("select * from opora2016.planete p join opora2016.internaute_possede_planete ipp on ipp.id_planete = p.id_planete where ipp.id_facebook=:id_facebook");
	$bonus->bindValue(":id_facebook", $id);
	$bonus->execute();
	$bonus_points = 1;
	foreach($bonus->fetchAll(PDO::FETCH_ASSOC) as $unBonus)
	{
		$bonus_points += $unBonus['bonus_points'];
	}
	
	echo "update opora2016.internaute set points = points - :bonus_points,
		total_points = total_points - :bonus_points
		where id_facebook =".$id;
		
	$str = $db->prepare("
		update opora2016.internaute set points = points - :bonus_points,
		total_points = total_points - :bonus_points
		where id_facebook =:id_facebook");
	$str->bindValue(":id_facebook",$id);
	$str->bindValue(":bonus_points",$bonus_points);
	$str->execute();
	echo "blaaaaaa";
}