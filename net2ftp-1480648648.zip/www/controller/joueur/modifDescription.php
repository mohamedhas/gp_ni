<?php
include_once "../../config/db.php";

$description = $_POST["description"];
$id_facebook = $_POST["id_facebook"];


$statment = $db->prepare("update opora2016.internaute set description =:description where id_facebook =:id");
$statment->bindValue(":description", $description);
$statment->bindValue(":id", $id_facebook);
$statment->execute();

echo json_encode(true);
