<?php


ini_set('display_errors','on');
error_reporting(E_ALL);

include_once "../../config/db.php";
include_once "updateLevel.php";
include_once "addPointPlayer.php";
include_once "addXP.php";

$id_facebook = $_POST["id_facebook"];


addPointPlayer($id_facebook);
addXP($id_facebook);

echo json_encode(true);

