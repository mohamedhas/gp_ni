<?php

include_once "../../config/db.php";


$statment = $db->prepare("select exp_internaute, exp_requise from opora.internaute where id_facebook = :idfb");
$statment->bindValue(":idfb", $_GET["idfacebook"]);
$statment->execute();

//------------------------------
//------------------------------
//2016

$statment = $db->prepare("select i.experience, n.exp_requis, i.xp_hebdo from opora2016.internaute i
join opora2016.niveau n on i.num_niveau = n.num_niveau
where id_facebook = :idfb");
$statment->bindValue(":idfb", $_GET["idfacebook"]);
$statment->execute();

echo json_encode($statment->fetch(PDO::FETCH_ASSOC));
