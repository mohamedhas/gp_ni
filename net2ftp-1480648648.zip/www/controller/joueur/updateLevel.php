<?php

function updateLevel($id){
	include "../../config/db.php";
	
	
	/////////// RECUPERATION EXPERIENCE REQUISE //////////////
	$str1 = $db->prepare("
		select (n.exp_requis - i.experience), n.requis as diff_experience from opora2016.internaute i
						join opora2016.niveau n on i.num_niveau = n.num_niveau
						where id_facebook =:id_facebook");
	$str1->bindValue(":id_facebook",$id);

	$str1->execute();
	$row1 = $str1->fetch(PDO::FETCH_ASSOC);
	if($row1["diff_experience"] <= 0)		//Experience > requis => Passage niveau +1
	{
		// echo "update opora2016.internaute set num_niveau = num_niveau +1 where id_facebook=". $id;
		$rqt = $db->prepare("update opora2016.internaute set num_niveau = num_niveau +1 where id_facebook=:id_facebook");
		$rqt->bindValue(":id_facebook",$id);
		$rqt->execute();
		

		$rqt3 = $db->prepare("insert into opora2016.internaute_possede_planete(id_facebook, id_planete) 
								values(:id_facebook, (select num_niveau from opora2016.internaute where id_facebook = :id_facebook) )");
		$rqt3->bindValue(":id_facebook",$id);
		$rqt3->execute();

	}
	if($row1["diff_experience"] > $row1['requis'])		//Experience < requis => Passage niveau -1 (sanctions)
	{
		// echo "update opora2016.internaute set num_niveau = num_niveau -1 where id_facebook=". $id;
		$rqt = $db->prepare("update opora2016.internaute set num_niveau = num_niveau -1 where id_facebook=:id_facebook");
		$rqt->bindValue(":id_facebook",$id);
		$rqt->execute();
		

		$rqt3 = $db->prepare("insert into opora2016.internaute_possede_planete(id_facebook, id_planete) 
								values(:id_facebook, (select num_niveau from opora2016.internaute where id_facebook = :id_facebook) )");
		$rqt3->bindValue(":id_facebook",$id);
		$rqt3->execute();

	}
}