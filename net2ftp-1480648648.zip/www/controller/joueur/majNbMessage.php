<?php 
session_start();
include_once "../../config/db.php";
$id_facebook = $_POST["id_facebook"];


	$str = $db->prepare("update opora2016.internaute set nb_messages = nb_messages + 1 where id_facebook=:id_facebook");
	$str->bindValue(":id_facebook",$id_facebook);
	$str->execute();
	

echo json_encode(true);
