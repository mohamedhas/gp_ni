<?php

include_once "../../config/db.php";


$statment = $db->prepare("select * from opora.recompense where id_facebook = :idfb");
$statment->bindValue(":idfb", $_GET['idfacebook']);
$statment->execute();

//------------------------------------
//------------------------------------
//2016

$statment = $db->prepare("select * from opora2016.recompense where id_receveur = :idfb");
$statment->bindValue(":idfb", $_GET['idfacebook']);
$statment->execute();

echo json_encode($statment->fetchAll(PDO::FETCH_ASSOC));
