<?php

include_once "../../config/db.php";


$statment = $db->prepare("select * from opora.titre where id_titre = :idtitre");
$statment->bindValue(":idtitre", $_GET["idtitre"]);
$statment->execute();

//--------------------------------------
//--------------------------------------
//2016
// Verifier utilité dans les js

$statment = $db->prepare("select * from opora2016.titre where id_titre = :idtitre");
$statment->bindValue(":idtitre", $_GET["idtitre"]);
$statment->execute();

echo json_encode($statment->fetchAll(PDO::FETCH_ASSOC));

