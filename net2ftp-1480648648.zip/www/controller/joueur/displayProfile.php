<?php
include_once "../../config/db.php";

if(isset($_GET["idfacebook"])){

$statment = $db->prepare("select *, n.exp_requis, t.libelle_titre, d.libelle_dept from opora2016.internaute i
join opora2016.departement d on d.id_dept = i.id_dept
join opora2016.niveau n on n.num_niveau = i.num_niveau 
left join opora2016.titre t on t.id_titre = i.id_titre where id_facebook = :idfb");
$statment->bindValue(':idfb', $_GET["idfacebook"]);
$statment->execute();

echo json_encode($statment->fetchAll(PDO::FETCH_ASSOC));
}
else{
echo "no";
}



