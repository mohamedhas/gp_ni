<?php 

function addXP($id){
	
	include "../../config/db.php";
	include_once("updateLevel.php");
	
	$bonus = $db->prepare("select * from opora2016.planete p join opora2016.internaute_possede_planete ipp on ipp.id_planete = p.id_planete where ipp.id_facebook=:id_facebook");
	$bonus->bindValue(":id_facebook", $id);
	$bonus->execute();
	$bonus_xp = 1;
	foreach($bonus->fetchAll(PDO::FETCH_ASSOC) as $unBonus)
	{
		$bonus_xp += $unBonus['bonus_xp'];
	}
	
	$str = $db->prepare("
		update opora2016.internaute set experience = experience + :bonus_xp,
		xp_hebdo = xp_hebdo + :bonus_xp
		where id_facebook =:id_facebook");
	$str->bindValue(":id_facebook",$id);
	$str->bindValue(":bonus_xp",$bonus_xp);
	$str->execute();
	updateLevel($id);
}