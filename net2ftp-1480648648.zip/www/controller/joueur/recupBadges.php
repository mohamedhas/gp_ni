<?php

include_once "../../config/db.php";


$statment = $db->prepare("select b.path_badge, b.nom_badge, b.desc_badge from opora.badge b join opora.associe_a_un a on a.id_badge = b.id_badge join opora.internaute i on i.id_facebook = a.id_facebook where a.id_facebook = :idfb");
$statment->bindValue(":idfb", $_GET['idfacebook']);
$statment->execute();

//---------------------------------
//---------------------------------
//2016
//Possible de retirer 2eme join
$statment = $db->prepare("select b.photo_badge, b.libelle_badge, b.description_badge from opora2016.badge b 
join opora2016.possede_badge pb on pb.id_badge = b.id_badge 
join opora2016.internaute i on i.id_facebook = pb.id_facebook where i.id_facebook = :idfb");
$statment->bindValue(":idfb", $_GET['idfacebook']);
$statment->execute();

echo json_encode($statment->fetchAll(PDO::FETCH_ASSOC));
