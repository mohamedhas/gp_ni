﻿<?php 

ini_set('display_errors','on');
error_reporting(E_ALL);
include_once "../../config/db.php";

$id = $_GET['idfacebook'];

$st = $db->prepare("select libelle_dept, num_niveau, nom, prenom, pseudo, est_eleve, total_points, count(r.id_facebook) \"nb_sauvetages\", xp_hebdo,
					experience, libelle_titre, description   from opora2016.internaute i
					join opora2016.titre t on t.id_titre = i.id_titre
					join opora2016.departement d on d.id_dept = i.id_dept
					left join opora2016.reponse r on r.id_facebook = i.id_facebook
					where i.id_facebook = :idfb
					group by libelle_dept, num_niveau, nom, prenom, pseudo, est_eleve, total_points, xp_hebdo,
					experience, libelle_titre, description");
$st->bindValue(":idfb", $id);
$st->execute();
$infos = $st->fetch(PDO::FETCH_ASSOC);

$dept = $infos['libelle_dept'];
$niveau =  $infos['num_niveau'];
$nom =  $infos['nom'];
$prenom =  $infos['prenom'];
$pseudo = $infos['pseudo'];
$statut =  $infos['est_eleve'];
$points = $infos['total_points'];
$sauvetages =  $infos['nb_sauvetages'];
$kmHebdo =  $infos['xp_hebdo'];
$kmGeneral =  $infos['experience'];
$titre =  $infos['libelle_titre'];
$descr =  $infos['description'];



$st = $db->prepare("select * from opora2016.badge b join opora2016.possede_badge pb on pb.id_badge = b.id_badge where pb.id_facebook = :idfb");
$st->bindValue(":idfb", $id);
$st->execute();
$mes_badges = $st->fetchAll(PDO::FETCH_ASSOC);


?>

<div id="lightbox">
	<div id="profile_stats">
		<div style="background-color: #2980b9" class="titre_div_profile">INFORMATIONS
		<div id="croix">X</div>
		</div>
		<div id="box_img">
			<img src="https://graph.facebook.com/<?php echo $id;?>/picture?type=large" class="profilePicture">
			<div id="dept_stats"><?php echo $dept ;?></div>
		</div>
		<div id="stats">
			<div id="niveau_stats">Niveau <?php echo $niveau ;?><br></div>
			<div id="infos_profile">
				<div id="pres_stats">Nom : <br>Prénom : <br> Pseudo : <br> Statut : <br> Stellars : <br> Nb de sauvetage : <br> Kilomètres parcourus :  <br> nombre de planète conquise :<br></div>
				<div id="valeurs_stats"><?php echo $nom ;?><br><?php echo $prenom ;?><br><?php echo $pseudo ;?><br><?php echo $statut ;?><br><?php echo $points ;?><br><?php echo $sauvetages ;?><br/><?php echo $kmGeneral ;?></br><?php echo $niveau ;?></div>
			</div>
				<button id="affichePlanete">Voir toutes les planètes conquises</button>
		</div>
	</div>
	<div id="profile_titre">
		<img src="./badges/cog_profile_titre.png" class="param_titre">
		<div style="background-color: #2980b9" class="titre_div_profile">TITRE</div>
		<div id="contenu_titre"><?php echo $titre ;?></div>
	</div>
	<div id="profile_badge">
		<div style="background-color: #2980b9" class="titre_div_profile">BADGES</div>
		<div id="contenu_badge">
		<?php 
		foreach($mes_badges as $badge)
		{
			echo '<span><img class="badge_profil" src="'.$badge['photo_badge'].'"><br>'.$badge['libelle_badge'].'</span>';
		}?>
		</div>
	</div>
	<div id="profile_desc">
		<img src="./badges/cog_profile_titre.png" class="param_titre_left">
		<div style="background-color: #2980b9" class="titre_div_profile">
			DESCRIPTION
			
		</div>
		<div id="contenu_desc"><?php echo $descr ;?></div>
	</div>
</div>