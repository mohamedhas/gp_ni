<?php

include_once "../../config/db.php";
//header('Content-Type: image/png');


$prenom = $_GET["prenom_internaute"];
$nom = $_GET["nom_internaute"];
$pseudo = $_GET["pseudo_internaute"];
$id = $_GET["id_facebook"];
$dept = $_GET["dept_internaute"];


if(checkPseudoLibre($pseudo))
{
$url = urlencode("http://graph.facebook.com/" . $id . "/picture");
$url2 = "http://graph.facebook.com/" . $id . "/picture?type=large";

$statment = $db->prepare("insert into opora2016.internaute(id_facebook, nom, prenom, pseudo, id_titre, id_dept) values(:id_facebook, :nom_internaute, :prenom_internaute, :pseudo, 1, :dept)");
$statment->bindValue(":prenom_internaute",$prenom);
$statment->bindValue(":nom_internaute", $nom);
$statment->bindValue(":pseudo", $pseudo);
$statment->bindValue(":id_facebook", $id);
$statment->bindValue(":dept", $dept);
$statment->execute();


echo json_encode(true);
}
else
{
 echo json_encode(false);
}

function checkPseudoLibre($pseudo) 
{ 
  
 ini_set('display_errors', 'On');
 error_reporting(-1);

  include "../../config/db.php";

  $statment = $db->prepare("select pseudo from opora2016.internaute where pseudo = '". $pseudo ."'");
  $statment->execute();
  $statment = $statment->fetchAll(PDO::FETCH_ASSOC);
  if(count($statment) > 0){
    return(false);
  }
  else{
    return(true);
  }
}	