					<table class="home_profile">
				  <!-- On affiche les informations de l\utilisateur -->
						<tr>
							<td id="photo_profil" rowspan='2'>
									<img id="photo_once" src="https://scontent.xx.fbcdn.net/v/t1.0-1/p130x130/10537422_10202048144999985_2728680047335562499_n.jpg?oh=84febc029d93348958083161f529e6a9&amp;oe=5883E844">

							</td>
							<td id="info_profile_home"><!--<div id="right_profile"></div>-->
								<div class="progressbar-back">
									<div class="progressbar-front"></div>
								</div>
							</td>
						</tr>
							
							<!--
							   <div class="progress-pie-chart" data-percent="43">
								<div class="ppc-progress">
								  <div class="ppc-progress-fill"></div>
								</div>
								<div class="ppc-percents">
								  <div class="pcc-percents-wrapper">
									<span>%</span>
								  </div>
								</div>
							  </div>
							  -->
						<tr>
							<td>
							<div id="level">Niveau 4</div><div id="name">Marc</div><div id="titre"> - V�t�ran</div>
							</td>
						</tr>
					</table>ont"></div>
								</div> <p><?php echo $ratio*100 ;?> %</p>
							</td>
						</tr>
							
							<!--
							   <div class="progress-pie-chart" data-percent="43">
								<div class="ppc-progress">
								  <div class="ppc-progress-fill"></div>
								</div>
								<div class="ppc-percents">
								  <div class="pcc-percents-wrapper">
									<span>%</span>
								  </div>
								</div>
							  </div>
							  -->
						<tr>
							<td>
							<div id="level">Niveau  <?php echo $level ;?> </div><div id="name"> <?php echo $prenom ;?> </div><div id="titre"> -  <?php echo $titre ;?> </div>
							</td>
						</tr>
					</table>
<?php 
}
?>