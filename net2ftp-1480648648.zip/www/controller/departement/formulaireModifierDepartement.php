<?php 
include_once "../../config/db.php";

$id = $_POST['id'];

$statement = $db->prepare("select * from opora2016.departement where id_dept = $id");
$statement->execute();
$dept = $statement->fetch(PDO::FETCH_ASSOC);

$statement = $db->prepare("select * from opora2016.categorie");
$statement->execute();
$categories = $statement->fetchAll(PDO::FETCH_ASSOC);

$statement = $db->prepare("select * from opora2016.categorie_appartient_a_dept where id_dept = $id");
$statement->execute();
$return = $statement->fetchAll(PDO::FETCH_ASSOC);
for($i = 0; $i < count($return); $i++)
{
	$mes_categories[$i] = $return[$i]['id_categorie'];
}
?>

<section id="contenu">
	<img src="icon/backButton.png" class="backButton">
	<div style="background-color: #" id="div_titre">
		<h1 style="background-color: #" class="titre_main">MODIFIER UN DEPARTEMENT</h1>
	</div>
	<div class="divNewBadge">
		<span class="libelle_departement"><label> Nom </label></span>
		<input id="nom_departement" name="nom_departement" class="validate[required,custom[onlyLetter],length[0,100]] feedback-input" type="text" value='<?php echo $dept['libelle_dept']; ?>' />
		<br>
		<span class="color_departement"><label> Couleur </label></span>
		<input id="color_departement" name="color_departement" class="validate[required,custom[onlyLetter],length[0,100]] feedback-input" type="color" value='<?php echo $dept['couleur_dept']; ?>' />
		<br>
		<span class="preview"><label> Visuel : </label></span>
		<span id="preview_departement"><?php echo '<p class="dept_libelle" style="color:'.$dept['couleur_dept'].'">'.$dept['libelle_dept'] .'</p>'; ?></span>
		<br>
		<span class="listeCat"><label> Categories associées </label>
		<?php 
		foreach($categories as $cat){
			echo "<input type='checkbox' name='dept' ". (in_array($cat['id_categorie'], $mes_categories)?'checked':'') ." id='". $cat['id_categorie'] ."' class='checkCat' /><label for='". $cat['id_categorie'] ."'>".$cat['libelle_categorie'] . "</label></br>";
		}?>
		</span>
		<br/>
		<button class="btn_gestionDepartement"> Modifier </button>
	</div>
</section>