<?php 

include "../../config/db.php";

$nom = $_POST['nom'];
$categories = $_POST['listeCategories'];
$couleur = $_POST['couleur'];


$statement = $db->prepare("insert into opora2016.departement(libelle_dept, couleur_dept) values ('$nom', '$couleur') returning id_dept");
$statement->execute();
$id = $statement->fetch()[0];

foreach($categories as $cat)
{
	$statement2 = $db->prepare("insert into opora2016.categorie_appartient_a_dept(id_categorie, id_dept) values ($id, $cat)");
	$statement2->execute();
}


?>