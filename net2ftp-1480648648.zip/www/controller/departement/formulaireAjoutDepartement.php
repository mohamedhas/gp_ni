<?php 
include_once "../../config/db.php";

$statement = $db->prepare("select * from opora2016.categorie");
$statement->execute();
$categories = $statement->fetchAll(PDO::FETCH_ASSOC);
?>

<section id="contenu">
	<img src="icon/backButton.png" class="backButton">
	<div style="background-color: #" id="div_titre">
		<h1 style="background-color: #" class="titre_main">AJOUTER UN DEPARTEMENT</h1>
	</div>
	<div class="divNewBadge">
		<span class="libelle_departement"><label> Nom </label></span>
		<input id="nom_departement" name="nom_departement" class="validate[required,custom[onlyLetter],length[0,100]] feedback-input" type="text" value='' />
		<br>
		<span class="color_departement"><label> Couleur </label></span>
		<input id="color_departement" name="color_departement" class="validate[required,custom[onlyLetter],length[0,100]] feedback-input" type="color" value='' />
		<br>
		<span class="preview"><label> Visuel : </label></span>
		<span id="preview_departement"></span>
		<br>
		<span class="listeCat"><label> Categories associés </label>
		<?php 
		foreach($categories as $cat){
			echo "<input type='checkbox' name='dept' id='". $cat['id_categorie'] ."' class='checkCat' /><label for='". $cat['id_categorie'] ."'>".$cat['libelle_categorie'] . "</label></br>";
		}?>
		</span>
		<br/>
		<button class="btn_gestionDepartement"> Ajouter </button>
	</div>
</section>