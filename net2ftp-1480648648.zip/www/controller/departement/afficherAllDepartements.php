<?php 
include_once "../../config/db.php";

$statement = $db->prepare("select * from opora2016.departement");
$statement->execute();
$departements = $statement->fetchAll(PDO::FETCH_ASSOC);

?>
<section id="contenu">
	<img src="icon/backButton.png" class="backButton">
	<div style="background-color: #" id="div_titre">
		<h1 style="background-color: #" class="titre_main">LES DEPARTEMENTS</h1>
	</div>
	<div class='allDepartements'>
		<table>
		<?php 
                $i = 0;
		foreach($departements as $dept)
		{
			if($i == 0) {echo "<tr>";}

			echo "<td><span class='dept_libelle' style='color:".$dept['couleur_dept']."'>". $dept['libelle_dept'] ."</span></td>";
		        echo "<td><button data-id='". $dept['id_dept'] ."' class='modifier'>Modifier</button><button data-id='". $dept['id_dept'] ."' class='suppress'>Supprimer</button></td>";

			if($i == 2) {echo "</tr>";}
                        $i++;
                        if($i == 3){$i = 0;}
		}?>
		</table>
	</div>
</section>