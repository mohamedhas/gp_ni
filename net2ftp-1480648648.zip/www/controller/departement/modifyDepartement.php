<?php
//session_start();
include_once "../../config/db.php";

$id = $_POST['id'];
$nom = $_POST['nom'];
$categories = $_POST['listeCategories'];
$couleur = $_POST['couleur'];


$statement = $db->prepare("update opora2016.departement set libelle_dept='$nom' set couleur_dept = '$couleur' where id_dept = $id");
$statement->execute();

$del = $db->prepare("delete from opora2016.categorie_appartient_a_dept where id_dept=:id_dept");
$del->bindValue(":id_dept",$id);
$del->execute();


foreach($categories as $cat)
{
	$statement2 = $db->prepare("insert into opora2016.categorie_appartient_a_dept(id_categorie, id_dept) values ($cat, $id)");
	$statement2->execute();
}
