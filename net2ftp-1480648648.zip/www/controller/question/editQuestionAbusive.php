<?php
include_once "../../config/db.php";

$id_question = $_POST["id_question"];
$valeur_question = $_POST["valeur_question"];



$statment = $db->prepare("update opora2016.question set texte =:valeur_question
						 where id_question=:id_question");
$statment->bindValue(":id_question", $id_question);
$statment->bindValue(":valeur_question", $valeur_question);
$statment->execute();

echo json_encode(true);



