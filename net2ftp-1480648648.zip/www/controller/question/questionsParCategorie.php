<?php 

ini_set('display_errors','on');
error_reporting(E_ALL);

include "../../config/db.php";
include "allQuestionsByDate.php";

$id_cat = $_POST['id_categorie'];

$st = $db->prepare("select distinct (q.id_matiere, id_question), * from opora2016.question q
					join opora2016.matiere m on m.id_matiere = q.id_matiere
					join opora2016.matiere_appartient_a_categorie maac on maac.id_matiere = m.id_matiere
					join opora2016.categorie c on c.id_categorie = maac.id_categorie
					where c.id_categorie = :categorie
					order by (q.id_matiere, id_question)
");
$st->bindValue(":categorie", $id_cat);
$st->execute();
$questions = $st->fetchAll(PDO::FETCH_ASSOC);

echo '<div id="contenu_div_index">
            <ul id="liste">';

//var_dump($questions);
foreach($questions as $question)
{
     echo '<li class="myquestion" data-question="'.$question['id_question'].'">
                    <table class="contenu_question">
                        <tbody>
                            <tr>
								<td rowspan="2" class="profil_question">
									<img src="https://graph.facebook.com/'. $question['id_facebook'] . '/picture?type=large" class="imageQuestion">
								</td>
								<td class="titre">
									'. $question['libelle_matiere'] .' : '. $question['titre'] . '
								</td>
								<td rowspan="2" class="nbreponse">
									Nombre de reponses : '. nbResponsesByQuestion($question['id_question']) .'
								</td>
							</tr>
							<tr>
								<td class="dept_libelle_'. $question['libelle_dept'] . '">
									'. $question['libelle_dept'] .'
								</td>
							</tr>
							<tr>
								<td class="date">
									'. $question['date_post'] . '
								</td>
							</tr>
						</tbody>
					</table>
				</li>';
}

echo '</ul></div>';
