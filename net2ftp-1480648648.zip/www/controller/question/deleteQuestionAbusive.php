<?php
session_start();
include_once "../../config/db.php";
include_once "../joueur/looseXP.php";
$id_question = $_POST["id_question"];


$rep = $db->prepare("select id_facebook from opora2016.question where id_question = :question");
$rep->bindValue(":question", $id_reponse);
$rep->execute();
$idfb = $rep->fetch(PDO::FETCH_ASSOC)['id_facebook'];

looseXP($idfb);


$statment = $db->prepare("delete from opora2016.a_vote_pour_reponse
						  where id_reponse in (select id_reponse from opora2016.reponse where id_question=:id)");
$statment->bindValue(":id", $id_question);
$statment->execute();

$statment = $db->prepare("delete from opora2016.reponse
						  where id_question=:id");
$statment->bindValue(":id", $id_question);
$statment->execute();


$statment = $db->prepare("delete from opora2016.question
						  where id_question=:id");
$statment->bindValue(":id", $id_question);
$statment->execute();

echo "OK";