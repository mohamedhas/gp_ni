<?php 

$image = $_POST['image_utilisateur'];
$matiere = $_POST['matiere'];
$dept = $_POST['departement'];
$titre = $_POST['titre'];
$nbr_rep = $_POST['nombre_reponse'];
$date = $_POST['date'];

echo '<table class="contenu_question">'.'<tr><td rowspan="2" class="profil_question">' . $image . '</td><td class="titre">'. $matiere . ' : ' . $titre . '</td><td rowspan="2" class = "nbreponse">Nombre de reponses : ' . $nbr_rep . '</td></tr>'.'<tr><td class="dept_libelle_'.$dept.'">' . $dept . '</td></tr>'.'<tr><td class="date">' . $date . '</td></tr></table>';
?>