<?php

/*$statment = $db->prepare("
select *
from opora2016.question q
left join opora2016.internaute i on q.id_facebook=i.id_facebook
left join opora2016.matiere m on q.id_matiere = m.id_matiere
join opora2016.matiere_appartient_a_categorie mc on m.id_matiere = mc.id_matiere
left join opora2016.departement d on d.id_dept = q.id_dept
order by q.id_question desc limit 10");
$statment->execute();

echo json_encode($statment->fetchAll(PDO::FETCH_ASSOC));
*/
function allQuestionsByDate($page)
{
$questions_by_page = 10;
$offset = $questions_by_page * ($page-1);
include_once "../../config/db.php";

$statment = $db->prepare("
	select *, case (select count(*) from opora2016.reponse where id_question = q.id_question) when 0 then q.date_post
	else (select MAX(date_post) from opora2016.reponse where id_question = q.id_question)
	end 
	as \"last\"
	from opora2016.question q
	join opora2016.internaute i on q.id_facebook=i.id_facebook
	join opora2016.matiere m on q.id_matiere = m.id_matiere
	join opora2016.matiere_appartient_a_categorie mc on m.id_matiere = mc.id_matiere
	left join opora2016.departement d on d.id_dept = q.id_dept
	order by last desc limit ".$questions_by_page." offset ".$offset);
$statment->execute();
return $statment->fetchAll(PDO::FETCH_ASSOC);
}

function nbResponsesByQuestion($id)
{
include "../../config/db.php";


$statment = $db->prepare(" select count(*) from opora2016.reponse where id_question = ".$id);
$statment->execute();

return $statment->fetch()[0];

}
function nbQuestions(){
	
	include "../../config/db.php";


	$statment = $db->prepare("select count(*) from opora2016.question");
	$statment->execute();

	return $statment->fetch()[0];
}