<?php 

session_start();
include_once "../../config/db.php";
$id_question = $_POST["id_question"];

	
		$str = $db->prepare("
		select q.texte, r.texte from opora2016.question q 
		join oporq2016.reponse r on q.id_question = r.id_question
		where q.id_question = ".$id_question);

	$str->execute();

echo json_encode($str->fetchAll());