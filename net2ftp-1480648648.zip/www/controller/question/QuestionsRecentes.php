<?php
include_once "../../config/db.php";

$query = $db->prepare("select * from opora.question q join categorie c on q.id_categorie = c.id_categorie join date d on q.id_date = d.id_date order by date DESC limit 10");
$query->execute();

//-------------------------------------------------------
//-------------------------------------------------------
//2016

//Verifier de son utilité.......

$query = $db->prepare("select * from opora2016.question q
join opora2016.categorie c on q.id_categorie = c.id_categorie 
order by q.date_post DESC limit 10");
$query->execute();

echo json_encode($query->fetchAll());




