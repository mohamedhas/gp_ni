<?php
include_once "../../config/db.php";

$id_question = $_POST["id_question"];
$valeur_reponse = $_POST["valeur_reponse"];


//!\\ Fichier identique a modifierMaQuestion.php

$statment = $db->prepare("update opora2016.question set texte =:valeur_question
						 where id_question=:id_question");
$statment->bindValue(":id_question", $id_question);
$statment->bindValue(":valeur_question", $valeur_reponse);
$statment->execute();

echo json_encode(true);
