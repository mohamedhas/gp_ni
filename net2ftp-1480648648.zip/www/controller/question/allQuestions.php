<?php
include_once "../../config/db.php";


$statment = $db->prepare("select * from opora2016.question q
join opora2016.matiere m on m.id_matiere = q.id_matiere
join opora2016.matiere_appartient_a_categorie mc on mc.id_matiere = m.id_matiere
join opora2016.categorie_appartient_a_dept cd on cd.id_dept = mc.id_dept
join opora2016.departement d on d.id_dept = cd.id_dept 
order by id_question desc");
$statment->execute();



echo json_encode($statment->fetchAll(PDO::FETCH_ASSOC));
