<?php
session_start();
include_once "../../config/db.php";


if (isset($_POST["id_question"]) && isset($_POST["id_facebook"])) {

	$id_question = $_POST["id_question"];
	$id_facebook = $_POST["id_facebook"];


	$statment = $db->prepare("insert into opora.question_abusive(id_question, id_facebook)
								values (:idque, :idface)");
	$statment->bindValue(":idque", $id_question);
	$statment->bindValue(":idface", $id_facebook);
	$statment->execute();
	
	//------------------------------------------
	//------------------------------------------
	//2016
	
	$statment = $db->prepare("update opora2016.question set id_facebook_declare_abusive = :idface
								where id_question = :idque");
	$statment->bindValue(":idque", $id_question);
	$statment->bindValue(":idface", $id_facebook);
	$statment->execute();


	echo json_encode(true);

}
else 
	echo json_encode(false);


