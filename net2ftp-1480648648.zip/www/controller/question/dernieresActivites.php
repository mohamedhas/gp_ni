<?php 

ini_set('display_errors','on');
error_reporting(E_ALL);

$idfb = $_POST['id_facebook'];

if(isset($_POST['page'])) $page = $_POST['page'];
else $page = 1;

$questions = DernieresActivites($page, $idfb);
$nbPages = ceil(nbQuestions($idfb)/10); //10 Questions by pages 
$mesNouvelles = getNewActivity($idfb);
echo '<div id="contenu_div_index">
            <ul id="liste">';
foreach($questions as $question)
{
	
     echo '<li class="myquestion'. (in_array($question['id_question'], $mesNouvelles)?' new_question':'') .'" data-question="'.$question['id_question'].'">
                    <table class="contenu_question">
                        <tbody>
                            <tr>
								<td rowspan="2" class="profil_question">
									<img src="https://graph.facebook.com/'. $question['id_facebook'] . '/picture?type=large" class="imageQuestion">
								</td>
								<td class="titre">
									'. $question['libelle_matiere'] .' : '. htmlentities($question['titre'], ENT_SUBSTITUTE) . '
								</td>
								<td rowspan="2" class="nbreponse">
									Nombre de reponses : '. nbResponsesByQuestion($question['id_question']) .'
								</td>
							</tr>
							<tr>
								<td class="dept_libelle" style="color:'. $question['couleur_dept']. '">
									'. $question['libelle_dept'] .'
								</td>
							</tr>
							<tr>
								<td class="date">
									'. $question['date_post'] . '
								</td>
							</tr>
						</tbody>
					</table>
				</li>';
}

// echo '
// <div id="pagination">';
// if($page != 1) echo '<span id="precedent">Precedent</span>';
// for($i = 0; $i < $nbPages; $i+=1){
	// if(abs($i - $nbPages) < 3 || $i < 3 || abs($i-$page) < 3){
		// echo " <span id='". ($i+1) ."'"; 
		// if($i+1 == $page) echo 'class="selected"';
		// echo ' > '. ($i+1) ."</span>";
	// }
// }
// if($page != $nbPages) echo '<span id="suivant">Suivant</span>';
// echo '</div>';
paginate($nbPages, $page);
echo '</ul></div>';


function DernieresActivites($page, $id){
	
	$questions_by_page = 10;
	$offset = $questions_by_page * ($page-1);
	include_once "../../config/db.php";

	$statment = $db->prepare("
	select *, case (select count(*) from opora2016.reponse where id_question = q.id_question) when 0 then q.date_post
	else (select MAX(date_post) from opora2016.reponse where id_question = q.id_question)
	end 
	as \"last\"
	from opora2016.question q
	join opora2016.internaute i on q.id_facebook=i.id_facebook
	join opora2016.matiere m on q.id_matiere = m.id_matiere
	join opora2016.matiere_appartient_a_categorie mc on m.id_matiere = mc.id_matiere
	left join opora2016.departement d on d.id_dept = q.id_dept
	where id_question in (
		select id_question from opora2016.reponse where id_facebook = :idfb
	) 
	or q.id_facebook = :idfb
	order by last desc limit ".$questions_by_page." offset ".$offset);
	$statment->bindValue(':idfb', $id);
	$statment->execute();
	return $statment->fetchAll(PDO::FETCH_ASSOC);
}

function nbResponsesByQuestion($id)
{
	include "../../config/db.php";


	$statment = $db->prepare(" select count(*) from opora2016.reponse where id_question = ".$id);
	$statment->execute();

	return $statment->fetch()[0];

}
function nbQuestions($id){
	include "../../config/db.php";

	
	$statment = $db->prepare("select count(*) from opora2016.question 
			where id_question in (
			select id_question from opora2016.reponse where id_facebook = :idfb
			) 
			or id_facebook = :idfb");
	$statment->bindValue(':idfb', $id);
	$statment->execute();
	

	return $statment->fetch()[0];
}

function paginate($total, $current, $adj=3) {
	
	// Initialisation des variables
	$prev = $current - 1; // numéro de la page précédente
	$next = $current + 1; // numéro de la page suivante
	$penultimate = $total - 1; // numéro de l'avant-dernière page
	$pagination = ''; // variable retour de la fonction : vide tant qu'il n'y a pas au moins 2 pages
 
	if ($total > 1) {
		// Remplissage de la chaîne de caractères à retourner
		$pagination .= "<div id=\"pagination\">\n";
 
		/* =================================
		 *  Affichage du bouton [précédent]
		 * ================================= */
		if ($current != 1) {
			// la page courante est supérieure à 1, le bouton renvoie sur la page dont le numéro est immédiatement inférieur
			$pagination .= "<span id='{$prev}'>◄</span>";
		}
		// } else {
			// dans tous les autres, cas la page est 1 : désactivation du bouton [précédent]
			// $pagination .= '<span class="inselected">◄</span>';
		// }
 
		/**
		 * Début affichage des pages, l'exemple reprend le cas de 3 numéros de pages adjacents (par défaut) de chaque côté du numéro courant
		 * - CAS 1 : il y a au plus 12 pages, insuffisant pour faire une troncature
		 * - CAS 2 : il y a au moins 13 pages, on effectue la troncature pour afficher 11 numéros de pages au total
		 */
 
		/* ===============================================
		 *  CAS 1 : au plus 12 pages -> pas de troncature
		 * =============================================== */
		if ($total < 7 + ($adj * 2)) {
			
			for ($i=1; $i<=$total; $i++) {
				if ($i == $current) {
					// Le numéro de la page courante est mis en évidence (cf. CSS)
					$pagination .= "<span class=\"selected\">{$i}</span>";
				} else {
					// Les autres sont affichées normalement
					$pagination .= "<span id=\"{$i}\">{$i}</span>";
				}
			}
		}
		/* =========================================
		 *  CAS 2 : au moins 13 pages -> troncature
		 * ========================================= */
		else {
			/**
			 * Troncature 1 : on se situe dans la partie proche des premières pages, on tronque donc la fin de la pagination.
			 * l'affichage sera de neuf numéros de pages à gauche ... deux à droite
			 * 1 2 3 4 5 6 7 8 9 … 16 17
			 */
			if ($current < 2 + ($adj * 2)) {
				for ($i = 1; $i < 4 + ($adj * 2); $i++) {
					if ($i == $current) {
						$pagination .= "<span class=\"selected\">{$i}</span>";
					} else {
						$pagination .= "<span id=\"{$i}\">{$i}</span>";
					}
				}
 
				// ... pour marquer la troncature
				$pagination .= '&hellip;';
 
				// et enfin les deux derniers numéros
				$pagination .= "<span id=\"{$penultimate}\">{$penultimate}</span>";
				$pagination .= "<span id=\"{$total}\">{$total}</span>";
			}
			/**
			 * Troncature 2 : on se situe dans la partie centrale de notre pagination, on tronque donc le début et la fin de la pagination.
			 * l'affichage sera deux numéros de pages à gauche ... sept au centre ... deux à droite
			 * 1 2 … 5 6 7 8 9 10 11 … 16 17
			 */
			elseif ( (($adj * 2) + 1 < $current) && ($current < $total - ($adj * 2)) ) {
				// Affichage des numéros 1 et 2
				$pagination .= "<span id='1'>1</span>";
				$pagination .= "<span id='2'>2</span>";
				$pagination .= '&hellip;';
 
				// les pages du milieu : les trois précédant la page courante, la page courante, puis les trois lui succédant
				for ($i = $current - $adj; $i <= $current + $adj; $i++) {
					if ($i == $current) {
						$pagination .= "<span class=\"selected\">{$i}</span>";
					} else {
						$pagination .= "<span id=\"{$i}\">{$i}</span>";
					}
				}
 
				$pagination .= '&hellip;';
 
				// et les deux derniers numéros
				$pagination .= "<span id=\"{$penultimate}\">{$penultimate}</span>";
				$pagination .= "<span id=\"{$total}\">{$total}</span>";
			}
			/**
			 * Troncature 3 : on se situe dans la partie de droite, on tronque donc le début de la pagination.
			 * l'affichage sera deux numéros de pages à gauche ... neuf à droite
			 * 1 2 … 9 10 11 12 13 14 15 16 17
			 */
			else {
				// Affichage des numéros 1 et 2
				$pagination .= "<span id='1'>1</span>";
				$pagination .= "<span id=\"2\">2</span>";
				$pagination .= '&hellip;';
 
				// puis des neuf derniers numéros
				for ($i = $total - (2 + ($adj * 2)); $i <= $total; $i++) {
					if ($i == $current) {
						$pagination .= "<span class=\"selected\">{$i}</span>";
					} else {
						$pagination .= "<span id=\"{$i}\">{$i}</span>";
					}
				}
			}
		}
 
		/* ===============================
		 *  Affichage du bouton [suivant]
		 * =============================== */
		// if ($current == $total)
			// $pagination .= "<span class=\"inselected\">►</span>\n";
		// else
		if($current != $total)
			$pagination .= "<span id=\"{$next}\">►</span>\n";
 
		// Fermeture de la <div> d'affichage
		$pagination .= "</div>\n";
	}
 
	return ($pagination);
}
function getNewActivity($idfb){
	include "../../config/db.php";

	
	$statment = $db->prepare("select id_question from opora2016.notification where id_facebook = :idfb");
	$statment->bindValue(':idfb', $idfb);
	$statment->execute();
	

	return $statment->fetchAll(PDO::FETCH_ASSOC);
}