<?php
session_start();
include_once "../../config/db.php";
$id_question = $_POST["id_question"];


$statment = $db->prepare("delete from opora.question_abusive
						  where id_question=:id");
$statment->bindValue(":id", $id_question);
$statment->execute();

//-----------------------------------
//-----------------------------------
//2016
$statment = $db->prepare("update opora2016.question set id_facebook_declare_abusive = null
						  where id_question=:id");
$statment->bindValue(":id", $id_question);
$statment->execute();

