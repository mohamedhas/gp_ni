<?php

include_once "../../config/db.php";
include_once "../joueur/addXP.php";

if (isset($_POST["titre_question"]) &&
    isset($_POST["valeur_question"]) &&
    isset($_POST["id_matiere"]) &&
    isset($_POST["id_dept"])&& isset($_POST["id_facebook"]) ){

	$titre_question = $_POST["titre_question"];
	$valeur_question = $_POST["valeur_question"];
	$id_matiere = $_POST["id_matiere"];
	$id_dept = $_POST['id_dept'];
	$id_facebook =$_POST["id_facebook"];

	if(!empty($_POST["titre_question"]) && !empty($_POST["valeur_question"])){

	$statment = $db->prepare("insert into opora2016.question (titre, texte, 
						id_matiere, id_facebook, id_dept)
						values(:titre_question, :valeur_question, 
						:id_matiere, :id_facebook, :id_dept) ");
	$statment->bindValue(":titre_question", $titre_question);
	$statment->bindValue(":valeur_question", $valeur_question);
	$statment->bindValue(":id_matiere", $id_matiere);
	$statment->bindValue(":id_facebook", $id_facebook);
	$statment->bindValue(":id_dept", $id_dept);

	$statment->execute();
	
	addXP($id_facebook);
	echo json_encode(true);

} 
// else {

	// echo json_encode(array(
		// "error"=> false,
		// "message" => "Insertion de la question avortée"
	// ));


// }
}
