<?php
include_once "../../config/db.php";
	

$st= $db->prepare("delete * from opora2016.notification where id_question = :id_question;");
$st->bindValue(":id_question", $_POST["id_question"]);
$st->execute();



$statment = $db->prepare("delete from opora2016.reponse where id_question = :id_question;");
$statment->bindValue(":id_question", $_POST["id_question"]);
$statment->execute();

$st= $db->prepare("delete from opora2016.question where id_question = :id_question;");
$st->bindValue(":id_question", $_POST["id_question"]);
$st->execute();


	
	




 	