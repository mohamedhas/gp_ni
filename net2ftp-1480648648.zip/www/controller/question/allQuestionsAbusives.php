<?php 
session_start();
include_once "../../config/db.php";

		$str = $db->prepare("
		select * from opora2016.question a
		join opora2016.internaute i on a.id_facebook = i.id_facebook
		where id_facebook_declare_abusive is not null
		order by id_question");

	$str->execute();

echo json_encode($str->fetchAll());