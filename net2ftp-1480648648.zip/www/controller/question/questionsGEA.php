<?php 
session_start();
include_once "../../config/db.php";
	$str = $db->prepare("select q.id_question, q.id_moderateur, to_char(dates,'DD/MM/YYYY') as dates, m.libelle_matiere, q.id_matiere, q.id_dept, i.id_facebook, i.id_administrateur, q.valeur_question, q.titre_question, i.nom_internaute, i.prenom_internaute, i.nb_messages_internaute, i.situation_internaute, i.niveau_internaute, i.description_internaute, i.exp_internaute, i.points_internaute, i.photo_internaute, i.code_etat_internaute, i.mail_internaute, i.exp_requise, i.total_points_internaute, d.libelle_dept
	from opora.question q
left join opora.internaute i on q.id_facebook=i.id_facebook
left join opora.departement d on q.id_dept = d.id_dept
left join opora.matiere m on q.id_matiere = m.id_matiere
where q.id_dept = 1 
order by q.id_question desc");
	
	$str->execute();
	
	//Ne faire plus qu'un fichier avec questionINFO.php (plus general, modulaire,...)
	
	

echo json_encode($str->fetchAll(PDO::FETCH_ASSOC));
