<?php
session_start();
include_once "../../config/db.php";
$id_question = $_POST["id_question"];

	
	$str = $db->prepare("
		select *
						from opora2016.question q
						left join opora2016.internaute i on i.id_facebook=q.id_facebook
						left join opora2016.matiere m on m.id_matiere = q.id_matiere
						left join opora2016.titre t on t.id_titre=i.id_titre
						left join opora2016.niveau n on n.num_niveau = i.num_niveau

		where id_question = ".$id_question);

	$str->execute();
	

echo json_encode($str->fetchAll());
