<?php
include_once "../../config/db.php";

$id_matiere = $_POST['id_matiere'];

// $statment = $db->prepare("select to_char(dates,'DD/MM/YYYY') as date1, * from opora.question q join opora.internaute i on i.id_facebook=q.id_facebook 
	// join opora.matiere m on m.id_matiere = q.id_matiere
	// where m.id_matiere=:id");
// $statment->bindValue(":id", $id_matiere);
// $statment->execute();

//------------------------------------
//------------------------------------
//2016

// $statment = $db->prepare("select to_char(date_post,'DD/MM/YYYY') as date1, * from opora2016.question q 
// join opora2016.internaute i on i.id_facebook=q.id_facebook 
	// join opora2016.matiere m on m.id_matiere = q.id_matiere
	// where m.id_matiere=:id");
$statment = $db->prepare("select * from opora2016.question q 
where id_matiere =:id");
$statment->bindValue(":id", $id_matiere);
$statment->execute();

echo json_encode($statment->fetchAll());
