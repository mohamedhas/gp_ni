<?php 
session_start();
include_once "../../config/db.php";
$id_question = $_POST["id_question"];

	$str = $db->prepare("
		select count(r.id_reponse) as nbreponse from opora2016.question q
		join opora2016.reponse r on r.id_question = q.id_question
		where q.id_question = :id_question");
	$str->bindValue(":id_question",$id_question);
	
	$str->execute();
	
	

echo json_encode($str->fetchAll(PDO::FETCH_ASSOC));
