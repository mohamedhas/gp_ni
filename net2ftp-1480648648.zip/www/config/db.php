<?php

ini_set('display_errors', 'On');
error_reporting('e_all');

// $db = new PDO("pgsql:host=localhost;dbname=opora; port=5432","postgres","postgres");

 $db = new PDO("pgsql:host=oporaunisxopora2.postgresql.db;dbname=oporaunisxopora2; port=5432","oporaunisxopora2","Oporapp14");
/*
function db()
{return global $db;}*/