
var varCheckBadge=0;

//vérifier si un joueur poossède déja le badge en question
function CheckSiBadgeDejaObtenu(id_facebook, id_badge){
	//TODO tester si la personne possède déja le hf
	
	// $.post("controller/badges/checkBadge.php", { "id_facebook":id_facebook, "id_badge": id_badge}, function(verif) {
		
	// 	console.log("verif : "+verif);
		
	// 	varTemp = verif;
	// 	console.log("vartemp : "+varTemp);

	// }, "json");

	$.ajax({
            type   : 'POST',
            url    : 'controller/badges/checkBadge.php',
            data   : { "id_facebook":id_facebook, "id_badge": id_badge},
            async  : false,
            success: function(msg) {
                r = msg;
                //console.log("verif : "+r);
		
				varCheckBadge = r;
				//console.log("vartemp : "+varCheckBadge);
            }
        });

	//console.log("vartemp en dehors de l'ajax :"+varCheckBadge);
}

//attribuer un badge à un joueur
function AddBadgeToPlayer(id_facebook, id_badge){

	$.post("controller/badges/addBadgeToPlayer.php", { "id_facebook":id_facebook, "id_badge": id_badge}, function(verif) {

	}, "json");
}




function felicitations(nom_badge){
	
	if(arguments[1]){
		alert('VOUS AVEZ OBTENU LE BADGE "'+nom_badge+'", vous avez reçu le titre "'+arguments[1]+'" en guise de récompense');
	}else{
		alert('VOUS AVEZ GAGNE LE BADGE "'+nom_badge+'"');
	}
}

//Mettre dans cette fonction toutes les fonctions de badge qui se déclancheront quand on posera une question
function VerificationBadgesQuestions(id_facebook){
	console.log("lancement des badges quand on pose une question");
	badgePremiersPas(id_facebook);
	badgesNombreQuestionsPosees(id_facebook);
}



/*------------------------------------------------------------------------------*\
							Les differents badges
\*-----------------------------------------------------------------------------*/

function badgePremiersPas(id_facebook){
	CheckSiBadgeDejaObtenu(id_facebook, 6);
	if(varCheckBadge == 1){
		console.log("possède déja le badge premiers pas");
	}else{
		AddBadgeToPlayer(id_facebook, 6);
		felicitations("Premiers Pas");
	}
}



function badgeLoupe(id_facebook){
	CheckSiBadgeDejaObtenu(id_facebook, 5);
	if(varCheckBadge == 1){
		console.log("possède déja le badge Loupe");
		
	}else{
		AddBadgeToPlayer(id_facebook, 5);
		felicitations("Loupe");
	}
}


function badgesNombreQuestionsPosees(id_facebook){
	

	$.ajax({
        type   : 'POST',
        url    : 'controller/badges/badgesNombreQuestionsPosees.php',
        data   : {"id_facebook":id_facebook},
        //async  : false,
        success: function(nombreQuestions) {
            //r = msg;
            console.log(nombreQuestions);

            switch(nombreQuestions) {
			    case "10":
			    	console.log("Check switch case 10");
			        AddBadgeToPlayer(id_facebook, 7);
			        AddAchievementRewardToPlayer(id_facebook, 10);
			        felicitations("interrogateur", "interrogateur");
			        break;
			    case "100":
			        AddBadgeToPlayer(id_facebook, 8);
					AddAchievementRewardToPlayer(id_facebook, 11);
					felicitations("Chercheur", "Chercheur");
			        break;
			    case "500":
			        AddBadgeToPlayer(id_facebook, 9);
					AddAchievementRewardToPlayer(id_facebook, 12);
					felicitations("Inspecteur", "Inspecteur");
			        break;
			    case "1000":
			        AddBadgeToPlayer(id_facebook, 10);
					AddAchievementRewardToPlayer(id_facebook, 14);
					felicitations("Détective privé", "Détective privé");
			        break;
			}
	
			//varCheckBadge = r;
			//console.log("vartemp : "+varCheckBadge);
        }
    });

	//AddBadgeToPlayer(id_facebook, 7);
	//AddAchievementRewardToPlayer();
	//felicitations("interrogateur", "interrogateur");

}


