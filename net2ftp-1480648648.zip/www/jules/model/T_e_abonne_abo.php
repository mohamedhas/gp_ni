<?php 

class T_e_abonne_abo extends Model{
	protected $abo_id;
	protected $abo_pseudo;
	protected $abo_motpasse;
	protected $abo_mel;
	protected $abo_nom;
	protected $abo_prenom;
	protected $abo_adrligne1;
	protected $abo_adrligne2;
	protected $abo_cp;
	protected $abo_ville;
	protected $abo_etat;
	protected $pay_id;
	protected $pays;		//Classe PAYS
	protected $abo_latitude;
	protected $abo_longitude;
	protected $abo_indicatif;
	protected $abo_tel;
	protected $abo_aeroport;
	protected $avis;
	
	public function __construct($id = null)
	{
		parent::__construct($id);
		$this->pays = Pays::findById($this->pay_id);
		
	}
	public static function checkConnexion($mail, $pass){
		$query = "select abo_id from t_e_abonne_abo where abo_mel='".$mail."' and abo_motpasse='".$pass."'";
		$st = db()->prepare($query);
		$st->execute();
		if($st->rowCount() != 1)
			return false;
		else 
			return $st->fetch();
	}
	public function getAvis(){
		return Avis::findAllBy(get_class($this), $this->abo_id);
	}
	public function getNombreAvis(){
		return count($this->getAvis());
	}
}