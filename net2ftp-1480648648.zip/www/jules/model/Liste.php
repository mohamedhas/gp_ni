<?php 

class Liste extends Model{
	protected $id_facebook;
	protected $nom;
	protected $prenom;
	
	public function __construct($id = null)
	{
		parent::__construct($id);
	}
}