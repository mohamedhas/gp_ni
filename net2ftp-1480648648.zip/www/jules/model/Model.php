<?php

// Classe métier générique à accès BD automatique
// ToDo : non duplication des instances de classes liées
// ToDo : modèle hiérarchique

class Model {

	// Un appel au constructeur sans id créées une instance et une ligne dans la db
	public function __construct($id=null) {
		$class = get_class($this);
		$table = strtolower($class);
		$get_id = substr($class, -3)."_id";
		if ($id == null) {
			$st = db()->prepare("insert into opora2016.$table default values returning $get_id");
			//echo "insert into $table default values returning $get_id";
			$st->execute();
			$row = $st->fetch();
			$field = $get_id;
			$this->$field = $row[$field];
		} else {
			global $db;
			$st = $db->prepare("select * from opora2016.$table where nom='Bernes'");
			$st->execute();
			$row = $st->fetch(PDO::FETCH_ASSOC);
			foreach($row as $field=>$value) {
					$this->$field = $value;
				}
			}
		}

	public static function findAll() {
		$class = get_called_class();
		$table = strtolower($class);
		$get_id = substr($class, -3)."_id";
		$st = db()->prepare("select $get_id from $table");
		$st->execute();
		$list = array();
		while($row = $st->fetch(PDO::FETCH_ASSOC)) {
			$list[] = new $class($row[$get_id]);
		}
		return $list;
	}
	
	public static function findAllBy($classCalling, $id) {
		$class = get_called_class();
		$table = strtolower($class);
		$get_id_where = substr($classCalling, -3)."_id";
		$get_id = substr($class, -3)."_id";
		$st = db()->prepare("select $get_id from $table where $get_id_where=".$id);
		//echo "select $get_id from $table where $get_id_where=".$id;
		$st->execute();
		$list = array();
		while($row = $st->fetch(PDO::FETCH_ASSOC)) {
			if($row[$get_id] != null)
				$list[] = new $class($row[$get_id]);
		}
		return $list;
	}
	
	public static function fieldAlreadyExists($field, $value) {
		$class = get_called_class();
		$table = strtolower($class);
		$get_field = substr($class, -3)."_".$field;
		$st = db()->prepare("select $get_field from $table where $get_field='".$value."'");
		$st->execute();
		if($st->rowCount() > 0)
			return true;
		return false;
	}
	
	public static function findById($id) {
		$class = get_called_class();
		if($id == null)
			return false;
		return new $class($id);
	}


	public function __get($fieldName) {
		$prefix = substr(get_class($this), -3);
		$varName = /*$prefix."_".*/$fieldName;
		if (property_exists(get_class($this), $varName))
			return $this->$varName;
		else
			throw new Exception("Unknown variable: ".$varName);
	}


	public function __set($fieldName, $value) {
		$class = get_class($this);
		$prefix = substr($class, -3);
		$varName = /*$prefix."_".*/$fieldName;
		if ($value != null) {
			if (property_exists(get_class($this), $varName)) {
				$this->$varName = $value;
				$table = strtolower($class);
				$id = $prefix."_id";//.$fieldName;
				/*if (isset($value->$id)) {
					$st = db()->prepare("update $table set ".$prefix."_id=:val where ".$prefix."_id=:id");
					$id = substr($id, 1);
					$st->bindValue(":val", $value->$id);
				} else {*/
					$st = db()->prepare("update $table set $fieldName=:val where $id=:id");
					$st->bindValue(":val", $value);
				//}
				$id = $prefix.'_id';//"id".$table;
				$st->bindValue(":id", $this->$id);
				$st->execute();
			} else{}
				//throw new Exception("Unknown variable: ".$varName . " ($fieldName) class : $class");
		}
	}

	// à surcharger
	public function __toString() {
		return get_class($this).": ".$this->name;
	}

	


}



