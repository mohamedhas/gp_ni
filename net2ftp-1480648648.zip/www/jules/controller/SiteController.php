<?php

class SiteController extends Controller {

	public function __construct()  {

	}

	

	public function index() {
		$this->render("index");
	}

	public function about() {
		$this->render("about");	
	}
	
	public function logout() {
		$_SESSION['id_hotelier'] = '';
		$_SESSION['id_abonne'] = '';
		
		$this->render("index");	
	}
	public function login() {
		$this->render("login");	
	}
	public function connexion() {
		$hotelier = Hotelier::checkConnexion(parameters()['mail'], parameters()['motpasse']);
		$abonne = Abonne::checkConnexion(parameters()['mail'], parameters()['motpasse']);
		if($hotelier != false || $abonne != false){
			if($hotelier)
				$_SESSION['id_hotelier'] = $hotelier['htr_id'];
			else
				$_SESSION['id_abonne'] = $abonne['abo_id'];
			$this->render("index");
		}
		else{
			$this->render("login");
		}
	}


}


