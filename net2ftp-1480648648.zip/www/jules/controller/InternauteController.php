<?php 

class InternauteController extends Controller {

	public function __construct()  {

	}
	public function register() {
		$this->render("register");
	}
	public function view(){
			$internaute = new Internaute("Bernes");
			echo $internaute->nom." ".$internaute->id_facebook;
			$this->render("compte");
			$ok = true;
			foreach(parameters() as $key=>$value)
			{
					if(substr($key, 0, 2) != 'no' && $key != 'r')
						$internaute->$key = $value;
				// $_SESSION['id_abonne'] = $abonne->abo_id;
			}
			// $this->render("index");
	}
	
	
	public function checkInfoAbonne($set=false){
		
		$_SESSION['erreur'] = '';
		$ok = true;
		if(empty(parameters()['abo_adrligne1'])){
			$_SESSION['erreur']['abo_adrligne1'] = "Veuillez rentrer votre adresse</br>";
			$ok = false;
		}
		if(empty(parameters()['abo_ville'])){
			$_SESSION['erreur']['abo_ville'] = "Veuillez rentrer votre ville</br>";
			$ok = false;
		}
		if(!$this->checkMail(parameters()['abo_mel'])){
			$_SESSION['erreur']['abo_mel'] = "Veuillez rentrer une adresse mail correcte</br>";
			$ok = false;
		}
		if(!$set && Abonne::fieldAlreadyExists('mel', parameters()['abo_mel'])){
			$_SESSION['erreur']['abo_mel'] = "L'adresse mail est deja utilisée</br>";
			$ok = false;
		}
		if(Hotelier::fieldAlreadyExists('mel', parameters()['abo_mel'])){
			$_SESSION['erreur']['abo_mel'] = "L'adresse mail est deja utilisée par un hotelier</br>";
			$ok = false;
		}
		if(!is_numeric(parameters()['abo_cp']) || strlen(parameters()['abo_cp']) < 4)
		{
			$_SESSION['erreur']['abo_cp'] = "Veuillez rentrer un code postal valide</br>";
			$ok = false;
		}
		if(empty(parameters()['abo_nom']))
		{
			$_SESSION['erreur']['abo_nom'] = "Veuillez renseigner votre nom</br>";
			$ok = false;
		}
		if(empty(parameters()['abo_prenom']))
		{
			$_SESSION['erreur']['abo_prenom'] = "Veuillez renseigner votre prénom</br>";
			$ok = false;
		}
		if(parameters()['abo_motpasse'] != parameters()['no_mdp'])
		{
			$_SESSION['erreur']['abo_motpasse'] = "Les mots de passes ne sont pas identiques</br>";
			$ok = false;
		}
		return $ok;
	}
	
	public function checkMail($mail){
		if(filter_var($mail, FILTER_VALIDATE_EMAIL))
			return true;
		return false;
	}
	
	public function modify()
	{
		if(isset($_SESSION['id_abonne']) && $_SESSION['id_abonne'] != '')
			$this->render("modify");
		else
			$this->render("index");
	}
	
	public function set()
	{
		if($this->checkInfoAbonne(true))
		{
			$abonne = Abonne::findById($_SESSION['id_abonne']);
			$ok = true;
			foreach(parameters() as $key=>$value)
			{
					if(substr($key, 0, 2) != 'no' && $key != 'r')
						$abonne->$key = $value;
			}
			$this->render("index");
		} else {
			$this->render("modify");
		}
	}
	public function profil()
	{
		$this->render("profil");
	}
}
