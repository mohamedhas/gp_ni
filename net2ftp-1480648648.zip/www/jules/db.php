<?php

ini_set('display_errors', 'On');
error_reporting(-1);
//$db = new PDO("pgsql:host=localhost;dbname=info244; port=5432","info244","XLvuA9");
$db = new PDO("pgsql:host=oporaunisxopora2.postgresql.db;dbname=oporaunisxopora2; port=5432","oporaunisxopora2","Oporapp14");

// function db()
// {return global $db;}

