<?php

// Debug. Désactiver en prod
error_reporting(E_ALL | E_STRICT);
ini_set('display_errors', true);

// Rien de plus !!
include_once "db.php";
include_once "tools.php";
session_start(); 
include_once "controller/route.php";
include_once "view/header.php";


// $db = new PDO("pgsql:host=oporaunisxopora2.postgresql.db;dbname=oporaunisxopora2; port=5432","oporaunisxopora2","Oporapp14");
// $st = $db->prepare("select * from $table where nom='Bernes'");
// $st->execute();
// $row = $st->fetch(PDO::FETCH_ASSOC);
// foreach($row as $field=>$value) 
// {
	// $this->$field = $value;
// }
// echo 'test';

