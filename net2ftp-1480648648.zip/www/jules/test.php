﻿<h1>Appli prenoms</h1>
<input type='text' id='champRecherche'/>
<button id='rechercher'>Rechercher ! </button>
<div id='result' ></div>



<script src="jquery.js"></script>
<script>
$(document).ready(function(){
	$("#rechercher").click(function(){
		$.post('traitement.php',{variable : $("#champRecherche").val()},function(data){
			$("#result").html(data);
		});
	});
});
</script>
