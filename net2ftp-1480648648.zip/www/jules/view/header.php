<!DOCTYPE html> 
<html>
	<head>
		<meta charset="UTF-8">
		<title>Trip Advisor</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<!-- <link rel="stylesheet" href="../css/assets/css/main.css" /> -->
		<link rel="stylesheet" type="text/css" href="css/style.css">
		<link href="https://fonts.googleapis.com/css?family=Baloo+Bhai|Open+Sans" rel="stylesheet">
	</head>

	<body>
		<nav id="navigation">
			<a href="." class="logo" >OuiDUT</a>
			<div class="buttonBox">
			<a class="button" href="?r=question/viewTop">Top questions</a>
			<a class="button" href="?r=question/viewAll">Questions récentes</a>
			<?php //} if(!(!isset($_SESSION['id_hotelier']) || $_SESSION['id_hotelier'] == '') || !(!isset($_SESSION['id_abonne']) || $_SESSION['id_abonne'] == '')){?>
				<a class="button" href="?r=internaute/view">Mon compte</a>
			<?php // } ?>
			</div>
		</nav>
		<main>
