<?php 




$pays = Liste::findAll();


foreach($pays as $unPays){
	echo "<p>".$unPays->pay_nom."</p>";
}