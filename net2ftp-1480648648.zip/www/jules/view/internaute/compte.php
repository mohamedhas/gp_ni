<?php 
echo '1';
echo __FUNCTION__;
print_r(__FUNCTION__);
echo '2';
echo "compte.php";
echo $internaute->nom;