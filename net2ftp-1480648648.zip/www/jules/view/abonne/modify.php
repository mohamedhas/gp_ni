<?php 
echo "<script src='verifications.js'></script>";

$abonne = Abonne::findById($_SESSION['id_abonne']);

$pays = T_r_pays_pay::findAll();
$pays_tri = Array(0=>"");

foreach($pays as $value)
{
	array_push($pays_tri, $value->pay_nom);
}

$parametres = Array(
			Array('abo_nom' , 'Nom', 'input', 'req', 'lock'),
			Array('abo_prenom' , 'Prenom', 'input', 'req', 'lock'),
			Array('abo_pseudo' , 'Pseudo', 'input', 'req', 'lock'),
			Array('abo_mel' , 'E-mail', 'input', 'mail'),
			Array('abo_motpasse' , 'Entrez un mot de passe', 'pass', 'mdp'),
			Array('no_mdp' , 'Retapez votre mot de passe', 'pass', 'remdp'),
			Array('abo_adrligne1' , 'Adresse', 'input', 'req'),
			Array('abo_adrligne2' , 'Complement d\'adresse', 'input'),
			Array('abo_cp' , 'Code postal', 'input', 'cp'),
			Array('abo_ville' , 'Ville', 'input', 'req'),
			Array('abo_etat' , 'Etat', 'input'),
			Array('pay_id', 'Pays', 'select', 'req', $pays_tri),
			Array('abo_tel', 'Telephone', 'input', 'req'),
			Array('abo_indicatif', 'Indicatif', 'input', 'req'),
			Array('abo_aeroport', 'Aeroport', 'input', 'req')
				);

$erreurs = array();
if(isset($_SESSION['erreur']) && !empty($_SESSION['erreur'])){
	$erreurs = $_SESSION['erreur'];
	$_SESSION['erreur'] = array();
}
?>
<div class="page">
	<h2>Inscription d'abonné</h2>

	<form action='?r=abonne/set' method='POST' id='modifyAbonneForm' class="form" onSubmit='return verifForm(this)'>
		<div class="container">
<?php 
	foreach($parametres as $data)
	{
		$verif = "";
		if(isset($data[3])){
			switch($data[3]){
				case 'req' : $verif = "required onBlur='verifChamps(this)' "; break;
				case 'mail' : $verif = "required onBlur='verifMail(this)' "; break;
				case 'mdp' : $verif = "required onBlur='verifMDP(this)' "; break;
				case 'remdp' : $verif = "required onBlur='verifREMDP(this)' "; break;
				case 'cp' : $verif = "required onBlur='verifCP(this)' "; break;
			}
		}

		if (isset($data[4])) {
			if ($data[4] == "lock") {
				$verif .= "disabled ";
			}
		}
		
		if($data[2] == 'input')
		{
			echo "
			<div class='group'>
				<input id='" . $data[0] . "' class='textField' type='text' name='" . $data[0] . "' " . $verif . " onFocus='noProblemo(this)' value='" . $abonne->$data[0] . "'/>" . (isset($erreurs[$data[0]])?$erreurs[$data[0]]:"") . "
				<span class='highlight'></span>
				<span class='bar'></span>
				<label>" . $data[1] . " " . ($verif != ''?'*':'') . "</label>
			</div>";
		}
		else if($data[2] == 'pass')
		{
			echo "
			<div class='group'>
				<input id='" . $data[0] . "' class='textField' type='password' name='" . $data[0] . "' " . $verif . " onFocus='noProblemo(this) value='" . (isset(parameters()[$data[0]])?parameters()[$data[0]]:"") . "/>" . (isset($erreurs[$data[0]])?$erreurs[$data[0]]:"") . "
			
				<span class='highlight'></span>
				<span class='bar'></span>
				<label>".$data[1]." ".($verif != ''?'*':'')."</label>
			</div>";
		}
		else if($data[2] == 'select'){
			echo "
			<div class='group select'>
			<label>" . $data[1] . " " . ($verif != ''?'*':'') . "</label>
				<select id='" . $data[0] . "' name='" . $data[0] . "' class='textField'>";

					$liste = $data[4];

					foreach($liste as $id=>$item){
						if($id == $abonne->$data[0]) {
							echo "<option value=" . $id . " selected>$item</option>";
						} else {
							echo "<option value=" . $id . ">$item</option>";
						}
					}

			echo "
				</select>
			</div>";
		}
	}
?>
			<div class="btnConnexion">
				<input type='submit' id='registerHotelier' value="Sauvegarder"/>
			</div>
		</div>
	</form>
</div>