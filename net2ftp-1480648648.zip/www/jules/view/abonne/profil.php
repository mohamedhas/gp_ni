<?php
if(isset(parameters()['id']))
{
	$abonne = Abonne::findById(parameters()['id']);
	
	$mesAvis = $abonne->getAvis();
	$months = array("", "Janvier", "Février", "Mars", "Avril", "Mai", "Juin", "Juillet", "Aout", "Septembre", "Octobre", "Novembre", "Décembre");
?>
<section class="profil">
<h1>Profil</h1>

<?php 
echo "<p><span class='champs'>Nom : </span><span class='valeur'>". $abonne->abo_nom ."</span></p>";
echo "<p><span class='champs'>Prénom : </span><span class='valeur'>". $abonne->abo_prenom ."</span></p>";
echo "<p><span class='champs'>Pseudo : </span><span class='valeur'>". $abonne->abo_pseudo ."</span></p>";
echo "<p><span class='champs'>E-mail : </span><span class='valeur'>". $abonne->abo_mel ."</span></p>";
echo "<p><span class='champs'>Adresse : </span><span class='valeur'>". $abonne->abo_adrligne1 ."</span></p>";
if($abonne->abo_adrligne2) echo "<p><span class='champs'>(suite) : </span><span class='valeur'>". $abonne->abo_adrligne2 ."</span></p>";
echo "<p><span class='champs'>Code postal : </span><span class='valeur'>". $abonne->abo_cp ."</span></p>";
echo "<p><span class='champs'>Ville : </span><span class='valeur'>". $abonne->abo_ville ."</span></p>";
if($abonne->abo_etat) echo "<p><span class='champs'>Etat : </span><span class='valeur'>". $abonne->abo_etat ."</span></p>";
echo "<p><span class='champs'>Pays : </span><span class='valeur'>". $abonne->pays->pay_nom ."</span></p>";
echo "<p><span class='champs'>Telephone : </span><span class='valeur'>+". $abonne->abo_indicatif . $abonne->abo_tel . "</span></p>";
if($abonne->abo_aeroport) echo "<p><span class='champs'>Aéroport : </span><span class='valeur'>". $abonne->abo_aeroport ."</span></p>";
echo "<p><span class='champs'>Nombre d'avis : </span><span class='valeur'>". count($mesAvis) ."</span></p>";

foreach($mesAvis as $avis){
	$hotel = Hotel::findById($avis->hot_id);
	$periode = PeriodeVisite::findById($avis->per_id);
	$visite = TypeVisite::findById($avis->vis_id);
	echo "<a href='?r=hotel/view&id=".$hotel->hot_id."'><div class='unAvis' style='border:1px solid black;margin:5px;'>";
	echo "<p>Posté sur <span class='nomHotelAvis'>".$hotel->hot_nom."</span></p>";
	echo "<p class='titreAvis'>".$avis->avi_titre."</p>";
	echo "<p class='contenuAvis'>\"".(strlen($avis->avi_detail) > 30 ? substr($avis->avi_detail, 0, 30)."[...]" : $avis->avi_detail) . "\"</p>";
	echo "<p class='noteAvis'>".$avis->avi_noteglobale."/5</p>";
	echo "<p class='periodeAvis'>".$months[$periode->per_mois]. " ". $periode->per_annee . "</p>";
	echo "<p class='visiteAvis'>".$visite->vis_libelle."</p>";
	echo "</div></a>";
}

}?>

</section>