<?php 

include_once "view/hotel/index.php";

?>