<?php 
echo "<script src='verifications.js'></script>";
$parametres = Array(
			Array('abo_nom' , 'Nom', 'input', 'req'),
			Array('abo_prenom' , 'Prenom', 'input', 'req'),
			Array('abo_pseudo' , 'Pseudo', 'input', 'req'),
			Array('abo_mel' , 'E-mail', 'input', 'mail'),
			Array('abo_motpasse' , 'Entrez un mot de passe', 'pass', 'mdp'),
			Array('no_mdp' , 'Retapez votre mot de passe', 'pass', 'remdp'),
			Array('abo_adrligne1' , 'Adresse', 'input', 'req'),
			Array('abo_adrligne2' , 'Complement d\'adresse', 'input'),
			Array('abo_cp' , 'Code postal', 'input', 'cp'),
			Array('abo_ville' , 'Ville', 'input', 'req'),
			Array('abo_etat' , 'Etat', 'input'),
			Array('pay_id', 'Pays', 'select'),
			Array('abo_tel', 'Telephone', 'input', 'req'),
			Array('abo_indicatif', 'Indicatif', 'input', 'req'),
			Array('abo_aeroport', 'Aeroport', 'input', 'req')
				);

$pays = Pays::findAll();

$options_pay_id = Array();
foreach($pays as $unPays){
	$options_pay_id[$unPays->pay_id] = $unPays->pay_nom;
}
$btnEnregister = "S'enregistrer";


$erreurs = array();
if(isset($_SESSION['erreur']) && !empty($_SESSION['erreur'])){
	$erreurs = $_SESSION['erreur'];
	$_SESSION['erreur'] = array();
}
?>
<div class='page'>
	<h2>Inscription d'abonné</h2>

	<form action='?r=abonne/add' method='POST' id='registerAbonneForm' onSubmit='return verifForm(this)'>
		<div class="container">
<?php 
	foreach($parametres as $data)
	{
		$verif = "";
		if(isset($data[3])){
			switch($data[3]){
				case 'req' : $verif = "required onBlur='verifChamps(this)' "; break;
				case 'mail' : $verif = "required onBlur='verifMail(this)' "; break;
				case 'mdp' : $verif = "required onBlur='verifMDP(this)' "; break;
				//case 'remdp' : $verif = " onBlur='verifREMDP(this)' "; break;
				case 'cp' : $verif = "required onBlur='verifCP(this)' "; break;
			}
		}
		
		if($data[2] == 'input')
		{
			echo "
			<div class='group'>
			<input id='".$data[0]."' class='textField' type='text' name='".$data[0]."' ". $verif ." onFocus='noProblemo(this) value='".(isset(parameters()[$data[0]])?parameters()[$data[0]]:'')."/>".(isset($erreurs[$data[0]])?$erreurs[$data[0]]:"")."
			
			<span class='highlight'></span>
			<span class='bar'></span>
			<label for='".$data[0]."'>".$data[1]." ".($verif != ''?'*':'').": </label>
			</div>";
		}
		else if($data[2] == 'pass')
		{
			echo "
			<div class='group'>
			<input id='".$data[0]."' class='textField' type='password' name='".$data[0]."' ". $verif ." onFocus='noProblemo(this) value='".(isset(parameters()[$data[0]])?parameters()[$data[0]]:'')."/>".(isset($erreurs[$data[0]])?$erreurs[$data[0]]:"")."
			
			<span class='highlight'></span>
			<span class='bar'></span>
			<label for='".$data[0]."'>".$data[1]." ".($verif != ''?'*':'').": </label>
			</div>";
		}
		else if($data[2] == 'select'){
			echo "
			<div class='group select'>
			<label for='".$data[0]."'>".$data[1]."  ".($verif != ''?'*':'').": </label><select id='".$data[0]."' name='".$data[0]."' class='textField'>";
			$liste = $options_pay_id;
			foreach($liste as $id=>$pays){
				echo "<option value=".$id." ".(isset(parameters()[$data[0]]) and parameters()[$data[0]] == $key?'selected':'').">$pays</option>";
			}
			echo "</select></div>";
		}
	}
?>
			<div class="btnConnexion">
				<input type='submit' id='registerHotelier' value="Enregistrer"/>
			</div>
		</div>
	</form>
</div>