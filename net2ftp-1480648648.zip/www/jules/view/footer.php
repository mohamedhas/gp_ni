<!--
</section>

	<footer id="footer">
		<div class="inner">
			<h2>&copy; Le site le plus swagg 2016</h2>
			<p>Designed By Ananas, Marco, Mr Tomasi, Julos et le sheitan.</p>
			<ul class="icons">
				<li><a href="#" class="icon fa-twitter"><span class="label">Twitter</span></a></li>
				<li><a href="#" class="icon fa-facebook"><span class="label">Facebook</span></a></li>
				<li><a href="#" class="icon fa-instagram"><span class="label">Instagram</span></a></li>
				<li><a href="#" class="icon fa-envelope"><span class="label">Email</span></a></li>
			</ul>
		</div>
	</footer>
-->
</main>

</body>
</html>