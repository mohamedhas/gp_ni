﻿<?php
$db = new PDO("pgsql:host=oporaunisxopora2.postgresql.db;dbname=oporaunisxopora2; port=5432","oporaunisxopora2","Oporapp14");
$theme = $db->prepare("select ".$_POST['variable']." from opora2016.internaute");
$theme->execute();
$theme = $theme->fetchall();
$string = '';
for ($i = 0;$i<count($theme);$i++)
{
	$string = $string.'<p>'.$theme[$i][$_POST['variable']].'</p>';
}
echo $string;
?>