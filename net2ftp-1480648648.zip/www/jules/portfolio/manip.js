$(document).ready(f());

function f(){
    
}