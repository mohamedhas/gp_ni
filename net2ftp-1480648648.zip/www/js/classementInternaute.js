// AFFICHAGE DE MON RANG
/*function displayMyRank(){

	$.post("controller/classement/myRank.php", {idfacebook}, function(internautes){
		var ul = $("<ul class='divMyRank'/>");
		$("#classement").append(ul);
		$.each(internautes, function(i, internaute){

			if(internaute.id_facebook == idfacebook){
				var li = $("<li "+themeColor1+"></li>");
				li.addClass("myRank");
				li.append("Mon rang : "+internaute.rank);

				ul.append(li);
			}
		});
	}, "json");
}*/


function displayBestPlayerOfAllTimeContainer(){
	$("#classement").append("<div' "+themeColor1+" id='boutonClassementGeneral' value='Classement général'>Top 5 Général</div>");
	$('#boutonClassementGeneral').append("<img src='icon/cross.png' id='BtnPlusClassement'/>");
	$('#boutonClassementGeneral').css("border-color",themeColor1);
	$("#boutonClassementGeneral").click(function(){
		$(this).addClass('selected');

		displayBestPlayerOfAllTime();

	});

	$("#BtnPlusClassement").click(function(){
		displayBestPlayerFull();
	});
}

//-------------------------------------------CLASSEMENT GENERAL-------------------------------------
function displayBestPlayerOfAllTime() {
	$('#classement').empty();
	var div_titre_classement = $("<div class='div_titre'/>");
	var titreClassement = $('<h1 '+themeColor2+' class="div_titre">TOP 5 GENERAL</h1>');
	div_titre_classement.append(titreClassement);
	$('#classement').append(div_titre_classement)
	$.post("controller/classementGeneralInternaute.php", { }, function(internautes) {
		var ul = $("<ul/>");
		ul.attr("id","liste_classement");
		$("#classement").append(ul);
		$.each(internautes, function(i, internaute) {
			var position = $("<div class='position_classement'></div>");
			var position_chiffre = $("<h1>"+internaute.rank+"</h1>");
			console.log(internaute.rank);
			position_chiffre.removeClass('first_position');
			position_chiffre.removeClass('second_position');
			position_chiffre.removeClass('third_position');
			position_chiffre.removeClass('other_position');
			switch(internaute.rank){
				case "1":
					
					position_chiffre.addClass('first_position');
					break;
				case "2":

					position_chiffre.addClass('second_position');
					break;
				case "3":
					position_chiffre.addClass('third_position');
					break;
				default:
					position_chiffre.addClass('other_position');
					break;
			}
			position.append(position_chiffre);
			var li = $("<li "+themeColor1+" id='li"+i+"'></li>");
			li.append(position);
			li.addClass("puces_classement");
			li.append("<img src='https://graph.facebook.com/"+internaute.id_facebook+"/picture?type=large' style='width:3vw; height:3vw;' class='image_classement' />");
			//li.append("<span class='nomInternaute'>"+internaute.nom+"</span> ");
			li.append("<span class='prenomInternaute'>"+internaute.prenom+"</span>");
			if(internaute.total_points >= 1)
			{
				li.append("<span class='pointsInternaute'> "+internaute.total_points+" points</span>");
			}
			if(internaute.total_points < 1)
			{
				li.append("<span class='pointsInternaute'> "+internaute.total_points+" point</span>");
			}
			li.click(function(){
				loadProfile(internaute.id_facebook);
			});
			ul.append(li);
		});
	}, "json").promise().done(
		function(){
			displayMyGlobalRank();
			displayBestPlayerByMonthContainer();
	});



}
function displayBestPlayer() {
	$('#classement').empty();
	var div_titre_classement = $("<div  class='div_titre'/>");
	var titreClassement = $('<h1 '+themeColor2+' class="div_titre">TOP 5 HEBDO</h1>');
	div_titre_classement.append(titreClassement);
	$('#classement').append(div_titre_classement)
	$.post("controller/classement/classementInternaute.php", { }, function(internautes) {
		var ul = $("<ul/>");
		ul.attr("id","liste_classement");
		$("#classement").append(ul);

		$.each(internautes, function(i, internaute) {
			var position = $("<div class='position_classement'></div>");
			var position_chiffre = $("<h1>"+internaute.rank+"</h1>");
			position_chiffre.removeClass('first_position');
			position_chiffre.removeClass('second_position');
			position_chiffre.removeClass('third_position');
			position_chiffre.removeClass('other_position');
			switch(internaute.rank){
				case "1":
					position_chiffre.addClass('first_position');
					break;
				case "2":
					position_chiffre.addClass('second_position');
					break;
				case "3":
					position_chiffre.addClass('third_position');
					break;
				default:
					position_chiffre.addClass('other_position');
					break;
			}
			position.append(position_chiffre);

			var li = $("<li "+themeColor1+" id='li"+i+"'/>");
			li.append(position);
			li.addClass("puces_classement");
			li.append("<img src='https://graph.facebook.com/"+internaute.id_facebook+"/picture?type=large' style='width:3vw; height:3vw;' class='image_classement' />");
			//li.append("<span class='nomInternaute'>"+internaute.nom+"</span>");
			li.append("<span class='prenomInternaute'>"+internaute.prenom+"</span>");
			if(internaute.total_points >= 1)
			{
				li.append("<span class='pointsInternaute'> "+internaute.points+" points</span>");
			}
			if(internaute.total_points < 1)
			{
				li.append("<span class='pointsInternaute'> "+internaute.points+" point</span>");
			}
			li.click(function(){
				console.log("id profile : "+internaute.id_facebook+"\nid courant : "+idfacebook)
				loadProfile(internaute.id_facebook);
				//console.log("id profile : "+internaute.id_facebook+"\nid courant"+idfacebook)
			});
			ul.append(li);
		});

	}, "json").promise().done(
		function(){
			displayMyRank();
			displayBestPlayerOfAllTimeContainer();
			displayBestPlayerFullContainer();
	});




}

//fonction qui affiche le bouton permettant de lancer la fonction displayBestPlayerFull
function displayBestPlayerFullContainer(){

	//$("#classement").append("<div id='boutonBestPlayerFull'>+</div>");
	$("#BtnPlusClassement").click(function(){
		$(this).addClass('selected');

		displayBestPlayerFull();



	});
}


//fonction qui affiche le classement hebdo en entier
function displayBestPlayerFull(){

$.post("controller/classement/classementGeneral.php", {classement : 'Hebdo'}, function(data){
        $("#contenu").html(data);
		$('td').click(function(){
			var row = $(this).parent('tr');
			loadProfile(row.data('id'));
		});
})
.done(function(){
   $('.tableHebdo').click(function(){displayHebdo();});
   $('.tableTotal').click(function(){displayTotal();});
});/*
	$('#contenu').empty();
	var div_classement_main = $('<div class="div_classement_main"></div>');
	$('#contenu').append(div_classement_main);
	var titre = $('<div '+themeColor2+'  class="div_titre"><h1 '+themeColor2+' class="titre_main">CLASSEMENT ENTIER</h1></div>');
	$('#contenu').prepend(titre);
	
        var html = '<table style="width:100%;">';
        $.ajax({type:'POST', url:"controller/classement/classementGeneral.php", success:function(data){
            html += data;
            }
        })
        .done(function(){$.ajax({type:'POST', url:"controller/classement/classementInternauteFullHebdo.php", success:function(internautes){
		$.each(JSON.parse(internautes), function(i, internaute){
        		$.ajax({type:'POST', url:"controller/classement/ligneClassement.php", data:{place:internaute.rank , idfacebook:internaute.id_facebook , nom:internaute.nom , prenom:internaute.prenom , pointsHebdo:internaute.points , pointsTotal:internaute.total_points }, async:false, success:function(data){
            				html += data;
                                 }
        		});
                });
              }
            })
            .done(function(){
                 html += "</table>";
                 $('.div_classement_main').html(html);
                 $('.tableHebdo').click(function(){displayHebdo();});
                 $('.tableTotal').click(function(){displayTotal();});
            });
        });*/
}

function displayHebdo(){

$.post("controller/classement/classementGeneral.php", {classement : 'Hebdo'}, function(data){
        $("#contenu").html(data);
		$('td').click(function(){
			var row = $(this).parent('tr');
			loadProfile(row.data('id'));
		});
})
.done(function(){
   $('.tableHebdo').click(function(){displayHebdo();});
   $('.tableTotal').click(function(){displayTotal();});
});

}
function displayTotal(){

$.post("controller/classement/classementGeneral.php", {classement : 'Total'}, function(data){
        $("#contenu").html(data);
		$('td').click(function(){
			var row = $(this).parent('tr');
			loadProfile(row.data('id'));
		});
})
.done(function(){
   $('.tableHebdo').click(function(){displayHebdo();});
   $('.tableTotal').click(function(){displayTotal();});
});
}


function displayMyGlobalRank(){

	$.post("controller/classement/myGlobalRank.php", {idfacebook : idfacebook}, function(internautes){
		var ul = $("<ul class='divMyRank'/>");
		$("#classement").append(ul);
		$.each(internautes, function(i, internaute){

			if(internaute.id_facebook == idfacebook){
				var li = $("<li "+themeColor1+"/>");
				li.addClass("myRank");
				li.append("Mon rang : "+internaute.rank);

				ul.append(li);
			}
		});
	}, "json");
}


function displayBestPlayerByMonthContainer(){
	$("#classement").append("<div "+themeColor1+" id='boutonClassementGeneral' value='Classement général'>Top 5 Hebdo</div>");
	$('#boutonClassementGeneral').append("<img src='icon/cross.png' id='BtnPlusClassement'/>");

	$("#boutonClassementGeneral").click(function(){

		$(this).addClass('selected');
		displayBestPlayer();
	});
	$("#BtnPlusClassement").click(function(){
		displayBestPlayerFull();

	});
}
