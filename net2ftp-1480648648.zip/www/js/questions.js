 	function displayAllQuestions() {

	$.post("controller/question/allQuestions.php", { }, function(questions) {
		var div_allquest = $("<div id='div_allquest' />");
		var ul = $("<ul class='ul_allquestion' />");
		var div_titre_main = $('<div '+themeColor2+' class="div_titre"></div>');

		var titre = $('<h1 '+themeColor2+' class="titre_main">TOUTES LES QUESTIONS</h1>');
		var div_box = $("<div class='div_box'></div>");
		var select_tri = $("<select id='select_tri'/>");
		var default_opt = $("<option value='all' selected='selected'>--</option>");
		select_tri.append(default_opt);
		
		///////////////////////////////////////////////////
		///////////////////////////////////////////////////
		$.post("controller/departement/allDepartement.php", { }, function(departements) {
			$.each(JSON.parse(departements), function(i, departement){
			var optDept = $("<option value='"+departement.id_dept+"'>"+departement.libelle_dept+"</option>");
			select_tri.append(optDept);
			console.log(departement.id_dept + " " + departement.libelle_dept);
			});
		});
		/////////////////////////////////////////////////
		/////////////////////////////////////////////////
		div_box.append(select_tri);
		titre.append(div_box);
		div_titre_main.append(titre);
		$("#contenu").append(div_titre_main);
		$(div_allquest).append(ul);
		$('#contenu').append(div_allquest);

			$.each(questions, function(i, question) {
				console.log(question);
				var li = $("<li/>");
				li.data("question",question);
				li.addClass("myquestion");


				var profil_question = $('<div/>');
				profil_question.addClass('profil_question');
				profil_question.append("<img src='https://graph.facebook.com/"+question.id_facebook+"/picture?type=large'  class='imageQuestion' />");
				li.append(profil_question);
				var contenu_question = $('<div/>');
				contenu_question.addClass('contenu_question');
				contenu_question.append("<span "+themeColor1+" class='titre'  >"+question.libelle_matiere+" : "+htmlEntities(question.titre)+"</span></br>");
				contenu_question.append("<span class='date'>"+question.dates+"</span>");
				contenu_question.append("<span class='dept_libelle_"+question.libelle_dept+"'>"+question.libelle_dept+"</span>");
				$.post("controller/question/nbReponse.php", {"id_question":question.id_question}, function(questions) {
					$.each(questions, function(i, question) {
						contenu_question.append("<span class = 'nbreponse'> Réponse : "+question.nbreponse+"</span>");

					});





				},"json");
				li.append(contenu_question);


				ul.append(li);

			});


		$(".myquestion").click(function() {
			questionReponse($(this).data("question").id_question);
		});



			/********************************************************
	*****************FUNCTION DE TRIE*************************
	***********************************************************/
	 	function selectTriQuestionByDept() {

		$('#select_tri').change(function(){

				    var selection = $('#select_tri').val();

				    switch(selection){

				        case 'gea':
				        $(".ul_allquestion").empty();
				        	$.post("controller/question/questionsGEA.php", { }, function(questions) {

							$.each(questions, function(i, question) {
							var li = $("<li/>");
							li.data("question",question);
							li.addClass('myquestion');

							var profil_question = $('<div/>');
							profil_question.addClass('profil_question');
              profil_question.append("<img src='https://graph.facebook.com/"+question.id_facebook+"/picture?type=large'  class='imageQuestion' />");

              //profil_question.append("<img src='"+question.photo_internaute+"' style='width:50px; height:50px;' class='image_reponse'/>")
							/*profil_question.append("<span class='nomInternauteQuestion'>"+question.nom_internaute+"</span>");*/
							li.append(profil_question);
							var contenu_question = $('<div/>');
							contenu_question.addClass('contenu_question');
							contenu_question.append("<span "+themeColor1+" class='titre'>"+question.libelle_matiere+" : "+htmlEntities(question.titre_question)+"</span></br>");
							contenu_question.append("<span class='date'>"+question.dates+"</span>");
							contenu_question.append("<span class='dept_libelle_"+question.libelle_dept+"'>"+question.libelle_dept+"</span>");


							$.post("controller/question/nbReponse.php", {"id_question":question.id_question}, function(questions) {
								$.each(questions, function(i, question) {
									contenu_question.append("<span class = 'nbreponse'> Réponse : "+question.nbreponse+"</span>");
								});
							},"json");


							li.append(contenu_question);

							ul.append(li);
						});

		 		$(".myquestion").click(function() {
					questionReponse($(this).data("question").id_question);
				});


			}, "json");
				           console.log("okgea");
				            break;
				        case 'info':
				         $(".ul_allquestion").empty();
				        	$.post("controller/question/questionsINFO.php", { }, function(questions) {

							$.each(questions, function(i, question) {
							var li = $("<li/>");
							li.data("question",question);
							li.addClass('myquestion');

							var profil_question = $('<div/>');
							profil_question.addClass('profil_question');
              profil_question.append("<img src='https://graph.facebook.com/"+question.id_facebook+"/picture?type=large'  class='imageQuestion' />");
              //profil_question.append("<img src='"+question.photo_internaute+"' style='width:50px; height:50px;' class='image_reponse'/>")
							profil_question.append("<span class='nomInternauteQuestion'>"+question.nom_internaute+"</span>");
							li.append(profil_question);
							var contenu_question = $('<div/>');
							contenu_question.addClass('contenu_question');
							contenu_question.append("<span "+themeColor1+" class='titre'>"+question.libelle_matiere+" : "+htmlEntities(question.titre_question)+"</span></br>");
							contenu_question.append("<span class='date'>"+question.dates+"</span>");
							contenu_question.append("<span class='dept_libelle_"+question.libelle_dept+"'>"+question.libelle_dept+"</span>");


							$.post("controller/question/nbReponse.php", {"id_question":question.id_question}, function(questions) {
								$.each(questions, function(i, question) {
									contenu_question.append("<span class = 'nbreponse'> Réponse : "+question.nbreponse+"</span>");
								});
							},"json");


							li.append(contenu_question);

							ul.append(li);
						});

		 		$(".myquestion").click(function() {
					questionReponse($(this).data("question").id_question);
				});


			}, "json");
				            console.log("okinfo");
				            break;
				        case 'all':

				         $(".ul_allquestion").empty();
				        	$.post("controller/question/allQuestions.php", { }, function(questions) {

							$.each(questions, function(i, question) {
							var li = $("<li/>");
							li.data("question",question);
							li.addClass('myquestion');

							var profil_question = $('<div/>');
							profil_question.addClass('profil_question');
              profil_question.append("<img src='https://graph.facebook.com/"+question.id_facebook+"/picture?type=large'  class='imageQuestion' />");

              //profil_question.append("<img src='"+question.photo_internaute+"' style='width:50px; height:50px;' class='image_reponse'/>")
							profil_question.append("<span class='nomInternauteQuestion'>"+question.nom_internaute+"</span>");
							li.append(profil_question);
							var contenu_question = $('<div/>');
							contenu_question.addClass('contenu_question');
						contenu_question.append("<span "+themeColor1+" class='titre'>"+question.libelle_matiere+" : "+htmlEntities(question.titre_question)+"</span></br>");
							contenu_question.append("<span class='date'>"+question.dates+"</span>");
							contenu_question.append("<span class='dept_libelle_"+question.libelle_dept+"'>"+question.libelle_dept+"</span>");


							$.post("controller/question/nbReponse.php", {"id_question":question.id_question}, function(questions) {
								$.each(questions, function(i, question) {
									contenu_question.append("<span class = 'nbreponse'> Réponse : "+question.nbreponse+"</span>");
								});
							},"json");


							li.append(contenu_question);

							ul.append(li);
						});

		 		$(".myquestion").click(function() {
					questionReponse($(this).data("question").id_question);
				});


			}, "json");
				            console.log("all");
				            break;
		    }
		});
 }

/********************************************************
***************** FIN *************************
***********************************************************/

selectTriQuestionByDept();

	}, "json");
}


function displayQuestionByCategorie(id_categorie){
	$.post("controller/question/questionsParCategorie.php", {id_categorie : id_categorie}, function(html){
		$("#contenu").html(html);
		
		$(".myquestion").click(function() {
			questionReponse($(this).data("question"));
		});
	});
}
function displayQuestionsByMatiere(idmatiere, libellematiere) {

	//console.log(idmatiere);
	//console.log(libellematiere);
	var div_titre_main = $('<div '+themeColor2+' class="div_titre"></div>');


		var titre = $('<h1 '+themeColor2+' class="titre_main">'+libellematiere.toUpperCase()+'</h1>');
		div_titre_main.append(titre);
		$("#contenu").append(div_titre_main);


	$.post("controller/question/questionsByMatiere.php", {"id_matiere":idmatiere }, function(questions) {
		var ul = $("<ul id='listequestions'/>");
		$("#contenu").append(ul);
			/*ul.css({
			height:"63vh",
			overflow:"hidden"
		})
		ul.mousewheel(function(event) {
			ul.scrollTop(ul.scrollTop()+event.deltaY*10);
			console.log(event);
		});*/
		$.each(questions, function(i, question) {
			
			var li = $("<li/>");
			li.data("question",question);
			li.addClass("myquestion");

			var profil_question = $('<div/>');
			profil_question.addClass('profil_question');
      profil_question.append("<img src='https://graph.facebook.com/"+question.id_facebook+"/picture?type=large'  class='imageQuestion' />");
			//profil_question.append("<img src='"+question.photo_internaute+"' style='width:50px; height:50px;' class='image_reponse'></br>");
			/*profil_question.append(question.nom_internaute);*/
			li.append(profil_question);
			var contenu_question = $('<div/>');
			contenu_question.addClass('contenu_question');
			contenu_question.append("<span "+themeColor1+" class='titre'>"+htmlEntities(question.titre)+"</span></br>");
			contenu_question.append("<span class='date_question'>"+question.date_post+"</span></br>");
			$.post("controller/question/nbReponse.php", {"id_question":question.id_question}, function(questions) {
					$.each(questions, function(i, question) {
						texte.append("<span class = 'nbreponse'> Réponse : "+question.nbreponse+"</span>");
					});

				},"json");
			li.append(contenu_question);

			ul.append(li);
		});
		$(".myquestion").click(function() {
			questionReponse($(this).data("question").id_question);
		});

	}, "json");




}



	

function displayQuestionsRecentes(page) {

checkObtentionBadge();
if(typeof(page) == 'undefined') page = 1;
$.post("controller/question/questionRecentes.php", {page : page}, function(data){
       $("#contenu").html(data);
})
.done(function(){
	var div_titre_main = $('<div '+themeColor2+' id="div_titre"></div>');

	var titre = $("<h1 "+themeColor2+" class='titre_main'>QUESTIONS RECENTES</h1>");
	div_titre_main.append(titre);

	$("#contenu").append(div_titre_main);	 	
        $(".myquestion").click(function() {
	     questionReponse($(this).data("question"));
	});
	displayAddQuestionButton();
        displayQuestionByCategoryButton();
	displayMyQuestionsButton();
	$('#suivant').click(function(){
		displayQuestionsRecentes(page+1);
	});
	$('#precedent').click(function(){
		displayQuestionsRecentes(page-1);
	});
	$('#pagination span').click(function(){
		if($(this).attr('id') != 'precedent' && $(this).attr('id') != 'suivant')
			displayQuestionsRecentes($(this).attr('id'));
	});
});
/*
	$.post("controller/question/allQuestionsByDate.php", {}, function(questions) {

		var ul = $("<ul/>");
				ul.attr("id","liste");
				$("#contenu_div_index").append(ul);

					$.each(JSON.parse(questions), function(i, question) {
						var li = $("<li/>");
						li.data("question",question);
						li.addClass('myquestion');
                                                /*************************************
							NOMBRE DE REPONSE
						**************************************//*
                                                var nombre_reponses = 0;
/////////////////////////////////////////////TOUTE LA MISE EN PAGE DE LA QUESTION EST LA ////////////////////////////////////////////////////////
						$.ajax({
							asynchronous : false,
							type : "post",
							url : "controller/question/nbReponse.php", 
							data : {"id_question":question.id_question}, 
							success : function(questions) {
								$.each(JSON.parse(questions), function(i, question) {
									nombre_reponses = parseInt(question.nbreponse, 10);
								});
                                                              }})
                                                              .done(function(){$.post("controller/question/questionFromList.php", {image_utilisateur:"<img src='https://graph.facebook.com/"+question.id_facebook+"/picture?type=large' class='imageQuestion' />", 
                                                                                                                             matiere:question.libelle_matiere, titre:question.titre, departement:question.libelle_dept,
                                                                                                                             date:question.date_post, nombre_reponse : nombre_reponses}, function(data){
                                                                       li.html(data);
                                                              });
                                                              });

										ul.append(li);
*/
/*
	 	$(".myquestion").click(function() {
				questionReponse($(this).data("question").id_question);
			});

      $('.imageQuestion').click(function(){
        loadProfile(question.id_facebook);

      });


			},"json");*/



}


function displayAddQuestionButton() {
	var button = $("<button/>");
	button
		.addClass("btn_posterQuestion")
		.append("Ajouter question")
		.click(displayFormPosterQuestions);

	$("#div_titre").append(button);
}

function displayQuestionByCategoryButton(){
       var button = $("<button/>");
       button.addClass("questionByCategory")
             .attr("id","btn_questionByCategory")
             .append("Questions par catégories")
             .click(displayAllCategories);

      $("#div_titre").append(button);
}

function displayMyQuestionsButton() {
	var button = $("<button/>");
	button
                .attr('id', 'btn_myQuestions')
		.addClass("my_questions")
		.append("Mes questions")
                .click(function(){
		      displayMyQuestionContainer();
		      displayBestPlayerContainer();
		      provenance = 'my_questions';
                });

	$("#div_titre").append(button);
}



function displayFormPosterQuestions(){
        $("#contenu").empty();
	var div = $("<div id='divadd'/>");
	var div_titre_main = $('<div '+themeColor2+' class="div_titre"></div>');
		var titre = $('<h1 '+themeColor2+' class="titre_main">POSER UNE QUESTION</h1>');
		div_titre_main.append(titre);
		$("#contenu").append(div_titre_main);
	$("#contenu").append(div);



	$.post("./controller/departement/deptQuestion.php",{}, function(depts){
		var selectDept = $("<select id='selectdept'></select>");
		$('#form-div').prepend(selectDept);
		optDefaut = $("<option selected='selected' value='' >Département</option>");
		selectDept.append(optDefaut);

		$.each(depts, function(i, dept)
		{
			var optDept = $("<option value="+dept.id_dept+">"+dept.libelle_dept+"</option>");
			selectDept.append(optDept);


		});


				var selectCateg = $("<select id='selectcateg'></select>");
				selectCateg.css("padding",'10px');
				selectCateg.css("width",'29%');
				selectCateg.css("border",'1px solid #ccc');
				selectCateg.css(" box-shadow",'none');
				selectCateg.css("background-image",'center');
				selectCateg.css("font-family",'"Maven Pro", sans-serif');
				selectCateg.css(" -webkit-box-sizing",'border-box');
				selectCateg.css("-moz-box-sizing",'border-box');
				selectCateg.css("-ms-box-sizing",'border-box');
				selectCateg.css("box-sizing",'border-box');
				selectCateg.css("border-radius",'3px');
				selectCateg.css(" border-radius",'3px');
				selectCateg.css("margin",'0px 5px 0px 5px');
				
				var selectMat = $("<select id='selectmat'></select>");

				$('#selectdept').on('change',function(){
					$('#selectmat').hide();
					$('#selectmat').empty();
					$('#selectcateg').empty();



					$.post("./controller/categorie/categQuestion.php",
						{
							"id_dept" : $('#selectdept').val()
						}
						, function(categories){
						optDefaut = $("<option selected='selected' value=''>Catégorie</option>");
						selectCateg.append(optDefaut).empty();
						selectDept.after(selectCateg);

						$.each(categories, function(i, categorie)
						{

							var optCateg= $("<option value="+categorie.id_categorie+">"+categorie.libelle_categorie+"</option>");
							selectCateg.append(optCateg);
							selectCateg.hide();
							selectCateg.fadeIn(300);

						});






						$('#selectcateg').on('change', function(){
							$('#selectmat').empty();



							var optMat;
								$.post("./controller/matiere/matiereQuestion.php",
									{
										"id_categ" : $("#selectcateg").val()
									},

									function(matieres){

										optDefaut = $("<option selected='selected' value=''>Matière</option>");
										selectMat.append(optDefaut).empty();
										selectCateg.after(selectMat);
										$.each(matieres, function(i, matiere)
										{
											optMat = $("<option  value="+matiere.id_matiere+">"+matiere.libelle_matiere+"</option>");
											selectMat.append(optMat);
											selectMat.hide();
											selectMat.fadeIn(300);

										});

									}, "json");
						});





					}, "json");

			});



	}, "json").fail(function(){

	});


var id =  idfacebook;
/*
	var inputTitre = $("<input id='inputTitre'  placeholder='Sujet'/>");

	form.append(inputTitre);
	var inputValeur = $("<textarea id='inputValeur' placeholder='Question'/>");
	form.append(inputValeur);
	var buttonSubmit = $("<button id='submit' />"); //onClick='VerifQuestion();VerifTitre();'
	buttonSubmit.append("Ajouter");
	form.append(buttonSubmit);*/


//-------------------------------------------------------------------
	var divform_main = $('<div id="form-main"></div>');
	var divform_div = $('<div '+themeColor2+' id="form-div"></div>');
	var form1 = $('<form class="form" id="form1"></form>');
	var p1 = $('<p class="input1" ></p>');
	var input1 = $('<input name="input1" type="text" class="validate[required,custom[onlyLetter],length[0,100]] feedback-input" placeholder="Titre" id="input1" ></input>');

	var p2 = $('<p class="text"></p>');
	var textarea1 = $('<textarea style="resize: none;" cols="30" rows="3" name="editor2" class="validate[required,length[6,300]] feedback-input" id="comment" placeholder="Question"></textarea>');

	var divsubmit = $('<div class="submit"></div>');
	var input2 = $('<input '+themeColor1+' type="submit" value="ENVOYER !" id="button-blue"></input>');
	var divease = $('<div class="ease"></div>');



	p1.append(input1);
	p2.append(textarea1);
	divsubmit.append(divease);
	divsubmit.append(input2);
	form1.append(p1);
	form1.append(p2);
	form1.append(divsubmit);
	divform_div.append(form1);
	divform_main.append(divform_div);
	$('#divadd').append(divform_main);

	editor=CKEDITOR.replace( 'editor2', {
											forcePasteAsPlainText : true,
											width   : '100%',
											uiColor : '#F2F2F2'
											});


//-------------------------------------------------------------------------



	$('.submit').click(function(){

                checkObtentionBadge();                      ///Obtention des badges, au cas ou

		$.post(
			"./controller/question/addQuestion.php",
			{
				"id_dept": $("#selectdept").val(),
				"titre_question": input1.val(),
				"valeur_question": editor.getData(),
				"id_matiere" : $("#selectmat").val(),
				"id_categ" : $("#selectcateg").val(),
				"id_facebook" : id
			},
			function(question) {
      	$("#contenu").empty();
        ResetPointsOnLoad();
        displayMyQuestionContainer();
        displayBestPlayerContainer();
        displayBestPlayerFullContainer();
        MajNbMessage(idfacebook);
        VerificationBadgesQuestions(idfacebook);

			},
			"json").fail(function(a,b,c) {
          ohSnap('Vous devez completer tous les champs !', {color: 'red'});



				});


		return false;


	});




}



function displayMyQuestions(id_facebook, page)
	{
		/*var div = $("<div id='div_myquest'/>");
			var div_titre_main = $('<div '+themeColor2+' class="div_titre"></div>');
		var titre = $('<h1 '+themeColor2+' class="titre_main">MES QUESTIONS</h1>');
		div_titre_main.append(titre);
		$("#contenu").append(div_titre_main);
		$("#contenu").append(div);
		var ul = $("<ul class='ul_myquestion'/>");
		$(div).append(ul);*/
		$.post("controller/question/myQuestions.php",
		{
			"id_facebook":id_facebook,
			"page" : page
		},
		function(html) {
			$('#contenu').html(html);

			$(".myquestion").click(function() {
				questionReponse($(this).data("question").id_question);
			});

		});
	}
function displayDernieresActivites(page){
	
	checkObtentionBadge();
	if(typeof(page) == 'undefined') page = 1;
	$.post("controller/question/dernieresActivites.php", {page : page, id_facebook : idfacebook}, function(data){
		   $("#contenu").html(data);
	})
	.done(function(){
		var div_titre_main = $('<div '+themeColor2+' id="div_titre"></div>');

		var titre = $("<h1 "+themeColor2+" class='titre_main'>ACTIVITE RECENTE</h1>");
		div_titre_main.append(titre);

		$("#contenu").append(div_titre_main);	 	
			$(".myquestion").click(function() {
			 questionReponse($(this).data("question"));
		});
		displayAddQuestionButton();
                displayQuestionByCategoryButton();
		displayMyQuestionsButton();
		$('#suivant').click(function(){
			displayDernieresActivites(page+1);
		});
		$('#precedent').click(function(){
			displayDernieresActivites(page-1);
		});
		$('#pagination span').click(function(){
			if($(this).attr('id') != 'precedent' && $(this).attr('id') != 'suivant')
				displayDernieresActivites($(this).attr('id'));
		});
	});
}
	/***************** BIENTOT LES 1000 LIGNES !!! ******************************/			