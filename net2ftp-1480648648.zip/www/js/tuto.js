function startingTuto(){
	var tutos = [
	{
		texte : "Bonjour jeune conquerant, Bienvenu dans l’univers de solarise. Je suis Theandras dieu de l’univers, et aujourd’hui ma mission est de t’accompagner dans la découverte de l’univers.",
		cible : null, bloque : true, bouton : true
	},
	{
		texte : "Ton objectif est de conquérir chaque planète de l’univers afin d’en devenir le maitre. Pour pouvoir conquérir des planètes il te faut parcourir un certain nombre de km que tu gagneras en effectuent des sauvetages.",
		cible : null, bloque : true, bouton : true
	},
	{
		texte : "Une demande de sauvetage correspond à une question posée par un joueur ",
		cible : '.myquestion', bloque : false, bouton : false
	},
	{
		texte : "Pour lui venir en aide il te suffira de répondre à sa question ",
		cible : '#cke_editor_2', bloque : true, bouton : true
	},
	{
		texte : "Si jamais d’autre conquerant approuve ta réponse ils auront la possibilité de liker ton sauvetage et cela te fera gagner plus de points",
		cible : '.addPoint', bloque : true, bouton : true
	},
	{
		texte : "Cependant prend garde car si ton sauvetage s’avère être inutile ou  déplacer tu pourras subir une rétrogradions…",
		cible : '.btnEnvoieReponsesAbusives', bloque : true, bouton : true
	},
	{
		texte : "Ici tu retrouveras les principales informations telles que le nombre de planètes conquis et ta progression (ton exp, ton lvl) ...",
		cible : '.home_profile', bloque : true, bouton : true
	},
	{
		texte : "... Ton titre qui pourra évoluer en fonction de tes accomplissements ...",
		cible : '#titre', bloque : true, bouton : true
	},
	{
		texte : "... Ton nom au sein de solaris",
		cible : '#pseudo', bloque : true, bouton : true
	},
	{
		texte : "Dans l’onglet profile ",
		cible : '.profil', bloque : false, bouton : false
	},
	{
		texte : "Ici tu retrouveras toutes les informations de ton avancé dans solaris",
		cible : '#profile_stats', bloque : true, bouton : true
	},
	{
		texte : "c’est ici que tu pourras consulter les titres",
		cible : '#profile_titre', bloque : true, bouton : true
	},
	{
		texte : "les badges obtenu",
		cible : '#contenu_badge', bloque : true, bouton : true
	},
	{
		texte : "Mais aussi de te décrire ",
		cible : '#profile_desc', bloque : true, bouton : true
	},
	{
		texte : "Allons voir ailleurs!",
		cible : '#croix', bloque : false, bouton : false
	},
	{
		texte : "Pour finir jeune conquerants tu peux retrouver à tout moment le classement des aventuriers",
		cible : '#classements', bloque : false, bouton : false
	},
	{
		texte : "Le classement est établi par le nombre de km parcourus par mois et au total.",
		cible : '.div_classement_main table', bloque : true, bouton : true
	}];
	var i = 0;
	createTuto(i, tutos);
	accepterNouveau(idfacebook, false);		//Pas de redirection apres acceptation
	/*
	var j = 0;
	var fTutos = [tuto(tutos[tutos.length-1].texte, tutos[tutos.length-1].cible, tutos[tutos.length-1].bloque, tutos[tutos.length-1].bouton, function(){$('#divTuto').remove();})];
	for(var i = tutos.length-2; i >= 0; i--)
	{
		fTutos.push(tutos[i].texte, tutos[i].cible, tutos[i].bloque, tutos[i].bouton, function(){fTutos[j]();});
		j++;
	}
	
	fTutos.reverse();
	fTutos[0]();
	*//*
	tuto("Bienvenu sur OPORA!", null, true, true, function(){	//texte, element, bloque, bouton, callback
		tuto("Tu peux consulter ton profil ici", $("#user")[0], false, false, function(){
			tuto("Voila tes stats", $("#infos_profile")[0], true, true, function(){
				tuto("Bon jeu!", null, true, true, function(){
					$('#divTuto').remove();
				});
			});
		});
	});*/
	
}
function createTuto(i, tab){
	var tutos = tab;
	var e = tutos[i].cible;
	if(i < tutos.length-1)
		tuto(tutos[i].texte, $(tutos[i].cible)[0], tutos[i].bloque, tutos[i].bouton, function(){i++; createTuto(i, tutos);});
	else
		tuto(tutos[i].texte, $(tutos[i].cible)[0], tutos[i].bloque, tutos[i].bouton, function(){$('#divTuto').remove();});
}
function tuto(texte, element, bloque, bouton, callback){
	var div = divTuto(bloque);
	div.css('background-color', 'transparent');
	if(typeof(element) != 'undefined' && element != null){
		AimElement(element, callback);
	}
	else {
		div.prepend($('<div style="width:100%;height:100%;opacity:0.7;background-color:black"/>'));
	}
	
	var divTexte = null;
	if(typeof(texte) != 'undefined' && texte != '')
		divText = instructionTuto(texte);
	if(bouton)
		addNextButton(callback, divText);
}
function divTuto(bloque){
	$('#divTuto').remove();
	var div = $("<div id='divTuto'/>");
	/*if(!bloque){
		div.css('pointer-events', 'none');
	}*/
	$('body').append(div);
	
	return div;
}
function instructionTuto(texte){
	var div = $("<div class='instructTuto welcomeBox' />");
	div.append($('<p>'+texte+'</p>'));
	$('#divTuto').append(div);
	
	return div;
}
function AimElement(e, callback){
	var div = $("#divTuto");
	var rect = e.getBoundingClientRect();
	var $window = $(document);
	
	var top_top = 0;
	var top_left = 0;
	var top_right = $window.width();
	var top_bottom = rect.top;
	
	var left_top = top_bottom;
	var left_left = 0;
	var left_right = rect.left;
	var left_bottom = $window.height();
	
	var right_top = top_bottom;
	var right_left = rect.right;
	var right_right = $window.width();
	var right_bottom = $window.height();
	
	var bottom_top = rect.bottom;
	var bottom_left = left_right;
	var bottom_right = right_left;
	var bottom_bottom = $window.height();
	
	var divTop = $("<div style='top:"+top_top+"px; left:"+top_left+"px;width:"+(top_right - top_left)+"px;height:"+(top_bottom - top_top)+"px' class='tutoBG'/>");
	var divLeft = $("<div style='top:"+left_top+"px; left:"+left_left+"px;width:"+(left_right - left_left)+"px;height:"+(left_bottom-left_top)+"px' class='tutoBG'/>");
	var divRight = $("<div style='top:"+right_top+"px; left:"+right_left+"px;width:"+(right_right - right_left)+"px;height:"+(right_bottom - right_top)+"px' class='tutoBG'/>");
	var divBottom = $("<div style='top:"+bottom_top+"px; left:"+bottom_left+"px;width:"+(bottom_right - bottom_left)+"px;height:"+(bottom_bottom - bottom_top)+"px' class='tutoBG'/>");
	var divCenter = $("<div style='top:"+top_bottom+"px; left:"+left_right+"px;width:"+(right_left - left_right)+"px;height:"+(bottom_top - top_bottom)+"px; opacity : 0'/>");
	
	div.append(divTop);
	div.append(divLeft);
	div.append(divRight);
	div.append(divBottom);
	div.append(divCenter);
	
	divCenter.click(function(){callback(true); e.click();});
	
	return divCenter;
}
function addNextButton(callback, divText){
	var buton = $("<button id='nextTuto'>Suivant</button>");
	$('#divTuto').append(buton);
	buton[0].style.top = (divText[0].offsetTop + divText[0].clientHeight) + 'px';
	buton.click(function(){
		callback(true);
	});
	return buton;
}
function fakeListQuestion(){
	
}
function fakeQuestion(){
	
}