function DisplayAjoutNiveau()
{
	$.post("controller/planete/formulaireAjoutPlanete.php", {}, function(html){
		$("#contenu").html(html);
		
		 //Ajout d'un bouton retour dans le titre
		var backButton = $('.backButton');
		backButton.click(function(){
		  //On vide le contenu et on affiche l'interface de gestion
		  $('#contenu').empty();
		  displayInterfaceGestionContainer();

		});
	
		var planetes = [];
		$.post("controller/planete/allPlanetes.php", {}, function(data){
			$.each(JSON.parse(data), function(i, planete){
				planetes[planetes.length] = {name: planete.nom_planete, coordX : planete.coordonnee_x, coordY : planete.coordonnee_y, km : hypothenus(planete.coordonnee_x, planete.coordonnee_y)};
			});
			
		})
		.done(function(){
			  var canvas = document.getElementById('canvas_planetes'); //WIDTH : 800 HEIGHT : 300
			  var dimensions = canvas.getBoundingClientRect();
			  var context = canvas.getContext('2d');
			  var coef = 2;
			  var xLocked = null;
			  var yLocked = null;
			  

			  canvas.addEventListener('mousemove', function(evt) {
				  coef = Math.round(getMaxKm(planetes)/60);
				  if(coef == 0) coef = 2;
				  var maxKm = getMaxKm(planetes)/coef;
				
				var mousePos = getMousePos(canvas,coef, evt);
				var message = "";
				var x = Math.round(mousePos.x);
				var y = Math.round(mousePos.y);
				if(hypothenus(x, y) > maxKm){ 
					context.clearRect(0, 0, canvas.width, canvas.height);
					if(xLocked != null && yLocked !=null){ drawSelectionPlanete(canvas, xLocked, yLocked);}
					else{                   drawSelectionPlanete(canvas, x, y);}
					message = "X : " + x*coef*100 + " -- Y : " + y*coef*100 + " -- Distance : " + Math.round(Math.sqrt(x*coef*100 * x*coef*100 + y*coef*100 * y*coef*100)) + "Km";
					writeText(canvas, message, 'red');
				}
				drawBase(canvas, coef);
				drawPlanetes(planetes, canvas, coef);
			  }, false);
			  
			  canvas.addEventListener('mouseup', function(evt) {
				  var maxKm = getMaxKm(planetes)/coef;
				var mousePos = getMousePos(canvas, coef, evt);
				if(hypothenus(mousePos.x, mousePos.y) > maxKm){
					var inputX = $('#coordXPlanete');
					var inputY = $('#coordYPlanete');
					var inputKM = $('#nombreKM');
					var x = Math.round(mousePos.x)*coef*100
					var y = Math.round(mousePos.y)*coef*100
					inputX.val(x);
					inputY.val(y);
					inputKM.val(Math.round(hypothenus(x, y)));
					xLocked = x/(coef*100);
					yLocked = y/(coef*100);
				}
			  }, false);
				$('.btn_gestionPlanete').click(function(){
					var nom = $('#nom_planete').val();
					var descr = $('#descr_planete').val();
					var img = $('#_file');
					var num = $('#id_planete').val();
					var bonusXP = $('#bonus_xp').val();
					var bonusPoints = $('#bonus_points').val();
					var coordX = $('#coordXPlanete').val()/100;
					var coordY = $('#coordYPlanete').val()/100;
					//On ajoute la planete en BDD 
					ajoutPlanete(nom, descr, img, num, bonusXP, bonusPoints, coordX, coordY);
					//On vide et on affiche l'interface de gestion
					$('#contenu').empty();
					displayInterfaceGestionContainer();
				});
		});
	});
	
  
}
function drawCircle(canvas, x, y, r, color, fill){
      if(fill == 'undefined') fill= false;
	  var rect = canvas.getBoundingClientRect();
      var context = canvas.getContext('2d');
	  var ratioX = canvas.width / rect.width;
	  var ratioY = canvas.height / rect.height;
		x += rect.width/2 * ratioX;
		y += rect.height/2 * ratioY;
		context.beginPath();
		context.arc(x, y, r, 0, 2*Math.PI);
		context.fillStyle = color;
		if(fill) context.fill();
		else context.stroke();
}
function getMousePos(canvas, coef, evt) {
    var rect = canvas.getBoundingClientRect();
	var ratioX = canvas.width/canvas.clientWidth;
	var ratioY = canvas.height/canvas.clientHeight;
    return {
		x : (evt.clientX - (rect.left + rect.width/2))*ratioX,
		y : (evt.clientY - (rect.top + rect.height/2))*ratioY
    };
}
function drawPlanetes(planetes, canvas, coef){
	for(var i = 0; i < planetes.length; i++){
			var yPlan = planetes[i].coordY/coef;
			var xPlan = planetes[i].coordX/coef;
			drawCircle(canvas, xPlan, yPlan, 10+hypothenus(xPlan, yPlan)*0.1, 'red', true);
			drawCircle(canvas, xPlan, yPlan, 10+hypothenus(xPlan, yPlan)*0.1, 'black', false);
		}
}
function drawSelectionPlanete(canvas, x, y){
	drawCircle(canvas, 0, 0, Math.sqrt(x*x + y*y), 'black');
	drawCircle(canvas, x, y, 10+hypothenus(x, y)*0.1, 'black', true);
}
function drawBase(canvas, coef){
	drawCircle(canvas, 0, 0, 50/coef, 'blue', true);
}
function writeText(canvas, message, color, x, y){
	if(typeof x == 'undefined') x = 0;
	if(typeof y == 'undefined') y = 0;
    var context = canvas.getContext('2d');
    context.font = '18pt Calibri';
    context.fillStyle = color;
    context.fillText(message, x, y);
}
function hypothenus(x, y){
	return Math.sqrt(x*x + y*y);
}
function getMaxKm(planetes){
		var maxKm = 0;
		$.each(planetes, function(i, planete){
			if(maxKm < planete.km)
				maxKm = planete.km;
		});
		return maxKm;
}
function getMinKm(planetes){
		var minKm = 0;
		$.each(planetes, function(i, planete){
			if(minKm > planete.km)
				minKm = planete.km;
		});
		return minKm;
}

function ajoutPlanete(nom, descr, img, num, bonusXP, bonusPoints, coordX, coordY){
	var chemin = upload(img[0], 'planetes/');
	console.log(chemin);
	$.ajax({
		type : 'post',
		url : 'controller/planete/newPlanete.php',
		data : {id_planete : num,
				nom_planete : nom,
				descr_planete : descr,
				img : chemin,
				bonus_xp : bonusXP,
				bonus_points : bonusPoints,
				coordXPlanete : coordX,
				coordYPlanete : coordY},
		success : function(data){
		}
	});
	return true;
}



function DisplayConsulterNiveau()
{
	$.post("controller/planete/afficherAllPlanetes.php", {}, function(html){
		$("#contenu").html(html);
		
		
		 //Ajout d'un bouton retour dans le titre
		var backButton = $('.backButton');
		backButton.click(function(){
		  //On vide le contenu et on affiche l'interface de gestion
		  $('#contenu').empty();
		  displayInterfaceGestionContainer();

		});
		
		$('.modifier').click(function(){
			var id = $(this).data('planete');
			$('#contenu').empty();
			DisplayModifierNiveau(id);
		});
	});
}

function getPlaneteById(planetes, id){
	var retour = {};
	var trouve = false;
	$.each(planetes, function(i, planete){
		if(planete.id == id){
			trouve = true;
			retour = planete;
		}
	});
	if(!trouve){
		retour = {id : -1, name : "", coordX : 0, coordY : 0, km : 0}; //"Planete" par defaut si on ne trouve rien
	}
	return retour;
}

function DisplayModifierNiveau(idplanete){
	$.post("controller/planete/formulaireModifierPlanete.php", {id_planete : idplanete}, function(html){
		$("#contenu").html(html);
		
		
		 //Ajout d'un bouton retour dans le titre
		var backButton = $('.backButton');
		backButton.click(function(){
		  //On vide le contenu et on affiche l'interface de gestion
		  $('#contenu').empty();
		  displayInterfaceGestionContainer();

		});
	
		var planetes = [];
		$.post("controller/planete/allPlanetes.php", {}, function(data){
			$.each(JSON.parse(data), function(i, planete){
				if(planete.id_planete != idplanete)											//On recupere les planetes autre que celle actuelle
				{
					var km = hypothenus(planete.coordonnee_x, planete.coordonnee_y)
					planetes[planetes.length] = {id : planete.id_planete, name: planete.nom_planete, coordX : planete.coordonnee_x, coordY : planete.coordonnee_y, km : km};
				}
			});
			
		})
		.done(function(){
			  var canvas = document.getElementById('canvas_planetes'); //WIDTH : 800 HEIGHT : 300
			  var dimensions = canvas.getBoundingClientRect();
			  var context = canvas.getContext('2d');
			  var coef = 2;
			  var xLocked = null;
			  var yLocked = null;
			  var planeteInf = getPlaneteById(planetes, idplanete-1);
			  var planeteSup = getPlaneteById(planetes, idplanete+1);
			  
			  

			  canvas.addEventListener('mousemove', function(evt) {
				  coef = Math.round(planeteSup.km/60);
				  if(coef == 0) coef = 2;
				  var maxKm = planeteSup.km/2;
				  var minKm = planeteInf.km;
				
				var mousePos = getMousePos(canvas, coef, evt);
				var message = "";
				var x = Math.round(mousePos.x);
				var y = Math.round(mousePos.y);
				if(minKm < hypothenus(x, y) && (hypothenus(x, y) < maxKm || maxKm == 0)){ 
					context.clearRect(0, 0, canvas.width, canvas.height);
					if(xLocked != null && yLocked !=null){ drawSelectionPlanete(canvas, xLocked, yLocked);}
					else{                   drawSelectionPlanete(canvas, x, y);}
					message = "X : " + x*coef*100 + " -- Y : " + y*coef*100;
					writeText(canvas, message, 'red');
				}
				drawBase(canvas, coef);
				drawPlanetes(planetes, canvas, coef);
			  }, false);
			  
			  canvas.addEventListener('mouseup', function(evt) {
				  var maxKm = planeteSup.km/2;
				  var minKm = planeteInf.km;
				  
				var mousePos = getMousePos(canvas, coef, evt);
				var x = Math.round(mousePos.x);
				var y = Math.round(mousePos.y);
				if(minKm < hypothenus(x, y) && (hypothenus(x, y) < maxKm || maxKm == 0)){ 
					var inputX = $('#coordXPlanete');
					var inputY = $('#coordYPlanete');
					var inputKM = $('#nombreKM');
					var x = Math.round(mousePos.x)*coef*100
					var y = Math.round(mousePos.y)*coef*100
					inputX.val(x);
					inputY.val(y);
					inputKM.val(Math.round(hypothenus(x, y)));
					xLocked = x/(coef*100);
					yLocked = y/(coef*100);
				}
			  }, false);
				$('.btn_gestionPlanete').click(function(){
					var nom = $('#nom_planete').val();
					var descr = $('#descr_planete').val();
					var img = $('#_file');
					var num = $('#id_planete').val();
					var bonusXP = $('#bonus_xp').val();
					var bonusPoints = $('#bonus_points').val();
					var coordX = $('#coordXPlanete').val()/100;
					var coordY = $('#coordYPlanete').val()/100;
					//On ajoute la planete en BDD 
					modifierPlanete(idplanete, nom, descr, img, num, bonusXP, bonusPoints, coordX, coordY);
					//On vide et on affiche l'interface de gestion
					$('#contenu').empty();
					displayInterfaceGestionContainer();
				});
		});
	});
}

function modifierPlanete(id, nom, descr, img, num, bonusXP, bonusPoints, coordX, coordY){
	var chemin = null;
	if(img.val() != "")	upload(img[0], 'planetes/');
	console.log(chemin);
	$.ajax({
		type : 'post',
		url : 'controller/planete/modifyPlanete.php',
		data : {id_planete : num,
				nom_planete : nom,
				descr_planete : descr,
				img : chemin,
				bonus_xp : bonusXP,
				bonus_points : bonusPoints,
				coordXPlanete : coordX,
				coordYPlanete : coordY},
		success : function(data){
		}
	});
	return true;
}

function afficherMap(id_facebook)
{
	
	$.post("controller/planete/miniMap.php", {}, function(html){
		var divMap = $('<div id="minimap">');
		$('body').append(divMap)
		divMap.html(html);
		$('#bg_planete').click(function(){
			divMap.remove();
			return 0;
		});
		
	
		var planetes = [];
		$.post("controller/planete/allPlanetesByInternaute.php", {id_facebook : id_facebook}, function(data){
			$.each(JSON.parse(data), function(i, planete){
				planetes[planetes.length] = {name: planete.nom_planete, coordX : planete.coordonnee_x, coordY : planete.coordonnee_y, km : hypothenus(planete.coordonnee_x, planete.coordonnee_y)};
				  
			});
			var canvas = document.getElementById('canvas_planetes'); //WIDTH : 800 HEIGHT : 300
			var dimensions = canvas.getBoundingClientRect();
			var context = canvas.getContext('2d');
			context.clearRect(0, 0, canvas.width, canvas.height);
			var coef = Math.round(getMaxKm(planetes)/60);
			var xLocked = null;
			var yLocked = null;
			if(coef == 0) coef = 2;
			var maxKm = getMaxKm(planetes)/coef;
			drawBase(canvas, coef);
			drawPlanetes(planetes, canvas, coef);
				
			canvas.addEventListener('mousemove', function(evt) {
				context.clearRect(0, 0, canvas.width, canvas.height);
				drawBase(canvas, coef);
				drawPlanetes(planetes, canvas, coef);
				$.each(planetes, function(i, planete){
					var posX = getMousePos(canvas, coef, evt).x*coef;
					var posY = getMousePos(canvas, coef, evt).y*coef;
					var rect = canvas.getBoundingClientRect();
					var ratioX = canvas.width / rect.width;
					var ratioY = canvas.height / rect.height;
					if(Math.abs(posX - planete.coordX) < 30 && Math.abs(posY - planete.coordY) < 30){
						writeText(canvas, planete.name, 'red', 20+planete.coordX/coef + rect.width/2 * ratioX, 20+planete.coordY/coef + rect.height/2 * ratioY);
					}
				});
			});
		});
	});
}