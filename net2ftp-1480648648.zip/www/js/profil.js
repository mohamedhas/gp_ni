function MajNbMessage(idfacebook) {

	$.post("controller/joueur/majNbMessage.php",
			{
				"id_facebook":idfacebook
			}, function(data) {
				console.log(data);
			},"json");
}
function displayXPProfile(){
	$.ajax({

		url:"controller/joueur/displayProfile.php",
		method:'get',
		data : {"idfacebook" : idfacebook},
		dataType:'json',
		success:function(data){

			$.each(data, function(i,infos_profile){
				var dist = $("#distanceXP");
				var vaisseau = $("#vaisseauXP");
				var percente = (infos_profile.experience / infos_profile.exp_requis) * 100;
				var ratio = (infos_profile.experience / infos_profile.exp_requis);
				var maxWidth = $('.progressbar-back').width();
				var barre = $('.progressbar-front');
				barre.css('width', maxWidth*ratio);
				dist.empty();
				dist.append(infos_profile.experience*100 + " / " + infos_profile.exp_requis*100 + "km");
				vaisseau[0].style.left = (maxWidth*ratio - 25) + 'px';
			});
		}
	});
	
}
function displayInfosProfile(){
	$.ajax({

		url:"controller/joueur/displayProfile.php",
		method:'get',
		data : {"idfacebook" : idfacebook},
		dataType:'json',
		success:function(data){

			$.each(data, function(i,infos_profile){
			console.log(infos_profile);
			var div = $('#info_profile_home');
			var photo = $('#photo_once');
			photo.attr('src', 'https://graph.facebook.com/' + infos_profile['id_facebook'] + '/picture?type=large');

			var right = $("<div/>");
			right.attr('id','right_profile');

                     /////////////////////////////////////////////   

                       			
			var level = $("<div "/*+themeColor2*/+" id='level'/>");
			level.append(infos_profile.num_niveau + " planètes");
			$('.home_profile').append(level);

			
                                    ////Ne garder que le pseudo
                        /*var firstname = $("<div "/*+themeColor2*//*+" id='nom'/>");
                        firstname.append(infos_profile.nom);
                        $(".home_profile").append(firstname);
                        */
			
                        /*
			var name = $("<div "/*+themeColor2*//*+" id='name'/>");
			name.append(infos_profile.prenom);
			$('.home_profile').append(name);*/
			if(infos_profile.id_titre != null)
			{
				var titre = $("<div id='titre' />");
				titre.append(" - " + infos_profile.libelle_titre);
				$('.home_profile').append(titre);
			}
                        
                        var pseudo = $("<div "/*+themeColor2*/+" id='pseudo'/>");
                        pseudo.append(infos_profile.pseudo);
                        $('.home_profile').append(pseudo);


/*
			//REMPLISSAGE DE LA BARRE D'EXPERIENCE

			$.ajax({

			url:"./controller/joueur/displayProfile.php",
			method:'get',
			data : {idfacebook : idfacebook},
			dataType:'json',
			success:function(data){

				$.each(data, function(i, exp){
				*/
				var dist = $("<p id='distanceXP' style='position:absolute; width:100%; top:15px;' />");
				var vaisseau = $("<img id='vaisseauXP' style='position:absolute; width : 50px; top:-5px' src='assets/vaisseau.png' />");
				var percente = (infos_profile.experience / infos_profile.exp_requis) * 100;
				var ratio = (infos_profile.experience / infos_profile.exp_requis);
				var maxWidth = $('.progressbar-back').width();
				var barre = $('.progressbar-front');
				barre.css('width', maxWidth*ratio);
				dist.append(infos_profile.experience*100 + " / " + infos_profile.exp_requis*100 + "km");
				vaisseau[0].style.left = (maxWidth*ratio - 25) + 'px';   //image de 50px (/2 pour avoir le milieu)
				/*
				$('.progress-pie-chart').attr('data-percent', Math.round(percente));

				  var $ppc = $('.progress-pie-chart'),
				    percent = parseInt($ppc.data('percent'));
				    //deg = 360*percent/100;
				  if (percent > 50) {
				    $ppc.addClass('gt-50');
				  }
				  $('.ppc-progress-fill').css('width', $('.ppc-percents').width()*percent/100);//'transform','rotate('+ deg +'deg)');
				  $('.ppc-percents span').html(percent+'%');
*/
				//var progress = $('<progress value='+ exp.exp+' max='+exp.exp_requise+' id="progress_bar"></progress>');

				
				//div.append(progress);
				div.append(dist);
				div.append(vaisseau);
				$('#home_profile').append(div);

	/*			})


				}*/
			//});

			div.prepend(right);
			//div.append(progress);
			$('#home_profile').append(div);

		});


		}
	})
.error(function(a, b){
console.log(a + " " + b + " ");
});

}


function verifExistence(nom, prenom){
	console.log("VERIF POUR " + prenom + " " + nom);
	$.ajax({
    url:"./controller/verif/verifExistence.php",
    type:'get',
    data : "idfacebook=" + idfacebook,
    dataType:'json',
    success:function(data){
                         console.log(data);
				$.each(data, function(i,infos){
					console.log("Verification de l'existence réussie !");
					console.log("User actuel : " + infos.nom);
					if (infos.nom != "")
					{
						utilisateurConnecte = true;
						updateInfosProfile();
						console.log("update infos ?");
					}
					if(infos.est_nouveau == true)
					{
						console.log("Nouveau utilisateur!");
						utilisateurConnecte = false;
						displayWelcomeNouveau(nom, prenom);
					}
				});
				
				if(data.length === 0){
					utilisateurConnecte = false;
					console.log("insertion nécessaire");
					displayWelcomeNouveau(nom, prenom);
				}
		}


});
}




function insertNewProfile(nomInternaute, prenomInternaute, pseudoInternaute, departementInternaute, fonction){
		var url = "https://graph.facebook.com/" + idfacebook + "/picture?type=large";
		console.log(url);
		console.log(nomInternaute + "    " + prenomInternaute);
		//Récupération de l'URL de la photo de profil
		$.ajax({
	    url: url,
	    type:'get',
	    dataType:'json',
	    success:function(data){

						$.each(data, function(i, informationsFacebook){
							console.log(informationsFacebook);
							console.log(informationsFacebook.url);
						});
			}


	});


	$.ajax({

		url:"./controller/joueur/insertProfile.php",
		method:'get',
                async : false,
		data : {id_facebook : idfacebook, nom_internaute : nomInternaute, prenom_internaute : prenomInternaute, pseudo_internaute : pseudoInternaute, url_internaute : url, dept_internaute : departementInternaute},
		dataType:'json',
		success:function(data){
			if(JSON.parse(data) == true){
				fonction(true);
				console.log("insertion d'un nouvel utilisateur réussie");
			}
			else{
				fonction(false);
			}
		}

	});
}

function updateInfosProfile(){
/*VIDE???*/
	};



function updateStats(){
/*
	$.ajax({

		url:"./controller/joueur/recupNombreMessages.php",
		method:'get',
		data : {idfacebook : idfacebook},
		dataType:'json',
		success:function(data){
				console.log("update d'un nouvel utilisateur réussie : "+data);

		}

		});
*/
}

$(document).ready(function(){

$('.profil').click(function(){
		updateStats();
		loadProfile(idfacebook);

	});
});
/* MISE A JOUR DU NOMBRE DE MESSAGE DISPONIBLE SUR LE PROFIL DE L'INTERNAUTE */




function loadProfile(current_user_id){
	$.ajax({

		url:"controller/joueur/profil.php",
		method:'get',
		data : {idfacebook : current_user_id},
		success:function(html){
			
			//CREATION DU BACKGROUND
			var existenceBG = $('#bg');
			if(existenceBG.length){

			}else{
			var div_bg = $("<div/>");
			div_bg.attr('id','bg');
			div_bg.css('top', window.scrollY + 'px');
			$("body").css('overflow','hidden');
			$("body").append(div_bg);
			$(div_bg).append(html);
			/*$("#lightbox").css('width', window.innerWidth - window.innerWidth/4);
			$("#lightbox").css('height', window.innerHeight - window.innerHeight/2);
			$("#lightbox").css('left', window.innerWidth/8);*/
			
		



			}
			if(admin){
				var btnBan = $("<button id='btn_ban'>Bannir ce joueur</button>");
				$('#profile_stats').append(btnBan);
				btnBan.click(function(){
					refuserNouveau(current_user_id, false);
				});
			}
			$('#affichePlanete').click(function(){
				afficherMap(current_user_id);
			});
                        
                        //VIDE LA DESCRIPTION
                        $('#user').click(function(){
                               // contenu_desc.empty();
                        });



			//CREATION DE LA CROIX DE FERMETURE
                        
			$('#croix').click(function(){
				div_bg.remove();

				$("body").css('overflow','visible');
			});

				$('.escape').click(function(){
				div_bg.remove();

				$("body").css('overflow','visible');
			});


			$("body").keyup(function(event){
				if(event.which == 27){
					$(div_bg).remove();
					$("body").css('overflow','visible');
				}
			});
			var param_titre = $('.param_titre');
			if(current_user_id != idfacebook)
				param_titre.css('visibility', 'hidden');
			
			$.ajax({
				url:"./controller/titre/allTitresById.php",
				type:'post',
				data : "idfacebook="+current_user_id,
				dataType:'json',
				success:function(titres){
					var selectTitre = $("<select id='select_titre'></select>");
					optDefaut = $("<option selected='selected' value='' >Titres disponibles</option>");
					selectTitre.append(optDefaut);

					$.each(titres, function(i, titre){
						var optTitre = $("<option value="+titre.id_titre+">"+titre.libelle_titre+"</option>");
						selectTitre.append(optTitre);
					});
				
					var profile_titre = $('#profile_titre');
					
					param_titre.click(function(){
						profile_titre.append(selectTitre.show());
					});


					selectTitre.change(function(){

						$.ajax({
							url:"./controller/titre/updateTitre.php",
							type:'get',
							data : "idtitre=" + selectTitre.val() + "&idfacebook=" + current_user_id,
							dataType:'json',
							success:function(data){
								selectTitre.fadeOut();
								console.log("Select changé");
								$('#contenu_titre').fadeOut(100).empty().delay(100).fadeIn();
								loadTitre(selectTitre.val());

							}
						});	
					});
				}
			});

				
				
			
			
			var param_titre_left = $('.param_titre_left');
			if(current_user_id != idfacebook)
				param_titre_left.css('visibility', 'hidden');
			var textDescription = "";
						$.ajax({

						url:"./controller/joueur/displayProfile.php",
						method:'get',
						data : {idfacebook : current_user_id},
						dataType:'json',
						success:function(data){

							$.each(data, function(i,infos_profile){
								var div = $('#contenu_desc');
								textDescription = infos_profile.description;
								console.log(textDescription);

						});


					}
				});
			param_titre_left.click(function(){
				
				var division_modif = $('<div id="modif_desc"/>');
				var parametreModif = 'placeholder="Décris toi et partage tes qualités !"';
				if(textDescription != "")
					parametreModif = '';
				var text_area = $('<textarea ' + parametreModif + ' class="validate[required,custom[onlyLetter],length[0,100]] feedback-input" name="editor2" id="textarea_desc"/>');
				text_area.append(textDescription);
				var bouton_maj_desc = $("<button id='btn_modifier_desc'>Modifier</button>");
				var contenu_desc = $('#contenu_desc');
				contenu_desc.fadeOut(100).empty().delay(100).append(division_modif).fadeIn();
				contenu_desc.append(division_modif);
				division_modif.append(text_area);
				division_modif.append(bouton_maj_desc);


				bouton_maj_desc.click(function(){
					var newDesc = $('#textarea_desc').val();
					$.post(

							"./controller/joueur/modifDescription.php",
							{
								"description" : newDesc,
								"id_facebook" : current_user_id
							},
							function(question, data){
								textDescription = newDesc;
							    contenu_desc.empty();
								contenu_desc.append(newDesc);
							}, "json").fail(function(a,b,c){

								console.log(a,b,c);
							});
				});
			});
			
		}
	});
}

function loadTitre(idtitre){
	$.ajax({
		url:"./controller/joueur/recupTitre.php",
		type:'get',
		data : "idtitre=" + idtitre,
		dataType:'json',
		success:function(data){

			$.each(data, function(i, titre){
				$('#contenu_titre').append(titre.libelle_titre);
			});



		}
	});

}