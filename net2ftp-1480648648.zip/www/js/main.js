//function $(id) { return document.getElementById(id); }

	var admin = false;
	var modo = false;
	
function init() {
	//var varTemp =0;
	
        provenance = "accueil";
	console.log(idfacebook);

	ResetPointsOnLoad();
	isAdministrateur(function(x){admin=x;});
	isModerateur(function(x){modo=x;});
	displayRechercheContainer();
	displayQuestionsRecentesContainer();
	displayBestPlayerContainer();
	displayRecompensesContainer();
	initTheme();
	checkTheme();
	displayProfileContainer();
    checkObtentionBadge();
	verifNotification();





	var div_titre_menu = $("<div "+themeColor2+" class='div_titre' '/>");
	var titreMenu = $('<h1 '+themeColor2+' class="titre_menu">MENU</h1>');
	div_titre_menu.append(titreMenu)
	$('#side_button').append(div_titre_menu);


	console.log("Lien URL :" + $("#photo_once").attr("src"));

	
	var div_developper = document.getElementById("developper_profil");
	var div_hidden = document.getElementById("hidden_profile_lines");
	var image_developper = document.getElementById("#image_developper");

	$("#developper_profil").click(function(){
		console.log(admin + " -- " + modo);
		if(div_hidden.style.top != "-20px"){
			$("#hidden_profile_lines").css("top", '-20px');
			$("#image_developper").css('transform', 'rotate(0deg)'); 
		}
		else {
			$("#hidden_profile_lines").css("top", '60px');
			$("#image_developper").css('transform', 'rotate(180deg)');
		}			
		
	});
	$(".accueil").click(function(){


		$("#contenu").empty();
                provenance = 'accueil';
		
		ResetPointsOnLoad();
		displayQuestionsRecentesContainer();//
		displayBestPlayerContainer();//
		displayBestPlayerFullContainer();



		var contenu_div_index = $("<div id='contenu_div_index'></div>");
		$("#contenu").append(contenu_div_index);
		var div_titre_menu = $("<div "+themeColor2+" id='div_titre' />");
		var div_titre_menu = $("<div "+themeColor2+" id='div_titre' />");
		var titreMenu = $('<h1 '+themeColor2+' class="titre_menu">MENU</h1>');
		div_titre_menu.append(titreMenu);
		$('#side_button').append(div_titre_menu);
	});
	$("#btn_questionByCategory").click(function(){
                       alert("probleme de redirection dans le main.js ou le button.js ");
		$('#contenu').children().remove();
		if ( $( "#menucat" ).length )
			// $('#contenu').remove();
			$('#menucat').remove();
		else
			displayAllCategories();
	});
	// $('.categorie').click(function(){
		// alert('categorie');
	// });
	$("#classements").click(function(){
		displayBestPlayerFull();}
	);
	
	
	
	

	$("#poster_question").click(function(){
		displayFormPosterQuestionContainer();
		displayBestPlayerContainer();

	});
	$("#nav-departement").click(function(){
		displayDepartementContainer();
		displayBestPlayerContainer();
	});
	$('#all_questions').click(function(){
		provenance = 'all_questions';

		displayAllQuestionsContainer();
		displayBestPlayerContainer();

	});

	$('.my_questions').click(function(){
		displayMyQuestionContainer();
		displayBestPlayerContainer();
		provenance = 'my_questions';
	});

	$("#btnInterfaceGestion").click(function(){
			displayInterfaceGestionContainer();
	});

	$("#nav-reponses_abusives").click(function(){
		displayReponsesAbusivesContainer();
		displayBestPlayerContainer();
	});
	$("#nav-questions_abusives").click(function(){
		displayQuestionsAbusivesContainer();
		displayBestPlayerContainer();
	});

	$('.puces_classement').each(function(){
		$(this).hover(function(){

			$('.pointsInternaute').each(function(){
				$(this).css('background-color','white').css('color','#297CBE');
			})

	});

	});

}


function ResetPointsOnLoad() {

	resetPoints();
}

function initTheme(){
	//checkTheme();
}

function displayProfileContainer(){
	displayInfosProfile();
	updateInfosProfile();
}
//Les classements
function displayBestPlayerContainer(){
/*
	displayBestPlayer();

*/
};

function displayMyRankContainer() {
	displayMyRank();
}






function displayRecompensesContainer(){
	//displayRecompenses();
}

function displayFormPosterQuestionContainer() {
	$("#contenu").empty();
	$("#side_button li").removeClass("active");
	$(this).addClass("active");

	displayFormPosterQuestions();


};

function displayInterfaceGestionContainer(){
	$("#contenu").empty();
	displayInterfaceGestion();
}

function displayCategoriesContainer() {
	$("#side_button li").removeClass("active");
	$(this).addClass("active");
	$("#contenu").empty();

	displayAllCategories();
};

function displayAllQuestionsContainer(){
	$("#side_button li").removeClass("active");
	$(this).addClass("active");
	$("#contenu").empty();

	displayAllQuestions();
	//displayQuestionsRecentes();
};

function displayQuestionsRecentesContainer() {

	displayQuestionsRecentes();

};

function displayMyQuestionContainer() {
	$("#contenu").empty();
	displayMyQuestions(idfacebook, 1);

}


//QUESTION VIA LES MATIERE VIA LES CATEGORIES VIA LES DEPARTEMENT
function displayDepartementContainer() {
	$("nav li").removeClass("active");
	$(this).addClass("active");
	$("#contenu").empty();
	displayAllDepartement();
}




//RECHERCHE
function displayRechercheContainer(){
		provenance = 'search';
	formRecherche();
}


function upload(file, path){
	
	var chemin = "";
	console.log(typeof file + " " + typeof file.files + " " + file.files);
    if(file.files.length === 0){
        return;
    }

    var data = new FormData();
    data.append('SelectedFile', file.files[0]);
    data.append('path', path);

    var request = new XMLHttpRequest();
    request.onreadystatechange = function(){
        if(request.readyState == 4){
            try {
                var resp = JSON.parse(request.response);
            } catch (e){
                var resp = {
                    status: 'error',
                    data: 'Unknown error occurred: [' + request.responseText + ']'
                };
            }
            console.log(resp.status + ': ' + resp.data);
			chemin = resp.data;
        }
    };

    request.open('POST', 'controller/files/uploadFile.php', false);
    request.send(data);
	return chemin;
}

function readURL(input, idImg) {

    if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
            $(idImg).attr('src', e.target.result);
        }

        reader.readAsDataURL(input.files[0]);
    }
}	
function htmlEntities(str) {
	return str.replace(/<script/gi, '&lt;script').replace(/\son[a-z]+=/gi, 'XXXX_BLOCKED=');
    //return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}