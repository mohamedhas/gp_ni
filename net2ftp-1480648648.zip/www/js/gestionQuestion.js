


function gestionQuestion(){
$('section').empty();
	var h1 = $("<h1>Questions</h1>");
	$("section").append(h1);

	/*
	Afficher question
	*/
	$.ajax({
		url:'./controller/displayQuestion.php', 
		method : "get",
		dataType : "json",

		success:function(questions){
			var ul = $("<ul />");
			$("section").append(ul);
			$.each(questions, function(i, question) {
				var li = $("<li class='question_"+i+"'/>");
				var btn_modif = $("<button id='btnModif_"+i+"'>Modifier</button>");
				var btn_suppr = $("<button id='btnDelete_"+i+"'>Supprimer</button>");
				li.data("question",question);
				li.addClass("question");
				li.append("<span class='valeur'>"+question.texte+"</span>");
				li.append(btn_modif);
				li.append(btn_suppr);
				ul.append(li);
				$("#btnDelete_"+i).click(function(){

				$.post(

					"./controller/supprQuestion.php", 
					{
						"id_question" : question.id_question
					},
					function(question) {
						console.log(question); 
						$(".question_"+i).fadeOut();
					},"json").fail(function(a,b,c){
						console.log(a,b,c);
					});

				});

				$("#btnModif_"+i).click(function(){
					
					var div = $("<div id='divarea'/>");
					$("section").append(div);

					var area = $("<textarea class='area' name='valeur_question' shape='rect'>"+question.texte+"</textarea>");
					div.append(area);
					var btn_validarea = $("<button name='btnarea' id='btnValide_"+i+"'>Valider</button>"); 
					div.append(btn_validarea);

					$("#btnValide_"+i).click(function(){
						$.post(

							"./controller/modifQuestion.php",
							{
								"id_question" : question.id_question,
								"valeur_question" : $(".area").val()
							},
							function(question){
								location.reload();
							}, "json").fail(function(a,b,c){
								console.log(a,b,c);
							});

					});
						

				});



				

			});

		},
	});

	





};






