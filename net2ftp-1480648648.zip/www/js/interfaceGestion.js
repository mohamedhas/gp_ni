$(document).ready(function(){



});



function displayInterfaceGestion(){

  var contenu = $('#contenu');
  var div_titre_main = $('<div '+themeColor2+'  id="div_titre"></div>');
  var titre = $('<h1 '+themeColor2+' class="titre_main">GESTION</h1>');
  div_titre_main.append(titre);
  $("#contenu").append(div_titre_main);




  //ZONE CONTENANT LES DIV DE GESTION
  var zoneGestion = $('<div />');
  zoneGestion.addClass('divGestion');
  contenu.append(zoneGestion);

  //NOUVEAUX INSCRITS

  var divNouveaux = $('<div />');
  divNouveaux.attr('id','divGestionNouveaux');
  var titre = $('<h1 '+themeColor1+' class="titreGestion">NOUVEAUX INSCRITS</h1>');
  divNouveaux.append(titre);
  zoneGestion.append(divNouveaux);

  var btnGestionNouveauxInscrits = $('<button '+themeColor1+' id="btnGestionQuestionsAbusives">Gérer les nouveaux inscrits</button>');


  btnGestionNouveauxInscrits.addClass("btnGestion");

  divNouveaux.append(btnGestionNouveauxInscrits);

      ///GESTION DES CLICS
          //questions
              btnGestionNouveauxInscrits.click(function(){
                $("#contenu").empty();
              	displayAllNouveauxInscrits();

              });

  //ZONE QUESTIONS REPONSES

  var divQR = $('<div />');
  divQR.attr('id','divGestionQR');
  var titre = $('<h1 '+themeColor1+' class="titreGestion">QUESTIONS & REPONSES</h1>');
  divQR.append(titre);
  zoneGestion.append(divQR);

  var btnGestionQuestionsAbusives = $('<button '+themeColor1+' id="btnGestionQuestionsAbusives">Gérer les questions abusives</button>>');
  var btnGestionReponsesAbusives = $('<button '+themeColor1+' id="btnGestionReponsesAbusives">Gérer les réponses abusives</button>');


  btnGestionReponsesAbusives.addClass("btnGestion");
  btnGestionQuestionsAbusives.addClass("btnGestion");

  divQR.append(btnGestionReponsesAbusives);
  divQR.append(btnGestionQuestionsAbusives);

      ///GESTION DES CLICS
          //questions
              btnGestionQuestionsAbusives.click(function(){
                $("#contenu").empty();
              	displayAllQuestionsAbusives();

              });
          //r�ponses
              btnGestionReponsesAbusives.click(function(){
                $("#contenu").empty();
                displayAllReponsesAbusives();
              });

  //BADGES

    var divGestionBadges = $('<div />');
  divGestionBadges.attr('id','divGestionBadges');
  var titre = $('<h1 '+themeColor1+' class="titreGestion">BADGES</h1>');
  divGestionBadges.append(titre);
  zoneGestion.append(divGestionBadges);

  var btnAjoutBadges = $('<button '+themeColor1+' id="btnAjoutBadges">Ajouter un badge</button>');

  btnAjoutBadges.addClass("btnGestion");
  divGestionBadges.append(btnAjoutBadges);

    ///CLIC SUR AJOUT DE BADGES

    btnAjoutBadges.click(function(){
		
    $('#contenu').empty();
	DisplayAjoutBadge();
	});

  var btnConsulterBadges = $('<button '+themeColor1+' id="btnConsulterBadges">Consulter tous les badges</button>');

  btnConsulterBadges.addClass("btnGestion");
  divGestionBadges.append(btnConsulterBadges);

    ///CLIC SUR AJOUT DE BADGES

    btnConsulterBadges.click(function(){
		
    $('#contenu').empty();
	displayConsulterLesBadges();
	});


  //RECOMPENSES  ON OUBLIE!
  /*


  var divGestionRecompenses = $('<div />');
  divGestionRecompenses.attr('id','divGestionRecompenses');
  var titre = $('<h1 '+themeColor1+' class="titreGestion">RECOMPENSES</h1>');
  divGestionRecompenses.append(titre);
  zoneGestion.append(divGestionRecompenses);

  var btnGererRecompense = $('<button '+themeColor1+' id="btnGererRecompense">Gérer les récompenses</button>');

  btnGererRecompense.addClass("btnGestion");
  divGestionRecompenses.append(btnGererRecompense);

  btnGererRecompense.click(function(){
    $('#contenu').empty();
	displayGererRecompenses();
        });
		*/
//TITRES

   var divGestionTitres = $('<div />');
  divGestionTitres.attr('id','divGestionTitres');
  var titre = $('<h1 '+themeColor1+' class="titreGestion">TITRES</h1>');
  divGestionTitres.append(titre);
  zoneGestion.append(divGestionTitres);

  var btnAjoutTitres = $('<button '+themeColor1+' id="btnAjoutTitres">Ajouter un titre</button>');

  btnAjoutTitres.addClass("btnGestion");
  divGestionTitres.append(btnAjoutTitres);

    ///CLIC SUR AJOUT DE Titres

    btnAjoutTitres.click(function(){
		
    $('#contenu').empty();
	DisplayAjoutTitre();
	});	
  var btnConsulterTitres = $('<button '+themeColor1+' id="btnConsulterTitres">Consulter tous les titres</button>');

  btnConsulterTitres.addClass("btnGestion");
  divGestionTitres.append(btnConsulterTitres);

    ///CLIC SUR AJOUT DE Titres

    btnConsulterTitres.click(function(){
		
    $('#contenu').empty();
	DisplayConsulterTitre();
	});	
	
//CATEGORIE

   var divGestionCategories = $('<div />');
  divGestionCategories.attr('id','divGestionCategories');
  var titre = $('<h1 '+themeColor1+' class="titreGestion">CATEGORIES</h1>');
  divGestionCategories.append(titre);
  zoneGestion.append(divGestionCategories);

  var btnAjoutCategories = $('<button '+themeColor1+' id="btnAjoutCategories">Ajouter une catégorie</button>');

  btnAjoutCategories.addClass("btnGestion");
  divGestionCategories.append(btnAjoutCategories);

    ///CLIC SUR AJOUT DE Categories

    btnAjoutCategories.click(function(){
		
    $('#contenu').empty();
	DisplayAjoutCategorie();
	});
  var btnConsulterCategories = $('<button '+themeColor1+' id="btnConsulterCategories">Consulter toutes les catégories</button>');

  btnConsulterCategories.addClass("btnGestion");
  divGestionCategories.append(btnConsulterCategories);

    ///CLIC SUR AJOUT DE Categories

    btnConsulterCategories.click(function(){
		
    $('#contenu').empty();
	DisplayConsulterCategorie();
	});	
			
//DEPARTEMENTS

   var divGestionDepartements = $('<div />');
  divGestionDepartements.attr('id','divGestionDepartements');
  var titre = $('<h1 '+themeColor1+' class="titreGestion">DEPARTEMENTS</h1>');
  divGestionDepartements.append(titre);
  zoneGestion.append(divGestionDepartements);

  var btnAjoutDepartements = $('<button '+themeColor1+' id="btnAjoutDepartements">Ajouter un département</button>');

  btnAjoutDepartements.addClass("btnGestion");
  divGestionDepartements.append(btnAjoutDepartements);

    ///CLIC SUR AJOUT DE Departements

    btnAjoutDepartements.click(function(){
		
    $('#contenu').empty();
	DisplayAjoutDepartement();
	});	
  var btnConsulterDepartements = $('<button '+themeColor1+' id="btnConsulterDepartements">Consulter tous les départements</button>');

  btnConsulterDepartements.addClass("btnGestion");
  divGestionDepartements.append(btnConsulterDepartements);

    ///CLIC SUR AJOUT DE Departements

    btnConsulterDepartements.click(function(){
		
    $('#contenu').empty();
	DisplayConsulterDepartement();
	});			
//MATIERES

   var divGestionMatieres = $('<div />');
  divGestionMatieres.attr('id','divGestionMatieres');
  var titre = $('<h1 '+themeColor1+' class="titreGestion">MATIERES</h1>');
  divGestionMatieres.append(titre);
  zoneGestion.append(divGestionMatieres);

  var btnAjoutMatieres = $('<button '+themeColor1+' id="btnAjoutMatieres">Ajouter une matière</button>');

  btnAjoutMatieres.addClass("btnGestion");
  divGestionMatieres.append(btnAjoutMatieres);

    ///CLIC SUR AJOUT DE Matieres

    btnAjoutMatieres.click(function(){
		
    $('#contenu').empty();
	DisplayAjoutMatiere();
	});
  var btnConsulterMatieres = $('<button '+themeColor1+' id="btnConsulterMatieres">Consulter toutes les matieres</button>');

  btnConsulterMatieres.addClass("btnGestion");
  divGestionMatieres.append(btnConsulterMatieres);

    ///CLIC SUR AJOUT DE Matieres

    btnConsulterMatieres.click(function(){
		
    $('#contenu').empty();
	DisplayConsulterMatiere();
	});			
//NIVEAUX

   var divGestionNiveaux = $('<div />');
  divGestionNiveaux.attr('id','divGestionNiveaux');
  var titre = $('<h1 '+themeColor1+' class="titreGestion">Planètes</h1>');
  divGestionNiveaux.append(titre);
  zoneGestion.append(divGestionNiveaux);

  var btnAjoutNiveaux = $('<button '+themeColor1+' id="btnAjoutNiveaux">Ajouter une planète</button>');

  btnAjoutNiveaux.addClass("btnGestion");
  divGestionNiveaux.append(btnAjoutNiveaux);

    ///CLIC SUR AJOUT DE Niveaux

    btnAjoutNiveaux.click(function(){
		
    $('#contenu').empty();
	DisplayAjoutNiveau();
	});
  var btnConsulterNiveaux = $('<button '+themeColor1+' id="btnConsulterNiveaux">Consulter toutes les planètes</button>');

  btnConsulterNiveaux.addClass("btnGestion");
  divGestionNiveaux.append(btnConsulterNiveaux);

    ///CLIC SUR AJOUT DE Niveaux

    btnConsulterNiveaux.click(function(){
		
    $('#contenu').empty();
	DisplayConsulterNiveau();
	});	
	
	
	
	
	
	
//Ajout d'un DIV pour l'esthetique
	/*var divFin = $('<div />');
	zoneGestion.append(divFin);*/
	
		
	
	

}





////////////////////////////////////////////////////////////////////


function DisplayAjoutRecompense()
{
	
    var div_titre_main = $('<div '+themeColor2+'  id="div_titre"></div>');
    var titre = $('<h1 '+themeColor2+' class="titre_main">NOUVELLE RECOMPENSES</h1>');
    div_titre_main.append(titre);
    $("#contenu").append(div_titre_main);

    var divNewBadge = $("<form id='target' class='divNewBadge' enctype='multipart/form-data'></form>");
    $("#contenu").append(divNewBadge);

    //var divTitreBadge = $("<span class='titre_badge'><label> Titre du nouveau badge : </label><input type='text'/></span></br>");
    var divLibelleBadge = $("<span class='libelle_badge'><label> Titre de la nouvelle récompense </label></span>");
    var inputTitre = $("<input class='inputTitre' type='text'/>");
	var sautLigne = $("<br />");
    var divImageBadge = $("<span class='image_badge'><label class='label_imageRecompense'> Image de la nouvelle recompense : </label><input type='file' accept='image/* ' class='btn_imageRecompense'/></span>");
    var btn_gestionBadge = $("<button type='submit' class='btn_gestionRecompense'> Sauvegarder </button>");
    $(".divNewBadge").append(divLibelleBadge);
    $(".divNewBadge").append(inputTitre);
	$(".divNewBadge").append(sautLigne);
    $(".divNewBadge").append(divImageBadge);
    $(".divNewBadge").append(btn_gestionBadge);


          $( "#target" ).submit(function() {

            $.ajax({
                url: "controller/recompense/newRecompense.php",
                type: "get",
                data: "photo_recompense="+$form.serialize(),
                success: function (response) {

                console.log(response);
                }
			});
		});
    btn_gestionBadge.click(function() {


        if((inputTitre.val() != "") && (inputDescription.val() != "")) {

          $.post("controller/badges/newBadge.php", {
            "valeur_upload":valeur_upload.val(),
            "libelle_badge":inputTitre.val(),
            "description":inputDescription.val()
           }, function(data) {
            console.log("data : "+data);
          });
            $("#contenu").empty();
            displayInterfaceGestion();
        }
    });

}

function displayACondition(index, valMet, valCom, valVal)
{
	var divUneCondition= $("<div class='uneCondition' />");
	var divCondition = $(".divConditions");
	var cbxMetrique = $("<select id='metrique"+index+"'/>");
	var cbxCompar = $("<select id='compare"+index+"' />");
	var inputValue;
	if(typeof(valVal) == 'undefined'){
		inputValue = $("<input type='text' placeholder='valeur à comparer' id='value"+index+"'/>");
	}
	else{
		inputValue = $("<input type='text' placeholder='valeur à comparer' id='value"+index+"' value='" + valVal + "'/>");
	}
	var btnSuppr = $("<button>Supprimer</button>");
	
	if(typeof(valCom) == 'undefined') cbxCompar.hide();
	if(typeof(valVal) == 'undefined') inputValue.hide();
	
	if(valCom != 'undefined'){
		$.ajax({
				url:"./controller/comparaison/allComparaisons.php", 
				type:'get',
				dataType:'json',		
				success:function(comparaisons){
					cbxCompar.append($("<option value=''>Signe de comparaison</option>"));
					$.each(comparaisons, function(i, comparaison){
						var Option = $("<option value='" + comparaison.id_comparaison + "'>" + comparaison.libelle_comparaison + "</option>");
						if(comparaison.id_comparaison == valCom) Option.attr('selected', 'selected');
						cbxCompar.append(Option);
					});
				}
			});
	}
	
	$.ajax({
		url:"./controller/metrique/allMetriques.php", 
		type:'get',
		dataType:'json',		
		success:function(metriques){
			cbxMetrique.append($("<option value=''>Caracteristique à comparer</option>"));
			$.each(metriques, function(i, metrique){
				var Option = $("<option value='" + metrique.id_metrique + "'>"+ metrique.libelle_metrique +"</option>");
				if(metrique.id_metrique == valMet) Option.attr('selected', 'selected');
				cbxMetrique.append(Option);
				});
		}
	});
	cbxMetrique.change(function(){
		if(!hideCondition(cbxMetrique, cbxCompar, inputValue)){
			cbxCompar.empty();
			cbxCompar.show();
			inputValue.value = "";
			inputValue.hide();
			checkDateInput(cbxMetrique, inputValue);
		
		
			$.ajax({
				url:"./controller/comparaison/allComparaisons.php", 
				type:'get',
				dataType:'json',		
				success:function(comparaisons){
					cbxCompar.append($("<option value=''>Signe de comparaison</option>"));
					$.each(comparaisons, function(i, comparaison){
						var Option = $("<option value='" + comparaison.id_comparaison + "'>" + comparaison.libelle_comparaison + "</option>");
						cbxCompar.append(Option);
					});
				}
			});
			cbxCompar.change(function(){
				inputValue.val("");
				inputValue.show();
				
			});
		}
	});
	
	btnSuppr.click(function(){
		cbxMetrique.hide();
		cbxCompar.hide();
		inputValue.hide();
		$(this).hide();
	});
	
	divUneCondition.append(cbxMetrique);
	divUneCondition.append(cbxCompar);
	divUneCondition.append(inputValue);
	divUneCondition.append(btnSuppr);
	var button = $('#btn_ajouterCondition');
	divUneCondition.insertBefore(button[0]);
}
function hideCondition(metric, comparaison, input)
{
	if(metric[0].value == 5)	//La metrique est 'ANNIVERSAIRE' (id=5)
	{
		comparaison.show();
		comparaison[0].value = 1;
		input.show();
		input[0].value = 1;
		cacherDeLEcran(comparaison, true);
		cacherDeLEcran(input, true);
		return true;
	}
	else{
		cacherDeLEcran(comparaison, false);
		cacherDeLEcran(input, false);
		return false;
	}
}
function checkDateInput(metric, input)
{
	if(metric[0].value == 4) 		//La metrique est 'DATE' (id=4)
	{
		input[0].type = 'date';	//L'input est un calendrier
	}
	else
	{
		input[0].type = 'number'; 	//L'input est du texte
	}
}
function cacherDeLEcran(elementACacher, cacher)
{
	if(cacher)
	{
		document.getElementById(elementACacher[0].id).style.position = 'absolute';
		document.getElementById(elementACacher[0].id).style.left = '10000px';
	}
	else{
		document.getElementById(elementACacher[0].id).style.position = 'relative';
		document.getElementById(elementACacher[0].id).style.left = '0px';
	}
}