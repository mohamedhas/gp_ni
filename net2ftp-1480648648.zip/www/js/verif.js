function VerifTitre() {
	
	var titre = document.getElementById("inputTitre");
	if(titre.value == "")
	{
		titre.style.backgroundColor="red";
		return false;
	}
}

function VerifQuestion() {
	
	var question = document.getElementById("inputValeur");
	if(question.value == "")
	{
		question.style.backgroundColor="red";
		return false;
	}
}


