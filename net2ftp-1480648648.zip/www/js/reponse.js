//FONCTION AFFICHAGE + RETOUR QUESTION REPONSE TOUTES LES QUESTIONS
	function questionReponse(id_question) {

		$("#contenu").empty();
		console.log("test");
		displayUneQuestion(id_question);
		
		//displayFormRepondre(id_question);

		//Ajout d'un bouton retour dans le titre
		var backButton = $('<img src="icon/backButton.png" class="backButton"></img>');
		$('#contenu').append(backButton);

//////////////////////// PROBLEME BOUTON DE RETOUR POUR ACCUEIL ET RECHERCHE
		/*if(provenance == 'accueil'){
			$('.backButton').hide();
		}*/
		if(provenance == 'search'){
			$('.backButton').hide();
		}

		//Gestion du clic du bouton retour
		backButton.click(function(){
			//On vide le contenu et on affiche l'interface de gestion
			$('#contenu').empty();
			switch(provenance) {
  case 'accueil':

		$("#contenu").empty();
                provenance = 'accueil';
		
		ResetPointsOnLoad();
		displayQuestionsRecentesContainer();//
		displayBestPlayerContainer();//
		displayBestPlayerFullContainer();



		var contenu_div_index = $("<div id='contenu_div_index'></div>");
		$("#contenu").append(contenu_div_index);
		var div_titre_menu = $("<div "+themeColor2+" id='div_titre' />");
		var titreMenu = $('<h1 '+themeColor2+' class="titre_menu">MENU</h1>');
		div_titre_menu.append(titreMenu);
		$('#side_button').append(div_titre_menu);
        break;
    case 'my_questions':
		displayMyQuestionContainer();
		displayBestPlayerContainer();
        break;
			case 'all_questions':
			displayAllQuestionsContainer();
			displayBestPlayerContainer();
			break;
			case 'search':
				lastSearch(value);
			break;
			}
		});
	}

	//FONCTION AFFICHAGE + RETOUR QUESTION REPONSE ACCUEIL
	function questionReponseHome(id_question) {

		$("#contenu").empty();
		displayUneQuestion(id_question);
		displayReponsesByQuestion(id_question);
		//displayFormRepondre(id_question);

		/*//Ajout d'un bouton retour dans le titre
		var backButton = $('<button class="backButton"></button>');
		$('#contenu').append(backButton);

		//Gestion du clic du bouton retour
		backButton.click(function(){
			//On vide le contenu et on affiche l'interface de gestion
			$('#contenu').empty();
			displayProfileContainer();
			displayRechercheContainer();
			displayQuestionsRecentesContainer();
			displayBestPlayerContainer();
			displayRecompensesContainer();
			displayQuestionsRecentes();
		});*/
	}

	//FONCTION AFFICHAGE + RETOUR QUESTION REPONSE MES QUESTIONS
	function questionReponseHome(id_question) {

		$("#contenu").empty();
		displayReponsesByQuestion(id_question);
		displayUneQuestion(id_question);
		//displayFormRepondre(id_question);

		//Ajout d'un bouton retour dans le titre
		var backButton = $('<button class="backButton"></button>');
		$('#contenu').append(backButton);

		//Gestion du clic du bouton retour
		backButton.click(function(){
			//On vide le contenu et on affiche l'interface de gestion
			$('#contenu').empty();
			displayProfileContainer();
			displayRechercheContainer();
			displayQuestionsRecentesContainer();
			displayBestPlayerContainer();
			displayRecompensesContainer();
			displayQuestionsRecentes();
		});
	}

	//FONCTION AFFICHAGE + RETOUR QUESTION REPONSE QUESTIONS PAR CATEGORIES
	function questionReponseHome(id_question) {

		$("#contenu").empty();
		displayReponsesByQuestion(id_question);
		displayUneQuestion(id_question);
		//displayFormRepondre(id_question);

		//Ajout d'un bouton retour dans le titre
		var backButton = $('<button class="backButton"></button>');
		$('#contenu').append(backButton);

		//Gestion du clic du bouton retour
		backButton.click(function(){
			//On vide le contenu et on affiche l'interface de gestion
			$('#contenu').empty();
			displayProfileContainer();
			displayRechercheContainer();
			displayQuestionsRecentesContainer();
			displayBestPlayerContainer();
			displayRecompensesContainer();
			displayQuestionsRecentes();
		});
	}

function displayReponsesByQuestion(id_question) {



	$.post("controller/reponse/reponsesByQuestion.php", {"id_question":id_question }, function(reponses) {




		var ul = $("<ul class='listereponses'/>");
		var div = $("#div_question_form");
		div.append(ul);

		var inputValue = $("<textarea name='editor2'/>");
		inputValue.attr("class","input_reponse");
		inputValue.attr("placeholder","Ma réponse...");
		var btn = $("<button "+themeColor1+"/>");
		btn.attr("id","rep");
		btn.append("Répondre!");
		div.append(inputValue);
		div.append(btn);
		editor=CKEDITOR.replace( 'editor2', {
											allowedContent : true,
											forcePasteAsPlainText : true,
											width   : '100%',
											uiColor : '#F2F2F2'
										});


		$.each(reponses, function(i, reponse) {


			var btnEnvoieReponsesAbusives = $("<button "+themeColor1+"/>");
			btnEnvoieReponsesAbusives.addClass("btnEnvoieReponsesAbusives");
			btnEnvoieReponsesAbusives.append("Signaler");

			var li = $("<li "+themeColor2+" />");
			li.addClass("reponse");

			var profil_reponse = $('<div '+themeColor2+'/>');
			var infos_profil_reponse = $("<div class='infos_reponse'/>");
			profil_reponse.addClass('profil_reponse');
			profil_reponse.append(infos_profil_reponse);
			infos_profil_reponse.append("<img src='https://graph.facebook.com/"+reponse.id_facebook+"/picture?type=large' class='imageQuestion' />");
                        infos_profil_reponse.append("<span class='prenomInternaute'>"+reponse.pseudo+"</span> ");
			//infos_profil_reponse.append("<span class='prenomInternaute'>"+reponse.prenom+"</span> ");
			//infos_profil_reponse.append("<span class='nomInternaute'>"+reponse.nom+"</span></br>");
			infos_profil_reponse.append("<span class='titreInternaute'> "+"«"+reponse.libelle_titre+"»"+"</span></br>");
			infos_profil_reponse.append("<span class='levelInternaute'> Niveau : "+reponse.num_niveau+"</span>");
			li.append(profil_reponse);
			profil_reponse.children(".image_reponse").data("reponse",reponse);
			var contenu_reponse = $('<div class="contenu_reponse"/>');

			contenu_reponse.append("<span class='valeurReponse'>"+htmlEntities(reponse.texte)+"</span></br>");
			//contenu_reponse.append("<textarea readonly class='valeurReponse'>"+reponse.valeur_reponse+"</textarea onlyread></br>");
			contenu_reponse.append("<span class='dateReponse'>"+reponse.date_post+"</span>");
			contenu_reponse.append("<span class='total_reputation'>"+reponse.points_reponse+" Points </span></br>");
			li.append(contenu_reponse);

			//var id_facebook = idfacebook; // devra etre égal à la variable de session id_facebook à la place de ce numéro en brut
			if(reponse.id_facebook == idfacebook){
				var btn_modifier = $("<button "+themeColor1+" id='btn_modifier_rep'/>");

				btn_modifier.append("Modifier ma réponse");
				li.append(btn_modifier);

				btn_modifier.on("click", function(){
					formModifierMaReponse(reponse.id_reponse, reponse.texte, id_question);

				});

			}else{
					var btn = $("<button/>");
					btn.addClass("addPoint");
					btn.append("<b>+</b>");
					li.append(btn);
					li.append(btnEnvoieReponsesAbusives);

					btn.click(function() {

					$.post("controller/points/addPoint.php", {"id_facebook":reponse.id_facebook, "id_reponse":reponse.id_reponse, "id_voteur" : idfacebook }, function(reponses) {
						btn.css("background-color","grey");
						btn.off();

					},"json");

				});


				}


			ul.append(li);

//-----------------------------------------------

 $(".image_reponse").click(function() {
				var reponse = ($(this).data("reponse"));
				console.log(reponse.id_facebook);
				loadProfile(reponse.id_facebook);
			});

//------------------------------------------------
			btnEnvoieReponsesAbusives.on("click", function() {

				$.post("controller/reponse/envoieReponsesAbusives.php", {"id_reponse":reponse.id_reponse, "id_facebook":reponse.id_facebook} , function(reponses){
					btnEnvoieReponsesAbusives.css("background-color","grey");
					btnEnvoieReponsesAbusives.off();

				},"json");
			});
		});

		/*LORSQUE L'ON CLIQUE SUR "Répondre" --> +2 expérience, si exp_requise atteinte alors update de exp_requise et de niveau_internaute (+1)*/

		$("#rep").click(function(){

            checkObtentionBadge();

			$.post("controller/joueur/levelUp.php",
				{
					"valeur_reponse":editor.getData(),
					"id_facebook":idfacebook
				}, function(data) {
					displayXPProfile();


				},"json");


			/* ON INSERE LA REPONSE DANS LA BD*/

			//if(inputValue.val() != "") {

			$.post("controller/reponse/repondre.php",
				{

					"valeur_reponse":editor.getData(),
					"id_question":id_question,
					"id_facebook":idfacebook
					},function(reponses) {
						$("#contenu").empty();
				MajNbMessage(idfacebook);
				questionReponse(id_question);
				addNotification(id_question, idfacebook);

					},"json");

				//}


	});

	}, "json");



}



function displayUneQuestion(id_question) {

	$.post("controller/question/uneQuestion.php", {"id_question":id_question }, function(questions) {
		var ul = $("<ul class='ul_uneQuestion'/>");
		var div_question = $('<div/>');
		var div_profile_question = $('<div/>');
		var div_valeur_question= $('<div/>');
		var div_form = $("<div id='div_question_form' />");
		
		div_question.addClass('profile_question');


		div_profile_question.addClass("valeur_question");
		div_valeur_question.append(ul);


		div_question.append(div_profile_question);
		div_question.append(div_valeur_question);
		div_form.prepend(div_question);
		$("#contenu").prepend(div_form);
		
		
		$.each(questions, function(i, question) {
			var div_titre_main = $('<div '+themeColor2+' id="div_titre"></div>');
			var titre = $('<h1 '+themeColor2+' class="titre_main">'+question.libelle_matiere+' : '+htmlEntities(question.titre)+'</h1>');
			div_titre_main.append(titre);
			$("#contenu").prepend(div_titre_main); 



			var btnEnvoieQuestionsAbusives = $("<button/>");
			btnEnvoieQuestionsAbusives.addClass("btnEnvoieQuestionsAbusives");
			btnEnvoieQuestionsAbusives.append("Signaler");
			console.log("test3");
			var la_question = $('<div class="uneQuestion"/>');
			//la_question.data("question", question);
			var profil_question = $("<div class='profil_question'/>");
			var infos_profil_question = $("<div class='infos_question'/>");
			
			infos_profil_question.append("<img src='https://graph.facebook.com/"+question.id_facebook+"/picture?type=large' class='imageQuestion' />");
            infos_profil_question.append("<span class='prenomInternaute'>"+question.pseudo+""+" </span>");
			//infos_profil_question.append("<span class='nomInternaute'> "+question.nom+"</span></br>");
			infos_profil_question.append("<span class='titreInternaute'> "+"«"+question.libelle_titre+"»"+"</span></br>");
			infos_profil_question.append("<span class='levelInternaute'> Niveau : "+question.num_niveau+"</span></br>");
			profil_question.append(infos_profil_question);
			la_question.append(profil_question);
			var contenu_uneQuestion = $('<div '+themeColor1+'/>');
			contenu_uneQuestion.addClass('contenu_uneQuestion');
			contenu_uneQuestion.append("<span class='valeurQuestion'>"+htmlEntities(question.texte)+"</span><br/>");
			contenu_uneQuestion.append("<span class='dateReponse'>"+question.date_post+"</span>");
			la_question.append(contenu_uneQuestion);
			

			la_question.append(btnEnvoieQuestionsAbusives);
			ul.append(la_question);

			$(".image_question").click(function() {

				loadProfile(question.id_facebook);
			});


					btnEnvoieQuestionsAbusives.on("click", function() {
						$.post("controller/question/envoieQuestionsAbusives.php", {"id_question":question.id_question, "id_facebook":question.id_facebook} , function(reponses){
							btnEnvoieQuestionsAbusives.css("background-color","grey");
							btnEnvoieQuestionsAbusives.off();
							console.log("envoie");
						},"json");
					});
				});
				
				displayReponsesByQuestion(id_question);
			}, "json");

	//});

}





//FONCTION MODIFIER SA REPONSE
function formModifierMaReponse(id_reponse, valeur_reponse, id_question){

	$(".btnEnvoieReponsesAbusives").hide();
	var textarea_modif_reponse = $("<textarea class='area'  shape='rect'>"+htmlEntities(valeur_reponse)+"</textarea>");
	$("#btn_modifier_rep").before(textarea_modif_reponse);
/*	editor=CKEDITOR.replace( 'editor3', {
											forcePasteAsPlainText : true,
											width   : '100%',
											uiColor : '#F2F2F2'
										});*/




	$("#btn_modifier_rep").click(function(){

			$.post("./controller/reponse/modifierMaReponse.php", {

			"id_reponse":id_reponse,
			"valeur_reponse":$('.area').val()
			},function(reponses) {

					questionReponse(id_question);
			}, "json");



	});
}
