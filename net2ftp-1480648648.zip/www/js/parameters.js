function initTheme(select, value){
  var initColor = value;
  console.log('initCOlor : ' + initColor);
  switch(initColor){
    case "#c0392b":
    $('.header').css('background-color', value);
    $('#recompenses').css('background-color', value);
    $('.div_titre').css('background-color', "#e74c3c");
    $('.myRank').css('background-color',"#e74c3c");
    $('.puces_classement').css('background-color',value);
    $('#boutonClassementGeneral').css('background-color', "#e74c3c");
    $('#boutonBestPlayerFull').css('background-color', "#e74c3c");
    $('.titre').css('background-color', "#e74c3c");
    select.css('background-color',value);
    break;
    default:
    select.css('background-color','#297CBE');

  }
}

function changeTheme(select){
  var newColor = select.val();
console.log("change theme +" + newColor);
  initTheme(select, newColor);
}

function checkTheme(){
  $.ajax({
    url:"./controller/verif/checkTheme.php",
    type:'get',
    data : "idfacebook=" + idfacebook,
    dataType:'json',
    success:function(data){

    /*$.each(data, function(i, themeActuel) {
       // console.log(themeActuel.theme);
        switch(themeActuel.theme){
          case 'c0392b': // CAS INFO COULEUR ROUGE DEUX NUANCES
          //MODIFICATION DES COULEURS DU HEADER
            $('header').css('background-color', '#'+ themeActuel.theme);
            $('#name').css('background-color', '#e74c3c');
            $('#level').css('background-color', '#e74c3c');
            $('.titre_div_recompenses').css('background-color', '#e74c3c');
            $('#selectColorTheme').css('background-color', '#e74c3c');
              //MODIFICATION DES HOVER DES RECOMPENSES
              $('.nom_rec').hover(function(){
                $(this).css('background-color','#e74c3c');
              }, function(){
                $('.nom_rec').css('background-color','#f2f2f2');
              });
          //MODIFICATION DES TROIS TITRES PRINCIPAUX
            $('.titre_menu').css('background-color', '#e74c3c');
            $('.titre_main').css('background-color', '#e74c3c');
            $('.div_titre').css('background-color', '#e74c3c');
            $('#div_titre').css('background-color', '#e74c3c');
          //MODIFICATION DU HOVER DES PUCES DU MENU
          $('.puce_menu').hover(function(){
            $(this).css('background-color','#e74c3c');
            $(this).css('border-color','#'+themeActuel.theme);
          }, function(){
            $('.puce_menu').css('background-color','#f2f2f2');
          });
          //MODIFICATION DE LA DIV CONTENU (QUESTIONS + REPONSES)
          $('.titre').css('background-color','#'+themeActuel.theme);
          $('.nbreponse').css('border-color','#'+themeActuel.theme);
          $('.nbreponse').css('color','#'+themeActuel.theme);
            //GESTION DU HOVER DES QUESTIONS
            $('.myquestion').hover(function(){
              $(this).css('background-color','#e74c3c');
              $(this).css('border-color','#'+themeActuel.theme);
            }, function(){
              $('.myquestion').css('background-color','#f2f2f2');
              $(this).css('border-color','transparent');
            });
            //Question affichée
            $('.uneQuestion').css('background-color','#'+themeActuel.theme);
            $('.contenu_uneQuestion').css('background-color','#'+themeActuel.theme);
            $('.infos_question').css('color','#'+themeActuel.theme);
            //Réponses affichées
            $('.reponse').css('background-color','#e74c3c');
            $('.infos_reponse').css('color','#e74c3c');
          //MODIFICATION DU CLASSEMENT + BOUTONS DU CLASSEMENT
          $('.puces_classement').css('background-color','#'+themeActuel.theme);
          $('.myRank').css('background-color','#'+themeActuel.theme);
          $('#boutonClassementGeneral').css('border-color','#'+themeActuel.theme);
          $('#boutonClassementGeneral').css('background-color','#'+themeActuel.theme);
          $('.tableClassement').css('background-color','#'+themeActuel.theme);
          //MODIFICATION DU profil
          $('.titre_div_profile').css('background-color','#'+themeActuel.theme);
          //MODIFICATION DU FORMULAIRE POUR POSER UNE QUESTION
          $('#form-div').css('background-color','#e74c3c');
          $('#button-blue').css('background-color','#'+themeActuel.theme);
          //MODIFICATION DES CATEGORIES
          $('.departement').css('background-color','#e74c3c');
          $('.departement').hover(function(){
            $(this).css('background-color','#'+themeActuel.theme);

          }, function(){
            $('.matiere').css('background-color','#f2f2f2');
          });
          $('.departement selected').css('background-color','#e74c3c');
          $('.categorie').css('background-color','#'+themeActuel.theme);
          $('.matiere').hover(function(){
            $(this).css('background-color','#e74c3c');

          }, function(){
            $('.matiere').css('background-color','#f2f2f2');
          });

          //INTERFACE DE GESTION
          $('.titreGestion').css('background-color','#'+themeActuel.theme);
            //GESTION DES BOUTONS DE GESTION
            $('.btnGestion').css('background-color','#'+themeActuel.theme);
            $('.btnGestion').css('border-color','#'+themeActuel.theme);
            $('.btnGestion').each(function(){
              $('.btnGestion').hover(function(){
                $(this).css('background-color','#f2f2f2');
                $(this).css('color','#f2f2f2');
              });
            }, function(){
              $('.btnGestion').css('background-color','#'+themeActuel.theme);
            });
          break;
          case '8E44AD' :
           //MODIFICATION DES COULEURS DU HEADER
            $('header').css('background-color', '#'+ themeActuel.theme);
            $('#name').css('background-color', '#9B59B6');
            $('#level').css('background-color', '#9B59B6');
            $('.titre_div_recompenses').css('background-color', '#9B59B6');
            $('#selectColorTheme').css('background-color', '#9B59B6');
              //MODIFICATION DES HOVER DES RECOMPENSES
              $('.nom_rec').hover(function(){
                $(this).css('background-color','#9B59B6');
              }, function(){
                $('.nom_rec').css('background-color','#f2f2f2');
              });
          //MODIFICATION DES TROIS TITRES PRINCIPAUX
            $('.titre_menu').css('background-color', '#9B59B6');
            $('.titre_main').css('background-color', '#9B59B6');
            $('.div_titre').css('background-color', '#9B59B6');
            $('#div_titre').css('background-color', '#9B59B6');
          //MODIFICATION DU HOVER DES PUCES DU MENU
          $('.puce_menu').hover(function(){
            $(this).css('background-color','#9B59B6');
            $(this).css('border-color','#'+themeActuel.theme);
          }, function(){
            $('.puce_menu').css('background-color','#f2f2f2');
          });
          //MODIFICATION DE LA DIV CONTENU (QUESTIONS + REPONSES)
          $('.titre').css('background-color','#'+themeActuel.theme);
          $('.nbreponse').css('border-color','#'+themeActuel.theme);
          $('.nbreponse').css('color','#'+themeActuel.theme);
            //GESTION DU HOVER DES QUESTIONS
            $('.myquestion').hover(function(){
              $(this).css('background-color','#9B59B6');
              $(this).css('border-color','#'+themeActuel.theme);
            }, function(){
              $('.myquestion').css('background-color','#f2f2f2');
              $(this).css('border-color','transparent');
            });
            //Question affichée
            $('.uneQuestion').css('background-color','#'+themeActuel.theme);
            $('.contenu_uneQuestion').css('background-color','#'+themeActuel.theme);
            $('.infos_question').css('color','#'+themeActuel.theme);
            //Réponses affichées
            $('.reponse').css('background-color','#9B59B6');
            $('.infos_reponse').css('color','#9B59B6');
          //MODIFICATION DU CLASSEMENT + BOUTONS DU CLASSEMENT
          $('.puces_classement').css('background-color','#'+themeActuel.theme);
          $('.myRank').css('background-color','#'+themeActuel.theme);
          $('#boutonClassementGeneral').css('border-color','#'+themeActuel.theme);
          $('#boutonClassementGeneral').css('background-color','#'+themeActuel.theme);
          //MODIFICATION DU profil
          $('.titre_div_profile').css('background-color','#'+themeActuel.theme);
          //MODIFICATION DU FORMULAIRE POUR POSER UNE QUESTION
          $('#form-div').css('background-color','#9B59B6');
          $('#button-blue').css('background-color','#'+themeActuel.theme);
          //MODIFICATION DES CATEGORIES
          $('.departement').css('background-color','#9B59B6');
          $('.departement').hover(function(){
            $(this).css('background-color','#'+themeActuel.theme);

          }, function(){
            $('.matiere').css('background-color','#f2f2f2');
          });
          $('.departement selected').css('background-color','#9B59B6');
          $('.categorie').css('background-color','#'+themeActuel.theme);
          $('.matiere').hover(function(){
            $(this).css('background-color','#9B59B6');

          }, function(){
            $('.matiere').css('background-color','#f2f2f2');
          });

          //INTERFACE DE GESTION
          $('.titreGestion').css('background-color','#'+themeActuel.theme);
            //GESTION DES BOUTONS DE GESTION
            $('.btnGestion').css('background-color','#'+themeActuel.theme);
            $('.btnGestion').css('border-color','#'+themeActuel.theme);
            $('.btnGestion').each(function(){
              $('.btnGestion').hover(function(){
                $(this).css('background-color','#f2f2f2');
                $(this).css('color','#f2f2f2');
              });
            }, function(){
              $('.btnGestion').css('background-color','#'+themeActuel.theme);
            });
          break;
        }

      });*/

    }
  });
}

/*
$(document).ready(function(){


  var selectColorTheme = $('<select '+themeColor1+'></select>');
  selectColorTheme.attr('id','selectColorTheme');

  $('#home_nav').append(selectColorTheme);
  initTheme(selectColorTheme);
  //AJOUT DES THEMES DANS LE SELECT
  selectColorTheme.append(new Option("Changer de thème","THEMES"));
  selectColorTheme.append(new Option("OPORA","2980b9"));
  selectColorTheme.append(new Option("INFO","c3272b"));
  selectColorTheme.append(new Option("GEA","8e44ad"));

  //EN CAS DE CLIQUE SUR LE SELECT ON DECLENCHE LA FONCTION changeTheme()
  selectColorTheme.change(function(){
    
    setTimeout(function(){ 
      window.location.href = ".";
    }, 500);

    //console.log("theme=" + selectColorTheme.val() + "&idfacebook=" + idfacebook);
    $.ajax({
      url:"./controller/theme/updateTheme.php",
      type:'get',
      data : "theme=" + selectColorTheme.val() + "&idfacebook=" + idfacebook,
      dataType:'json',
      success:function(data){

        console.log("code couleur changé");

      }
    });
  });

  //RAFRAICHISSEMENT DU THEME
  //setInterval(checkTheme, 5);

});
*/