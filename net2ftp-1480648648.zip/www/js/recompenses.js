/********************************************
Afficher les recompenses
*********************************************/
function displayRecompenses(){

	var div_titre = $('<div '+themeColor2+'></div>');
	div_titre.attr('class','titre_div_recompenses');
	var div_rec = $('<h2 class="div_rec">RECOMPENSES</h2>');
	div_titre.append(div_rec);
	$('#recompenses').prepend(div_titre);
	
       $.post('./controller/recompense/recompense.php',{},function(recompenses){
			$.each(recompenses, function(i,recompense){
                                $.post("./controller/recompense/uneRecompense.php", {image:recompense.photo , place:recompense.place_necessaire }, function(data){
                                        var div_titre = $('<div />');
                                        div_titre.html(data);
				        $('#recompenses').append(div_titre);
                                });
                        });
      });/*
                                        
			//var div = $("<div class='div_rec'/>");
			var img = $("<img class='img_rec' src="+recompense.photo+" >");
			switch(i){
				case 0 : var div_titre = $("<h4 class='nom_rec'><span class='span_num'>"+(i+1)+"er  </span><span class='span_nom'>"+recompense.libelle_recompense+"</span></h4>");
				break;
				default : var div_titre = $("<h4 class='nom_rec'><span class='span_num'>"+(i+1)+"ème  </span><span class='span_nom'>"+recompense.libelle_recompense+"</span></h4>");
			}
			div_titre.prepend(img);



			//div.append(titre);
			//var img2 = $("<img class='img_rec2' src="+recompense.photo_recompense+" >");
			//$('body').append(img2);
			
			//img2.hide();
			/*img.click(function(){
			var div_lghtB = $("<div/>");
			div_lghtB.attr('id','lightbox_rec');
			$("#recompenses").append(div_lghtB);
				img2.fadeIn(200);									
				div_lghtB.append(img2);
				
			},function(){
				img2.fadeOut(200);	
					
			});*//*	
				//$('#recompenses').append(div);

			});
		},"json");
*/


}	


function displayGererRecompenses(){
	
		 //Ajout d'un bouton retour dans le titre
    var backButton = $('<img src="icon/backButton.png" class="backButton"></img>');
    $('#contenu').append(backButton);

    //Gestion du clic du bouton retour
    backButton.click(function(){
      //On vide le contenu et on affiche l'interface de gestion
      $('#contenu').empty();
      displayInterfaceGestionContainer();

    });
    var div_titre_main = $('<div '+themeColor2+'  id="div_titre"></div>');
    var titre = $('<h1 '+themeColor2+' class="titre_main">GERER LES RECOMPENSES</h1>');
    div_titre_main.append(titre);
    $("#contenu").append(div_titre_main);
	
	var ul = $("<ul class='listeRecompenses' />");
	
	$("#contenu").append(ul);
	
	
	$.ajax({
		type:'post',
		url:'./controller/recompense/allRecompenses.php',
		data:{"idfacebook":idfacebook},
		success:function(recompenses){
			recompenses = JSON.parse(recompenses);
			$.each(recompenses, function(i, recompense){
				var liRecompense = $("<li class='uneRecompense' id='recompense" + recompense.place_necessaire + "' />");
				var imageRecompense = $("<img src='./" + recompense.photo_recompense + "' class='imagerecompense' />");
				var nomRecompense = $("<p class='nomrecompense'>" + recompense.libelle_recompense + "</p>");
				var descriptionRecompense = $("<p class='descr_recompense'>" + recompense.description_recompense + "</p>");
				var lblCondition = $("<p class='condition_obtention_recompense'>Prix pour le " + tradOrdinaux(recompense.place_necessaire) + "</p>");
				var btnSupprimer = $("<img src='./icon/supprimer.png' />");
				
				btnSupprimer.click(function(){
					$.post("./controller/recompense/supprimerRecompense.php", {id: recompense.id_recompense});
				});
				
				liRecompense.append(nomRecompense);
				liRecompense.append(btnSupprimer);
				liRecompense.append(imageRecompense);
				liRecompense.append(descriptionRecompense);
				liRecompense.append(lblCondition);
				
				ul.append(liRecompense);
			});
		}
	});
	displayFormulaireAjoutRecompense();
	
}

function tradOrdinaux(place)
{
	var string = place;
	if(place == 1) string += "er";
	else string += "eme";
	return string;
}

function displayFormulaireAjoutRecompense()
{
	var divAjout = $("<div class='ajoutRecompense' />");
	var lblIntitule = $("<p>Intitullé : </p>");
	var inputIntitule = $("<input type='text' id='inpIntitule' />");
	var selectPlace = $("<select />");
	var max =  $(".uneRecompense").length + 1;
	for(var i = 1; i <= max+1; i++){
		var opt = $("<option value='" + i + "'>" + i + "</option>");
		selectPlace.append(opt);
	}
	
	divAjout.append(lblIntitule);
	divAjout.append(inputIntitule);
	divAjout.append(selectPlace);
	
	$("#contenu").append(divAjout);
}
	