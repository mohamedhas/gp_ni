function displayAllReponsesAbusives() {

	$("#contenu").empty();
	$.post("controller/reponse/allReponsesAbusives.php", { }, function(reponses) {
		var ul = $("<ul/>")
		ul.addClass("listeReponsesAbusives");
			var div_titre_main = $('<div '+themeColor2+'  id="div_titre"></div>');
		var titre = $('<h1 '+themeColor2+'  class="titre_main">REPONSES ABUSIVES</h1>');
		div_titre_main.append(titre);
		$("#contenu").append(div_titre_main);
		$('#contenu').append(ul);
	


		 //Ajout d'un bouton retour dans le titre
    var backButton = $('<img src="icon/backButton.png" class="backButton"></img>');
    $('#contenu').append(backButton);

    //Gestion du clic du bouton retour
    backButton.click(function(){
      //On vide le contenu et on affiche l'interface de gestion
      $('#contenu').empty();
      displayInterfaceGestionContainer();

    });
    
		$.each(reponses, function(i, reponse) {
			var li = $("<li/>");
			li.data("reponse",reponse);
			li.addClass("ReponseAbusive");

			var profil_reponse = $('<div/>');
			profil_reponse.addClass('profil_reponse');
			profil_reponse.append("<img src='https://graph.facebook.com/" + reponse.id_facebook + "/picture?type=large' style='width:50px; height:50px;' class='image_reponse'></br>");
			profil_reponse.append(reponse.prenom + " " + reponse.nom);
			li.append(profil_reponse);
			var contenu_reponse = $('<div/>');
			contenu_reponse.addClass('contenu_reponse');
			contenu_reponse.append("<span class='valeurReponse'>"+reponse.texte+"</span></br>");
			contenu_reponse.append("<span class='date'>"+reponse.date_post+"</span>");

			li.append(contenu_reponse);

			/*var li = $("<li/>");
			li.data("reponse",reponse);
			li.addClass("ReponseAbusive");
			li.append("<img src='"+reponse.photo_internaute+"' style='width:50px; height:50px;' />");
			li.append("<span class='prenomInternaute'>"+reponse.prenom_internaute+"</span>");
			li.append("<span class='nomInternaute'>"+reponse.nom_internaute+"</span></br>");
			li.append("<span class='levelInternaute'> level : "+reponse.niveau_internaute+"</span></br>");
			li.append("<span class='valeurReponse'>"+reponse.valeur_reponse+"</span>");
			li.append("<span class='date'>"+reponse.dates+"</span>");*/
			ul.append(li);

			var id = reponse.id_reponse;

			var div_btn = $('<div class=Btns_Reponse_Abusive/>');
			var btn_retablir = $("<button class='btn_retablir' value='"+id+"'>Rétablir</button>");
			div_btn.append(btn_retablir);

			var btn_delete = $("<button class='btn_delete' value='"+id+"'>Supprimer</button>");
			div_btn.append(btn_delete);

			var btn_edit = $("<button class='btn_edit' id='btn_edit_"+id+"' value='"+reponse.id_reponse+"'>Editer</button>");
			div_btn.append(btn_edit);

			li.append(div_btn);

			$("#btn_edit_"+id+"").click(function() {

				formEditReponse(id, reponse.valeur_reponse)();

				
			});
			
		});

		$(".btn_retablir").click(function() {
			retablirReponse($(this).val());
		});

		$(".btn_delete").click(function() {

			deleteReponse($(this).val());
		});

		


	}, "json");

}



function retablirReponse(id_reponse){

	$("#contenu").empty();
	$.post("controller/reponse/retablirReponse.php", { "id_reponse":id_reponse}, function(reponses) {


	}, "json");

	displayAllReponsesAbusives();

	
}


function deleteReponse(id_reponse){

	$("#contenu").empty();
	$.post("controller/reponse/deleteReponseAbusive.php", { "id_reponse":id_reponse}, function(reponses) {


	}, "json");

	displayAllReponsesAbusives();
	
}


function formEditReponse(id_reponse, valeur_reponse){

	$("#btn_edit_"+id_reponse+"")
						.after("<input type='submit' id='submit_valide_"+id_reponse+"'/>")
						.after("<textarea class='area' name='valeur_reponse' shape='rect'>"+valeur_reponse+"</textarea>");

	$("#submit_valide_"+id_reponse+"").click(function(){

		editReponse(id_reponse,$(".area").val());
	});
}


function editReponse(id_reponse,valeur_reponse){

	$.post("controller/reponse/editReponse.php", { "id_reponse":id_reponse, "valeur_reponse":valeur_reponse}, function(reponses) {


	}, "json");

	retablirReponse(id_reponse);
	displayAllReponsesAbusives();



}




