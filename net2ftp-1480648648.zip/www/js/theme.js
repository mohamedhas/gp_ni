function checkTheme(){
  $.post("./controller/checkTheme.php", { }, function(theme) {

			$.each(theme, function(i, actualTheme) {
        console.log(actualTheme.themeColor + " est le theme actuel");

        });
      },"json");

      console.log("verif du theme effectuée");
};
