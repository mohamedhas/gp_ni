var varCheckBadge=0;

//vérifier si un joueur poossède déja le badge en question
function CheckSiBadgeDejaObtenu(id_facebook, id_badge){
	//TODO tester si la personne possède déja le hf
	
	// $.post("controller/badges/checkBadge.php", { "id_facebook":id_facebook, "id_badge": id_badge}, function(verif) {
		
	// 	console.log("verif : "+verif);
		
	// 	varTemp = verif;
	// 	console.log("vartemp : "+varTemp);

	// }, "json");

	$.ajax({
            type   : 'POST',
            url    : 'controller/badges/checkBadge.php',
            data   : { "id_facebook":id_facebook, "id_badge": id_badge},
            async  : false,
            success: function(msg) {
                r = msg;
                //console.log("verif : "+r);
		
				varCheckBadge = r;
				//console.log("vartemp : "+varCheckBadge);
            }
        });

	//console.log("vartemp en dehors de l'ajax :"+varCheckBadge);
}

//attribuer un badge à un joueur
function AddBadgeToPlayer(id_facebook, id_badge){

	$.post("controller/badges/addBadgeToPlayer.php", { "id_facebook":id_facebook, "id_badge": id_badge}, function(verif) {

	}, "json");
}




function felicitations(nom_badge){
	
	if(arguments[1]){
		alert('VOUS AVEZ OBTENU LE BADGE "'+nom_badge+'", vous avez reçu le titre "'+arguments[1]+'" en guise de récompense ');
	}else{
		alert('VOUS AVEZ GAGNE LE BADGE "'+nom_badge+'"');
	}
}

//Mettre dans cette fonction toutes les fonctions de badge qui se déclancheront quand on posera une question
function VerificationBadgesQuestions(id_facebook){
	console.log("lancement des badges quand on pose une question");
	badgePremiersPas(id_facebook);
	badgesNombreQuestionsPosees(id_facebook);
}



/*------------------------------------------------------------------------------*\
							Les differents badges
\*-----------------------------------------------------------------------------*/

function badgePremiersPas(id_facebook){
	CheckSiBadgeDejaObtenu(id_facebook, 6);
	if(varCheckBadge == 1){
		console.log("possède déja le badge premiers pas");
	}else{
		AddBadgeToPlayer(id_facebook, 6);
		AddAchievementRewardToPlayer(id_facebook, 1);
		felicitations("Premiers Pas", "Débutant");
	}
}



function badgeLoupe(id_facebook){
	CheckSiBadgeDejaObtenu(id_facebook, 5);
	if(varCheckBadge == 1){
		console.log("possède déja le badge Loupe");
		
	}else{
		AddBadgeToPlayer(id_facebook, 5);
		felicitations("Loupe");
	}
}


function badgesNombreQuestionsPosees(id_facebook){
	

	$.ajax({
        type   : 'POST',
        url    : 'controller/badges/badgesNombreQuestionsPosees.php',
        data   : {"id_facebook":id_facebook},
        //async  : false,
        success: function(nombreQuestions) {
            //r = msg;
            console.log("nombre de questions : " + nombreQuestions);

            switch(nombreQuestions) {
			    case "10":
			    	console.log("Check switch case 10");
			    	CheckSiBadgeDejaObtenu(id_facebook, 7);
			    	if(varCheckBadge == 1){
						console.log("possède déja le badge interrogateur");
					}else{
						AddBadgeToPlayer(id_facebook, 7);
			        	AddAchievementRewardToPlayer(id_facebook, 10);
			        	felicitations("interrogateur", "interrogateur");
					}
			        break;
			    case "100":
			    	CheckSiBadgeDejaObtenu(id_facebook, 8);
			    	if(varCheckBadge == 1){
						console.log("possède déja le badge Chercheur");
					}else{
						AddBadgeToPlayer(id_facebook, 8);
						AddAchievementRewardToPlayer(id_facebook, 11);
						felicitations("Chercheur", "Chercheur");
					}
			        
			        break;
			    case "500":
			    	CheckSiBadgeDejaObtenu(id_facebook, 9);
			    	if(varCheckBadge == 1){
						console.log("possède déja le badge Inspecteur");
					}else{
						AddBadgeToPlayer(id_facebook, 9);
						AddAchievementRewardToPlayer(id_facebook, 12);
						felicitations("Inspecteur", "Inspecteur");
					}
			        
			        break;
			    case "1000":
			    	CheckSiBadgeDejaObtenu(id_facebook, 10);
			    	if(varCheckBadge == 1){
						console.log("possède déja le badge Détective privé");
					}else{
						AddBadgeToPlayer(id_facebook, 10);
						AddAchievementRewardToPlayer(id_facebook, 14);
						felicitations("Détective privé", "Détective privé");
					}
			        
			        break;
			}
	
			//varCheckBadge = r;
			//console.log("vartemp : "+varCheckBadge);
        }
    });

	//AddBadgeToPlayer(id_facebook, 7);
	//AddAchievementRewardToPlayer();
	//felicitations("interrogateur", "interrogateur");

}


function DisplayAjoutBadge()	//Formulaire pour ajouter un badge
{
		 //Ajout d'un bouton retour dans le titre
    var backButton = $('<img src="icon/backButton.png" class="backButton"></img>');
    $('#contenu').append(backButton);

    //Gestion du clic du bouton retour
    backButton.click(function(){
      //On vide le contenu et on affiche l'interface de gestion
      $('#contenu').empty();
      displayInterfaceGestionContainer();

    });
    var div_titre_main = $('<div '+themeColor2+'  id="div_titre"></div>');
    var titre = $('<h1 '+themeColor2+' class="titre_main">NOUVEAU BADGE</h1>');
    div_titre_main.append(titre);
    $("#contenu").append(div_titre_main);

    var divNewBadge = $("<div class='divNewBadge'></div>");
    $("#contenu").append(divNewBadge);

    //var divTitreBadge = $("<span class='titre_badge'><label> Titre du nouveau badge : </label><input type='text'/></span></br>");
	var sautLigne;
	sautLigne = document.createElement("br");
    var divLibelleBadge = $("<span class='libelle_badge'><label> Titre du nouveau badge </label></span>");
    var inputTitre = $("<input id='inputTitre' class='validate[required,custom[onlyLetter],length[0,100]] feedback-input' type='text'/>");
    var divLibelleDesc = $("<span class='libelle_desc'><label> Description du badge </label></span>");
    var inputDescription = $("<textarea style='height:150px; width:300px' class='validate[required,custom[onlyLetter],length[0,100]] feedback-input' id='textareaDescr'></textarea>");
	var fichiers = $("<input type='file' id='_file' accept='image/*' class='btn_imageRecompense'/>");
    var divImageBadge = $("<span class='image_badge'><label class='label_imageBadge'> Image du nouveau badge : </label></span>");
	var preview = $("<img src='#' id='previewImage' />");
    divImageBadge.append(fichiers);
	divImageBadge.append(preview);
	var divConditions = $("<div class='divConditions' />");
	var libCondition = $("<span class='libelle_badge'><label> Condition d'obtention </label></span>");
	//divConditions.append(libCondition);
	var btn_gestionBadge = $("<button class='btn_gestionBadge'> Sauvegarder </button>");
	var divBadge = $(".divNewBadge");
    divBadge.append(divLibelleBadge);
    divBadge.append(inputTitre);
	divBadge.append(sautLigne);
    divBadge.append(divLibelleDesc);
    divBadge.append(inputDescription);
	sautLigne = document.createElement("br");
	divBadge.append(sautLigne);
    divBadge.append(divImageBadge);
	sautLigne = document.createElement("br");
	divBadge.append(sautLigne);
	divBadge.append(libCondition);
	divBadge.append(divConditions);
    divBadge.append(btn_gestionBadge);
	
	preview.hide();
	
	fichiers.change(function(){
		preview.show();
		readURL(fichiers[0], "#previewImage");
	});
	
	var btn_ajouterCondition = $("<button id='btn_ajouterCondition'> Ajouter une condition </button>");
	divConditions.append(btn_ajouterCondition);
	displayACondition(0);														//Fonction displayACondition() dans le interfaceGestion.js
	
	indexCondition = 1;
	btn_ajouterCondition.click(function(){displayACondition(indexCondition++);});
	
    btn_gestionBadge.click(function() {
		var valide = (inputTitre.val() != "") && (inputDescription.val() != "") && (fichiers.val() != "");
		var chemin = upload(fichiers[0], "badges/");							//Fonction upload dans main.js
		for(var i = 0; i < indexCondition; i++)
		{
			if($("#value"+i)[0].style.display != 'none' && $("#value"+i)[0].value == "")
				valide = false;
		}
		
		if(valide){
			console.log(inputTitre.val() + " " +  chemin + " " + inputDescription.val());
			AjouterUnBadge(inputTitre.val(),  chemin, inputDescription.val());
		}
	});
}
function AjouterUnBadge(titre, photo, descr)
{
	console.log(titre, photo, descr);
	var lastID = 0;
          $.ajax({
				type:'post',
				url:"controller/badges/newBadge.php", 
				data:{ "libelle_badge":titre,
					"photo": photo,
					"description":descr
				},	
				success:function(data) {
					lastID = JSON.parse(data);
					console.log("data : "+lastID);
			  
				for(var i = 0; i < indexCondition; i++)
				{
					if($("#value"+i)[0].style.display != 'none' && $("#value"+i)[0].value != "")
					{
						var met = $("#metrique"+i)[0].value;
						var com = $("#compare"+i)[0].value;
						var val = $("#value"+i)[0].value;
						console.log(lastID + " " + met + " " + com + " " + val);
						$.ajax({
							url:"controller/badges/newConditionBadge.php", 
							type:'post',
							data:{
								"id_badge":lastID,
								"id_metrique":met,
								"id_comparaison":com,
								"value":val}, 
							success:	function(data, stat) {
								console.log("data 2 : "+data+ " " + stat);
							}
						});
					}
				}
			  
				$("#contenu").empty();
				displayInterfaceGestion();
			}
		});
}

function displayConsulterLesBadges()
{
		 //Ajout d'un bouton retour dans le titre
    var backButton = $('<img src="icon/backButton.png" class="backButton"></img>');
    $('#contenu').append(backButton);

    //Gestion du clic du bouton retour
    backButton.click(function(){
      //On vide le contenu et on affiche l'interface de gestion
      $('#contenu').empty();
      displayInterfaceGestionContainer();

    });
    var div_titre_main = $('<div '+themeColor2+'  id="div_titre"></div>');
    var titre = $('<h1 '+themeColor2+' class="titre_main">TOUS LES BADGES</h1>');
    div_titre_main.append(titre);
    $("#contenu").append(div_titre_main);
	
	var ul = $("<ul class='listeBadges' />");
	
	$("#contenu").append(ul);
	
	
	$.ajax({
		type:'post',
		url:'./controller/badges/allBadges.php',
		data:{"idfacebook":idfacebook},
		success:function(badges){
			badges = JSON.parse(badges);
			$.each(badges, function(i, badge){
				var liBadge = $("<li class='unBadge' />");
                                liBadge.data('badge', badge);
				var imageBadge = $("<img src='./" + badge.photo_badge + "' class='imageBadge' />");
				var nomBadge = $("<p class='nomBadge'>" + badge.libelle_badge + "</p>");
				var descriptionBadge = $("<p class='descr_badge'>" + badge.description_badge + "</p>");
				var divConditions = $("<div class='condition_badge' />");
				var lblConditions = $("<p class='condition_optention_badge'>Pour recevoir ce badge, il faut :</p>");
				var ulConditions = $("<ul class='liste_conditions_badge' />");
                                var btnModifier = $("<button name='btn_modifier'>Modifier</button>");
                                var btnSupprimer = $("<button name='btn_supprimer'>Supprimer</button>");
				
				$.ajax({
					async:false,
					type:'post',
					url:'./controller/badges/allConditionsByBadge.php',
					data:{'id_badge':badge.id_badge},
					success:function(conditions){
						conditions = JSON.parse(conditions);
						$.each(conditions, function(j, condition){
							var ligne_condition = $("<p class='ligne_condition_badge' />");
							var texte = "<span class='index_condition_badge'>"+ (j+1) + "</span> : <span class='metrique_condition'>" + condition.libelle_metrique + "</span> <span class='comparaison_condition'>" + condition.libelle_comparaison + "</span> <span class='valeur_condition'>" + condition.valeur_seuil + "</span>";
							ligne_condition.append($(texte));
							ulConditions.append(ligne_condition);
						});
					}
				});
				liBadge.append(nomBadge);
				liBadge.append(imageBadge);
				liBadge.append(descriptionBadge);
				liBadge.append(lblConditions);
				liBadge.append(ulConditions);
				liBadge.append(divConditions);
				liBadge.append(btnModifier);
				liBadge.append(btnSupprimer);
				
				btnModifier.click(function(){
				        modifierBadge(badge);
				});
				btnSupprimer.click(function(){
				        supprBadge(badge);
				});				

				ul.append(liBadge);
			});
		}
	});
	
}

function checkObtentionBadge(){
    $.ajax({
         url:"controller/badges/checkBadge.php",
         data: {id_facebook : idfacebook},
         type: 'post',
         success: function(data){
				if(data != 'null'){
					$.each(JSON.parse(data), function(i, badge){
							console.log(badge);
							smallPopup("Bravo! Vous avez obtenu le badge \"" + badge + "\" :) ");
					});
				}
         }
    });
	checkObtentionTitre(); 			//Also check for Titre


}
function modifierBadge(badge)
{
     DisplayModifierBadge(badge);
}

function supprBadge(badge)
{

     alert("suppression de " + badge.libelle_badge);
}
function DisplayModifierBadge(badge)	//Formulaire pour ajouter un badge
{
	$('#contenu').empty();
		 //Ajout d'un bouton retour dans le titre
    var backButton = $('<img src="icon/backButton.png" class="backButton"></img>');
    $('#contenu').append(backButton);

    //Gestion du clic du bouton retour
    backButton.click(function(){
      //On vide le contenu et on affiche l'interface de gestion
      $('#contenu').empty();
      displayInterfaceGestionContainer();

    });
    var div_titre_main = $('<div '+themeColor2+'  id="div_titre"></div>');
    var titre = $('<h1 '+themeColor2+' class="titre_main">MODIFIER UN BADGE</h1>');
    div_titre_main.append(titre);
    $("#contenu").append(div_titre_main);

    var divNewBadge = $("<div class='divNewBadge'></div>");
    $("#contenu").append(divNewBadge);

    //var divTitreBadge = $("<span class='titre_badge'><label> Titre du nouveau badge : </label><input type='text'/></span></br>");
	var sautLigne;
	sautLigne = document.createElement("br");
    var divLibelleBadge = $("<span class='libelle_badge'><label> Titre du badge </label></span>");
    var inputTitre = $("<input id='inputTitre' class='validate[required,custom[onlyLetter],length[0,100]] feedback-input' type='text' value='"+ badge.libelle_badge +"'/>");
    var divLibelleDesc = $("<span class='libelle_desc'><label> Description du badge </label></span>");
    var inputDescription = $("<textarea style='height:150px; width:300px' class='validate[required,custom[onlyLetter],length[0,100]] feedback-input' id='textareaDescr'>" + badge.description_badge + "</textarea>");
	var fichiers = $("<input type='file' id='_file' accept='image/*' class='btn_imageRecompense'/>");
    var divImageBadge = $("<span class='image_badge'><label class='label_imageBadge'> Image du badge : </label></span>");
	var preview = $("<img src='"+ badge.photo_badge +"' id='previewImage' />");
    divImageBadge.append(fichiers);
	divImageBadge.append(preview);
	var divConditions = $("<div class='divConditions' />");
	var libCondition = $("<span class='libelle_badge'><label> Condition d'obtention </label></span>");
	//divConditions.append(libCondition);
	var btn_gestionBadge = $("<button class='btn_gestionBadge'> Sauvegarder </button>");
	var divBadge = $(".divNewBadge");
    divBadge.append(divLibelleBadge);
    divBadge.append(inputTitre);
	divBadge.append(sautLigne);
    divBadge.append(divLibelleDesc);
    divBadge.append(inputDescription);
	sautLigne = document.createElement("br");
	divBadge.append(sautLigne);
    divBadge.append(divImageBadge);
	sautLigne = document.createElement("br");
	divBadge.append(sautLigne);
	divBadge.append(libCondition);
	divBadge.append(divConditions);
    divBadge.append(btn_gestionBadge);
	
	fichiers.change(function(){
		readURL(fichiers[0], "#previewImage");
	});
	
	indexCondition = 0;
	var btn_ajouterCondition = $("<button id='btn_ajouterCondition'> Ajouter une condition </button>");
	divConditions.append(btn_ajouterCondition);
	$.ajax({url: "controller/badges/allConditionsByBadge.php",
			data : {id_badge : badge.id_badge},
			type : 'post',
			success : function(data){
				$.each(JSON.parse(data), function(i, condition){
					displayACondition(indexCondition, condition.id_metrique, condition.id_comparaison, condition.valeur_seuil);		
					indexCondition++;												//Fonction displayACondition() dans le interfaceGestion.js
				});
			}
	});
	
	btn_ajouterCondition.click(function(){displayACondition(indexCondition++);});
	
    btn_gestionBadge.click(function() {
		var valide = (inputTitre.val() != "" && (inputDescription.val() != ""));
		var chemin = badge.photo_badge
		if(fichiers.val() != "") chemin = upload(fichiers[0], "badges/");							//Fonction upload dans main.js
		for(var i = 0; i < indexCondition; i++)
		{
			if($("#value"+i)[0].style.display != 'none' && $("#value"+i)[0].value == "")
				valide = false;
		}
		
		if(valide){
			console.log(inputTitre.val() + " " +  chemin + " " + inputDescription.val());
			ModifierUnBadge(badge.id_badge, inputTitre.val(),  chemin, inputDescription.val());
		}
	});
}

function ModifierUnBadge(id, titre, photo, descr)
{
	console.log(titre, photo, descr);
	var lastID = 0;
          $.ajax({
				type:'post',
				url:"controller/badges/modifyBadge.php", 
				data:{ "id_badge" : id,
					"libelle_badge":titre,
					"photo": photo,
					"description":descr
				},	
				success:function(data) {
					lastID = JSON.parse(data);
					console.log("data : "+lastID);
			  
				for(var i = 0; i < indexCondition; i++)
				{
					if($("#value"+i)[0].style.display != 'none' && $("#value"+i)[0].value != "")
					{
						var met = $("#metrique"+i)[0].value;
						var com = $("#compare"+i)[0].value;
						var val = $("#value"+i)[0].value;
						console.log(id + " " + met + " " + com + " " + val);
						$.ajax({
							url:"controller/badges/newConditionBadge.php", 
							type:'post',
							data:{
								"id_badge":id,
								"id_metrique":met,
								"id_comparaison":com,
								"value":val}, 
							success:	function(data, stat) {
								console.log("data 2 : "+data+ " " + stat);
							}
						});
					}
				}
			  
				$("#contenu").empty();
				displayInterfaceGestion();
			}
		});
}
