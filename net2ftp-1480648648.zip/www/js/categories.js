function displayAllCategories() {

	$.post("controller/categorie/displayAllCategoriesQuestions.php", {dataType : 'html'}, function(html) {
		$("#contenu").html(html);
		var titre = $('<h1 id="div_titre">TOUTES LES CATEGORIES</h1>');
		$('#contenu').prepend(titre);
		
		$('.categorie').click(function(){
			$('#contenu').empty();
			// displayMatieresContainer($(this).data("categories").id_categorie);
			// $('#contenu').children().remove();
			/*$.post("controller/matiere/matiereQuestion.php", { "id_categ": $(this).attr('id') }, function(matieres) {
				$.each(matieres, function(i, matiere) {
					$('#contenu').append("<li id="+matiere.id_matiere+">"+matiere.libelle_matiere+"</li>");
					displayQuestionsByMatiere(matiere.id_matiere,matiere.libelle_matiere);
				});
			}, "json");*/
			displayQuestionByCategorie($(this).attr("id"));
			
			
			
			
			// displayQuestionsByMatiere(1,'PHP');
			// displayQuestionsByMatiere($(this).attr('categorie'),$(this).attr(';
			// alert('clic');
		});
	}, "html");
}


function displayMatieresContainer(idcateg) {

	$("nav li").removeClass("active");
	$(this).addClass("active");

	// displayMatieresByCategorie(idcateg);

}


function displayCategoriesByDepartement(iddept, nomdept, verifRightMenu) {

	var verifZoom = false;

	//V2RIFIE SI ON A CLIQUE SUR UNE CATEGORIE SE TROUVANT LE CONTENU OU DANS L'ARBORESCENCE DE DROITE
	if(verifRightMenu == false) {

		$.post("controller/categorie/categoriesByDept.php", { "id_departement":iddept }, function(categories) {
			console.log(categories);
			var ul = $("<ul style='background-color : white;' class='listecateg'/>");

			var contenucategorie = $('<div id="contenucategorie"/>');
			$('#contenu').append(contenucategorie);


			contenucategorie.append(ul);
			$.each(categories, function(i, categorie) {

				var li = $("<li "+themeColor1+"/>");
				li.data("categorie",categorie);
				li.addClass("categorie");
				li.append("<span class='nomcategorie'>"+categorie.libelle_categorie+"</span>");
				li.attr("id","idcateg"+categorie.id_categorie);
				li.attr("name",categorie.libelle_categorie);

				displayMatieresByCategorie(categorie.id_categorie, categorie.libelle_categorie, verifRightMenu);
				ul.append(li);
			});

		}, "json");

	}else{
		$.post("controller/categorie/categoriesByDept.php", { "id_departement":iddept }, function(categories) {
			var ul = $("<ul class='listecategRightMenu' id='deptNum"+iddept+"'/>");
			//$('#contenucategorie').remove();
			var contenucategorie = $('<div  id="contenucategorie"/>');
			$('#'+iddept+'')//.html(' - '+nomdept)
						.after(contenucategorie);

			contenucategorie.append(ul);
			$.each(categories, function(i, categorie) {

				var li = $("<li "+themeColor2+"/>");
				li.data("categorie",categorie);
				li.addClass("liCategorieRightMenu");
				li.append("<span "+themeColor2+" class='nomcategorie'> + "+categorie.libelle_categorie+"</span>");
				li.attr("id","idcateg"+categorie.id_categorie);
				li.attr("name",categorie.libelle_categorie);


				//displayMatieresByCategorie(categorie.id_categorie, categorie.nom_categorie);
				ul.append(li);
			});

			$('.liCategorieRightMenu').click(function(){
				if(($(this).hasClass('selected'))){
					$('#categNum'+$(this).data("categorie").id_categorie+'').remove();
					$(this).html(' + '+$(this).data("categorie").libelle_categorie);

					$(this).removeClass('selected');
				}else{

					displayMatieresByCategorie($(this).data("categorie").id_categorie, $(this).data("categorie").libelle_categorie, verifRightMenu);
					$(this).html(' - '+$(this).data("categorie").libelle_categorie);

					$(this).addClass('selected');
				}
			});

		}, "json");

	}

}




function displayMatiereByCategorieContainer(idcateg, nomcateg) {

	$("nav li").removeClass("active");
	$(this).addClass("active");

	displayMatieresByCategorie(idcateg, nomcateg);


}

function DisplayAjoutCategorie(){
	$.post("controller/categorie/formulaireAjoutCategorie.php", {}, function(html){
		$("#contenu").html(html);
		
		 //Ajout d'un bouton retour dans le titre
		var backButton = $('.backButton');
		backButton.click(function(){
		  //On vide le contenu et on affiche l'interface de gestion
		  $('#contenu').empty();
		  displayInterfaceGestionContainer();

		});
		
		$('.btn_gestionCategorie').click(function(){
			var nom = $('#nom_categorie').val();
			var matiere = $('#nom_matiere').val();
			var depts = [];
			var matieres = [];
			var checkboxes = $('.checkDept');
			var checkMat = $('.checkMat');
			$.each(checkboxes, function(i, check){
				if(check.checked){
					depts[depts.length] = check.dataset.id;
				}
			});
			$.each(checkMat, function(i, check){
				if(check.checked){
					matieres[matieres.length] = check.id;
				}
			});
			AjouterCategorie(nom, depts, matiere, matieres);
			//On vide et on affiche l'interface de gestion
			$('#contenu').empty();
			displayInterfaceGestionContainer();
		});
	
	});
}

function AjouterCategorie(nom, departements, matiere, matieres){
	$.post("controller/categorie/newCategorie.php", {nom : nom, depts : departements, matiere : matiere, listeMatieres : matieres}, function(){});
}
function DisplayConsulterCategorie()
{
	$.post("controller/categorie/afficherAllCategorie.php", {}, function(html){
		$("#contenu").html(html);
		
		 //Ajout d'un bouton retour dans le titre
		var backButton = $('.backButton');
		backButton.click(function(){
		  //On vide le contenu et on affiche l'interface de gestion
		  $('#contenu').empty();
		  displayInterfaceGestionContainer();

		});
		
		$('.modifier').click(function(){
			var id = $(this).data('id');
			DisplayModifierCategorie(id);
		});
	
	});
}

function DisplayModifierCategorie(id){
	$.post("controller/categorie/formulaireModifierCategorie.php", {id : id}, function(html){
		$("#contenu").html(html);
		
		 //Ajout d'un bouton retour dans le titre
		var backButton = $('.backButton');
		backButton.click(function(){
		  //On vide le contenu et on affiche l'interface de gestion
		  $('#contenu').empty();
		  displayInterfaceGestionContainer();

		});
		
		$('.btn_gestionCategorie').click(function(){
			/*var nom = $('#nom_categorie').val();
			var matiere = $('#nom_matiere').val();
			var depts = [];
			var checkboxes = $('.checkDept');
			$.each(checkboxes, function(i, check){
				if(check.checked){
					depts[depts.length] = check.dataset.id;
				}
			});
			ModifierCategorie(nom, depts, matiere);
			//On vide et on affiche l'interface de gestion
			$('#contenu').empty();
			displayInterfaceGestionContainer();*/
		});
	
	});
}