$('.notification').click(function(){
	$.ajax({
		url : 'controller/notification/closeNotifications.php',
		type : 'get',
		data : {id_facebook : idfacebook},
		success : function(){
			displayDernieresActivites();
		}
	});
});

function verifNotification(){
	function verif(){
		$.ajax({
			url : 'controller/notification/getNotifications.php',
			type : 'get',
			data : {id_facebook : idfacebook},
			success : function(data){
				if(JSON.parse(data).length > 0){
					$('.notification').show();
				}
				else 
					$('.notification').hide();
			}
		});
	}
	verif();
	setInterval(verif,
		2 * 60 * 1000	//Toutes les 2 minutes
		);
}

function addNotification(id_question, id_posteur){
	$.ajax({
		url : 'controller/notification/addNotification.php',
		type : 'get',
		data : {id_question : id_question,
				id_posteur : id_posteur},
		success : function(){
		}
	});
}