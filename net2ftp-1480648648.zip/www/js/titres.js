//atribuer un titre à un joueur
function AddAchievementRewardToPlayer(id_facebook, id_titre){
	$.post("controller/addTitreToPlayer.php", { "id_facebook":id_facebook, "id_titre": id_titre}, function(verif) {

	}, "json");
}

function DisplayAjoutTitre()	//Formulaire pour ajouter un titre
{
		 //Ajout d'un bouton retour dans le titre
    var backButton = $('<img src="icon/backButton.png" class="backButton"></img>');
    $('#contenu').append(backButton);

    //Gestion du clic du bouton retour
    backButton.click(function(){
      //On vide le contenu et on affiche l'interface de gestion
      $('#contenu').empty();
      displayInterfaceGestionContainer();

    });
    var div_titre_main = $('<div '+themeColor2+'  id="div_titre"></div>');
    var titre = $('<h1 '+themeColor2+' class="titre_main">NOUVEAU TITRE</h1>');
    div_titre_main.append(titre);
    $("#contenu").append(div_titre_main);

    var divNewTitre = $("<div class='divNewTitre'></div>");
    $("#contenu").append(divNewTitre);

    //var divTitreTitre = $("<span class='titre_titre'><label> Titre du nouveau titre : </label><input type='text'/></span></br>");
	var sautLigne;
	sautLigne = document.createElement("br");
    var divLibelleTitre = $("<span class='libelle_titre'><label> Titre du nouveau titre </label></span>");
    var inputTitre = $("<input id='inputTitre' class='validate[required,custom[onlyLetter],length[0,100]] feedback-input' type='text'/>");
	var divConditions = $("<div class='divConditions' />");
	var libCondition = $("<span class='libelle_titre'><label> Condition d'obtention </label></span>");
	//divConditions.append(libCondition);
	var btn_gestionTitre = $("<button class='btn_gestionTitre'> Sauvegarder </button>");
	var divTitre = $(".divNewTitre");
    divTitre.append(divLibelleTitre);
    divTitre.append(inputTitre);
	sautLigne = document.createElement("br");
	divTitre.append(sautLigne);
	divTitre.append(libCondition);
	divTitre.append(divConditions);
    divTitre.append(btn_gestionTitre);
	
	var btn_ajouterCondition = $("<button id='btn_ajouterCondition'> Ajouter une condition </button>");
	divConditions.append(btn_ajouterCondition);
	displayACondition(0);														//Fonction displayACondition() dans le interfaceGestion.js
	
	indexCondition = 1;
	btn_ajouterCondition.click(function(){displayACondition(indexCondition++);});
	
    btn_gestionTitre.click(function() {
		var valide = (inputTitre.val() != "");
		for(var i = 0; i < indexCondition; i++)
		{
			if($("#value"+i)[0].style.display != 'none' && $("#value"+i)[0].value == "")
				valide = false;
		}
		
		if(valide){
			console.log(inputTitre.val());
			AjouterUnTitre(inputTitre.val());
		}
	});
}
function AjouterUnTitre(titre)
{
	console.log(titre);
	var lastID = 0;
          $.ajax({
				type:'post',
				url:"controller/titre/newTitre.php", 
				data:{ "libelle_titre":titre,
				},	
				success:function(data) {
					lastID = JSON.parse(data);
					console.log("data : "+lastID);
			  
				for(var i = 0; i < indexCondition; i++)
				{
					if($("#value"+i)[0].style.display != 'none' && $("#value"+i)[0].value != "")
					{
						var met = $("#metrique"+i)[0].value;
						var com = $("#compare"+i)[0].value;
						var val = $("#value"+i)[0].value;
						console.log(lastID + " " + met + " " + com + " " + val);
						$.ajax({
							url:"controller/titre/newConditionTitre.php", 
							type:'post',
							data:{
								"id_titre":lastID,
								"id_metrique":met,
								"id_comparaison":com,
								"value":val}, 
							success:	function(data, stat) {
								console.log("data 2 : "+data+ " " + stat);
							}
						});
					}
				}
			  
				$("#contenu").empty();
				displayInterfaceGestion();
			}
		});
}

function DisplayConsulterTitre()
{
		 //Ajout d'un bouton retour dans le titre
    var backButton = $('<img src="icon/backButton.png" class="backButton"></img>');
    $('#contenu').append(backButton);

    //Gestion du clic du bouton retour
    backButton.click(function(){
      //On vide le contenu et on affiche l'interface de gestion
      $('#contenu').empty();
      displayInterfaceGestionContainer();

    });
    var div_titre_main = $('<div '+themeColor2+'  id="div_titre"></div>');
    var titre = $('<h1 '+themeColor2+' class="titre_main">TOUS LES TITRES</h1>');
    div_titre_main.append(titre);
    $("#contenu").append(div_titre_main);
	
	var ul = $("<ul class='listeTitres' />");
	
	$("#contenu").append(ul);
	
	
	$.ajax({
		type:'post',
		url:'./controller/titre/allTitres.php',
		data:{"idfacebook":idfacebook},
		success:function(titres){
			titres = JSON.parse(titres);
			$.each(titres, function(i, titre){
				var liTitre = $("<li class='unTitre' />");
                                liTitre.data('titre', titre);
				var nomTitre = $("<p class='nomTitre'>" + titre.libelle_titre + "</p>");
				var divConditions = $("<div class='condition_titre' />");
				var lblConditions = $("<p class='condition_optention_titre'>Pour recevoir ce titre, il faut :</p>");
				var ulConditions = $("<ul class='liste_conditions_titre' />");
                                var btnModifier = $("<button name='btn_modifier'>Modifier</button>");
                                var btnSupprimer = $("<button name='btn_supprimer'>Supprimer</button>");
				
				$.ajax({
					async:false,
					type:'post',
					url:'./controller/titre/allConditionsByTitre.php',
					data:{'id_titre':titre.id_titre},
					success:function(conditions){
						conditions = JSON.parse(conditions);
						$.each(conditions, function(j, condition){
							var ligne_condition = $("<p class='ligne_condition_titre' />");
							var texte = "<span class='index_condition_titre'>"+ (j+1) + "</span> : <span class='metrique_condition'>" + condition.libelle_metrique + "</span> <span class='comparaison_condition'>" + condition.libelle_comparaison + "</span> <span class='valeur_condition'>" + condition.valeur_seuil + "</span>";
							ligne_condition.append($(texte));
							ulConditions.append(ligne_condition);
						});
					}
				});
				liTitre.append(nomTitre);
				liTitre.append(lblConditions);
				liTitre.append(ulConditions);
				liTitre.append(divConditions);
				liTitre.append(btnModifier);
				liTitre.append(btnSupprimer);
				
				btnModifier.click(function(){
				        modifierTitre(titre);
				});
				btnSupprimer.click(function(){
				        supprTitre(titre);
				});				

				ul.append(liTitre);
			});
		}
	});
	
}

function checkObtentionTitre(){
    $.ajax({
         url:"controller/titre/checkTitre.php",
         data: {id_facebook : idfacebook},
         type: 'post',
         success: function(data){
                $.each(JSON.parse(data), function(i, titre){
                        console.log(titre);
                        ohSnap("Bravo! Vous avez obtenu le titre \"" + titre + "\" :) ");
                });
         }
    });


}
function modifierTitre(titre)
{
     DisplayModifierTitre(titre);
}

function supprTitre(titre)
{
		$.post("controller/titre/supprTitre.php", {id : titre.id_titre}, function(){
			ohSnap("Titre \"" + titre.libelle_titre +"\" supprimé!");
			$('#contenu').empty();
			DisplayConsulterTitre();
		});
}
function DisplayModifierTitre(monTitre)	//Formulaire pour ajouter un titre
{
	$('#contenu').empty();
		 //Ajout d'un bouton retour dans le titre
    var backButton = $('<img src="icon/backButton.png" class="backButton"></img>');
    $('#contenu').append(backButton);

    //Gestion du clic du bouton retour
    backButton.click(function(){
      //On vide le contenu et on affiche l'interface de gestion
      $('#contenu').empty();
      displayInterfaceGestionContainer();

    });
    var div_titre_main = $('<div '+themeColor2+'  id="div_titre"></div>');
    var titre = $('<h1 '+themeColor2+' class="titre_main">MODIFIER UN TITRE</h1>');
    div_titre_main.append(titre);
    $("#contenu").append(div_titre_main);

    var divNewTitre = $("<div class='divNewTitre'></div>");
    $("#contenu").append(divNewTitre);

    //var divTitreTitre = $("<span class='titre_titre'><label> Titre du nouveau titre : </label><input type='text'/></span></br>");
	var sautLigne;
	sautLigne = document.createElement("br");
    var divLibelleTitre = $("<span class='libelle_titre'><label> Nom du titre </label></span>");
    var inputTitre = $("<input id='inputTitre' class='validate[required,custom[onlyLetter],length[0,100]] feedback-input' type='text' value='"+ monTitre.libelle_titre +"'/>");
	var divConditions = $("<div class='divConditions' />");
	var libCondition = $("<span class='libelle_titre'><label> Condition d'obtention </label></span>");
	//divConditions.append(libCondition);
	var btn_gestionTitre = $("<button class='btn_gestionTitre'> Sauvegarder </button>");
	var divTitre = $(".divNewTitre");
    divTitre.append(divLibelleTitre);
    divTitre.append(inputTitre);
	sautLigne = document.createElement("br");
	divTitre.append(sautLigne);
	divTitre.append(libCondition);
	divTitre.append(divConditions);
    divTitre.append(btn_gestionTitre);
	
	indexCondition = 0;
	var btn_ajouterCondition = $("<button id='btn_ajouterCondition'> Ajouter une condition </button>");
	divConditions.append(btn_ajouterCondition);
	$.ajax({url: "controller/titre/allConditionsByTitre.php",
			data : {id_titre : monTitre.id_titre},
			type : 'post',
			success : function(data){
				$.each(JSON.parse(data), function(i, condition){
					displayACondition(indexCondition, condition.id_metrique, condition.id_comparaison, condition.valeur_seuil);		
					indexCondition++;												//Fonction displayACondition() dans le interfaceGestion.js
				});
			}
	});
	
	btn_ajouterCondition.click(function(){displayACondition(indexCondition++);});
	
    btn_gestionTitre.click(function() {
		var valide = (inputTitre.val() != "");
		for(var i = 0; i < indexCondition; i++)
		{
			if($("#value"+i)[0].style.display != 'none' && $("#value"+i)[0].value == "")
				valide = false;
		}
		
		if(valide){
			console.log(inputTitre.val());
			ModifierUnTitre(monTitre.id_titre, inputTitre.val());
		}
	});
}

function ModifierUnTitre(id, monTitre)
{
	console.log(monTitre);
	var lastID = 0;
          $.ajax({
				type:'post',
				url:"controller/titre/modifyTitre.php", 
				data:{ "id_titre" : id,
					"libelle_titre":monTitre
				},	
				success:function(data) {
					lastID = JSON.parse(data);
					console.log("data : "+lastID);
			  
				for(var i = 0; i < indexCondition; i++)
				{
					if($("#value"+i)[0].style.display != 'none' && $("#value"+i)[0].value != "")
					{
						var met = $("#metrique"+i)[0].value;
						var com = $("#compare"+i)[0].value;
						var val = $("#value"+i)[0].value;
						console.log(id + " " + met + " " + com + " " + val);
						$.ajax({
							url:"controller/titre/newConditionTitre.php", 
							type:'post',
							data:{
								"id_titre":id,
								"id_metrique":met,
								"id_comparaison":com,
								"value":val}, 
							success:	function(data, stat) {
								console.log("data 2 : "+data+ " " + stat);
							}
						});
					}
				}
			  
				$("#contenu").empty();
				displayInterfaceGestion();
			}
		});
}