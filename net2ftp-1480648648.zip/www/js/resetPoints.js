function resetPoints() {
	$.post("controller/points/resetPoints.php", { }, function() {
			
			console.log('resetPoints.js');
			
		
	}, "json");
	
}