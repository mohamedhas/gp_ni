



function isAdministrateur(fonction) {
	//console.log(idfacebook);
	$.post("controller/verif/verifAdmin.php", { idfacebook : idfacebook }, function(internautes) {
		

			if(internautes.length > 0){
				fonction(true);	
		 	}else{
				$('#btnInterfaceGestion').remove(0);
		 		//$('#nav-reponses_abusives').remove();
		 	}
	}, "json");
}
function isModerateur(fonction) {
	//console.log(idfacebook);
	$.post("controller/verif/verifModo.php", { idfacebook : idfacebook }, function(internautes) {
		
		$.each(internautes, function(i, internaute) {

			if(internaute.est_admin == false){
				
		 	}else{
				fonction(true);
		 	}

		});

	}, "json");
}