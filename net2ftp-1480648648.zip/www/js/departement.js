
function displayAllDepartement() {
	//$("#contenu").empty();
	// $("#classement").append(titreClassement);

	 var RightMenu = false;


	$.post("controller/allDepartement.php", { }, function(Departements) {
		var div = $("<ul id='divListeDepartement'/>");
		var ul = $("<ul id='listeDepartement'/>");
		$("#contenu").append(div);
		$("#divListeDepartement").append(ul);
		$.each(Departements, function(i, departement) {
			var li = $("<li "+themeColor1+"/>");
			li.data("departement",departement);
			li.addClass("departement");
			li.append("<span  "+themeColor1+" class='nom'>"+departement.libelle_dept+"</span>");
			li.attr("id","deptId"+departement.id_dept);
			li.attr("name",departement.libelle_dept);
			li.attr("dept_id", departement.id_dept);
			$('#deptId1').addClass('selected');
			ul.append(li);
			

		});
		$('.departement').click(function(){

			displayCategorieContainer($(this).data("departement").id_dept, $(this).data("departement").libelle_dept, RightMenu);
			$('.departement').removeClass('selected');
			$(this).addClass('selected');
		});
		displayCategorieContainer(1, "GEA", RightMenu);
	}, "json");

	

}


function displayCategorieContainer(iddept, nomdept, verifRightMenu) {
	if(verifRightMenu == false){
		$("nav li").removeClass("active");
		$(this).addClass("active");
		$("#contenucategorie").remove();
			var div_titre_main = $('<div '+themeColor2+' id="div_titre"></div>');
		var titre = $('<h1 '+themeColor2+' class="titre_main">CATEGORIES</h1>');
		div_titre_main.append(titre);
		$("#contenu").append(div_titre_main);
		displayCategoriesByDepartement(iddept, nomdept, verifRightMenu);
	}else{

		displayCategoriesByDepartement(iddept, nomdept, verifRightMenu);
	}
}

//---------------------------------------------------------------------------
//                               RIGHT MENU
//---------------------------------------------------------------------------

function displayAllDepartementRightMenu() {

	var RightMenu = true;


	//$("#contenu").empty();
	$("#classement").empty();
		var div_titre_main = $('<div '+themeColor2+' id="div_titre"></div>');
		var titre = $('<h1 '+themeColor2+' class="titre_class">DEPARTEMENTS</h1>');
		div_titre_main.append(titre);
		$("#classement").append(div_titre_main);
	$.post("controller/allDepartement.php", { }, function(Departements) {
		var div = $("<div class='divContenuRightMenu'/>");
		var ul = $("<ul class='ulDepartement'/>");
		div.append(ul);
		$("#classement").append(div);
		$.each(Departements, function(i, departement) {
			var li = $("<li "+themeColor1+"/>");
			li.data("departement",departement);
			li.addClass("departementRightMenu");
			li.append("<span class='nom'> + "+departement.libelle_dept+"</span>");
			li.attr("id",departement.id_dept);
			li.attr("name",departement.libelle_dept);
			li.attr("dept_id", departement.id_dept);
			ul.append(li);
			

		});
		$('.departementRightMenu').click(function(){
			if(($(this).hasClass('selected'))){
				$('#deptNum'+$(this).data("departement").id_dept+'').remove();
				$(this).html(' + '+$(this).data("departement").libelle_dept);

				$(this).removeClass('selected');

			}else{
				displayCategorieContainer($(this).data("departement").id_dept, $(this).data("departement").libelle_dept, RightMenu);
				$(this).html(' - '+$(this).data("departement").libelle_dept);
				
				$(this).addClass('selected');
			}
		});

	}, "json");

}


function DisplayAjoutDepartement(){
	$.post("controller/departement/formulaireAjoutDepartement.php", {}, function(html){
		$("#contenu").html(html);
		
		 //Ajout d'un bouton retour dans le titre
		var backButton = $('.backButton');
		backButton.click(function(){
		  //On vide le contenu et on affiche l'interface de gestion
		  $('#contenu').empty();
		  displayInterfaceGestionContainer();
		  
		});
		
		$(function() {
			var name = $('#nom_departement').val();
			var couleur = $('#color_departement').val();

			$('#nom_departement').keyup(function() { 
				if ($('#nom_departement').val() != name) {
					name = $('#nom_departement').val();
					$('#preview_departement').empty();
					$('#preview_departement').append($('<p style="color:'+couleur+'" class="dept_libelle">'+name+'</p>'));
				}
			});
			$('#color_departement').change(function() { 
				couleur = $(this).val();
				$('#preview_departement').empty();
				$('#preview_departement').append($('<p style="color:'+couleur+'" class="dept_libelle">'+name+'</p>'));
				
			});
		});
		
		$('.btn_gestionDepartement').click(function(){
			var nom = $('#nom_departement').val();
			var couleur = $('#color_departement').val();
			var categories = [];
			var checkboxes = $('.checkCat');
			$.each(checkboxes, function(i, check){
				if(check.checked){
					categories[categories.length] = check.id;
				}
			});
			AjouterDepartement(nom, categories, couleur);
			//On vide et on affiche l'interface de gestion
			$('#contenu').empty();
			displayInterfaceGestionContainer();
		});
	
	});
}

function AjouterDepartement(nom, categories, couleur){
	$.post("controller/departement/newDepartement.php", {nom : nom, listeCategories : categories, couleur : couleur}, function(){});
}
function DisplayConsulterDepartement()
{
	$.post("controller/departement/afficherAllDepartements.php", {}, function(html){
		$("#contenu").html(html);
		
		 //Ajout d'un bouton retour dans le titre
		var backButton = $('.backButton');
		backButton.click(function(){
		  //On vide le contenu et on affiche l'interface de gestion
		  $('#contenu').empty();
		  displayInterfaceGestionContainer();

		});
		
		$('.modifier').click(function(){
			var id = $(this).data('id');
			DisplayModifierDepartement(id);
		});
	
	});
}

function DisplayModifierDepartement(id){
	$.post("controller/departement/formulaireModifierDepartement.php", {id : id}, function(html){
		$("#contenu").html(html);
		
		 //Ajout d'un bouton retour dans le titre
		var backButton = $('.backButton');
		backButton.click(function(){
		  //On vide le contenu et on affiche l'interface de gestion
		  $('#contenu').empty();
		  displayInterfaceGestionContainer();

		});
		
		$('.btn_gestionDepartement').click(function(){
			var nom = $('#nom_departement').val();
			var couleur = $('#color_departement').val();
			var categories = [];
			var checkboxes = $('.checkCat');
			$.each(checkboxes, function(i, check){
				if(check.checked){
					categories[categories.length] = check.id;
				}
			});
			ModifierDepartement(id, nom, couleur, categories);
			
			DisplayConsulterDepartement();
		});
	
	});
}
function ModifierDepartement(id, nom, couleur, categories){
	$.post("controller/departement/modifyDepartement.php", {id : id, nom : nom, couleur : couleur, listeCategories : categories}, function(){});
}




