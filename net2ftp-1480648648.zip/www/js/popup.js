function popup()
{
	
	var box = $("<div id='welcomeBox' />");
	
	/*var strtexte = $("<p class='welcomeText' />");
	strtexte.append(texte);*/
	
	$("body").append($('<div id="grayBack" />'));
	$("#grayBack").css('opacity', 0).fadeTo(300, 0.5, function () { box.fadeIn(500); });
	$("body").append(box);
	//box.append(strtexte);
	
	return box;
}

function closePopup(box)
{
	var bg = $('#grayBack');
	$("#grayBack").css('opacity', 0.5).fadeTo(300, 0, function () { box.fadeOut(500); });
	bg.remove();
	box.remove();
}
function smallPopup(texte)
{
	
	var box = $("<div class='smallPopup' />");
	var img = $("<img src='icon/imgtest.png'");
	var strtexte = $("<p class='PopupText' />");
	strtexte.append(texte);
	
	/*$("body").append($('<div id="grayBack" />'));
	$("#grayBack").css('opacity', 0).fadeTo(300, 0.5, function () { box.fadeIn(500); });*/
	$("body").append(box);
	box.append(img);
	box.append(strtexte);
	
	return box;
}
