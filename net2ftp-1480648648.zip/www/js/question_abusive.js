function displayAllQuestionsAbusives() {



	$("#contenu").empty();
		var div_titre_main = $('<div '+themeColor2+' id="div_titre"></div>');
		var titre = $('<h1 '+themeColor2+'  class="titre_main">QUESTIONS ABUSIVES</h1>');
		div_titre_main.append(titre);
		$("#contenu").append(div_titre_main);
	$.post("controller/question/allQuestionsAbusives.php", { }, function(questions) {
		var ul = $("<ul/>")
		ul.addClass("listeQuestionsAbusives");
		$('#contenu').append(ul);


		 //Ajout d'un bouton retour dans le titre
    var backButton = $('<img src="icon/backButton.png" class="backButton"></img>');
    $('#contenu').append(backButton);

    //Gestion du clic du bouton retour
    backButton.click(function(){
      //On vide le contenu et on affiche l'interface de gestion
      $('#contenu').empty();
      displayInterfaceGestionContainer();

    });

		$.each(questions, function(i, question) {
			
			var li = $("<li/>");
			li.data("question",question);
			li.addClass("questionAbusive");

			var profil_question = $('<div/>');
			profil_question.addClass('profil_question');
			profil_question.append("<img src='https://graph.facebook.com/" + question.id_facebook + "/picture?type=large' style='width:50px; height:50px;' class='image_reponse'></br>");
			profil_question.append(question.prenom + " " + question.nom);
			li.append(profil_question);
			var contenu_question = $('<div/>');
			contenu_question.addClass('contenu_question');
			contenu_question.append("<span class='titre'>"+question.titre+"</span></br>");
			contenu_question.append("<div class='valeurQuestionAbusive'>"+question.texte+"</div></br>");
			contenu_question.append("<span class='date'>"+ question.date_post +"</span>");

			li.append(contenu_question);

			/*var li = $("<li/>");
			li.data("question",question);
			li.addClass("questionAbusive");
			li.append("<img src='"+question.photo_internaute+"' style='width:50px; height:50px;' />");
			li.append("<span class='prenomInternaute'>"+question.prenom_internaute+"</span> ");
			li.append("<span class='nomInternaute'>"+question.nom_internaute+"</span></br>");
			li.append("<span class='levelInternaute'> level : "+question.niveau_internaute+"</span></br>");
			li.append("<span class='titre'>"+question.titre_question+"</span>");
			li.append("<span class='valeurQuestion'>"+question.valeur_question+"</span></br>");
			li.append("<span class='date'>"+question.dates+"</span>");*/
			ul.append(li);

			var id = question.id_question;

			var div_btn = $('<div class=Btns_Question_Abusive/>');
			var btn_retablir = $("<button class='btn_retablir' value='"+id+"'>Rétablir</button>");
			div_btn.append(btn_retablir);

			var btn_delete = $("<button class='btn_delete' value='"+id+"'>Supprimer</button>");
			div_btn.append(btn_delete);

			var btn_edit = $("<button class='btn_edit' id='btn_edit_"+id+"' value='"+question.id_question+"'>Editer</button>");
			div_btn.append(btn_edit);

			li.append(div_btn);

			$("#btn_edit_"+id+"").click(function() {

				formEditQuestion(id, question.texte);
				
			});
			
		});

		$(".btn_retablir").click(function() {
			retablirQuestionAbusive($(this).val());
		});

		$(".btn_delete").click(function() {

			deleteQuestionAbusive($(this).val());
		});

		


	}, "json");

}



function retablirQuestionAbusive(id_question){

	$("#contenu").empty();
	$.post("controller/question/retablirQuestionAbusive.php", { "id_question":id_question}, function(questions) {


	}, "json");

	displayAllQuestionsAbusives();

	
}


function deleteQuestionAbusive(id_question){

	$("#contenu").empty();
	$.post("controller/question/deleteQuestionAbusive.php", { "id_question":id_question}, function(questions) {


	}, "json");

	displayAllQuestionsAbusives();
	
}


function formEditQuestion(id_question, valeur_question){

	$("#btn_edit_"+id_question+"")
						.after("<input type='submit' id='submit_valide_"+id_question+"'/>")
						.after("<textarea class='area' name='valeur_question' shape='rect'>"+valeur_question+"</textarea>");

	$("#submit_valide_"+id_question+"").click(function(){
		editQuestionAbusive(id_question,$(".area").val());
	});
}


function editQuestionAbusive(id_question,valeur_question){

	$.post("controller/question/editQuestionAbusive.php", { "id_question":id_question, "valeur_question":valeur_question}, function(questions) {


	}, "json");

	retablirQuestionAbusive(id_question);
	displayAllQuestionsAbusives();


}




