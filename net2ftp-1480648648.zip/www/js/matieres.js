function displayMatieresByMatiere(idcateg, nomcateg, verifRightMenu) {

	//V2RIFIE SI ON A CLIQUE SUR UNE CATEGORIE SE TROUVANT LE CONTENU OU DANS L'ARBORESCENCE DE DROITE
	if(verifRightMenu == false) {
		$.post("controller/matiere/matieresByMatiere.php", { "id_matiere":idcateg }, function(matieres) {
			var ul = $("<ul/>");
			$("#idcateg"+idcateg+"").append(ul);
			$.each(matieres, function(i, matiere) {

				var li = $("<li/>");
				li.data("matiere",matiere);
				li.addClass("matiere");
				li.append("<span class='nom'>"+matiere.libelle_matiere+"</span>");
				li.attr("id",matiere.id_matiere);
				li.attr("name",matiere.libelle_matiere);
				ul.append(li);
			});

			$('.matiere').click(function(){
				// console.log($(this).data("matiere").id_matiere);
				// console.log($(this).data("matiere").libelle_matiere);
				displayQuestionsByMatiereContainer($(this).data("matiere").id_matiere,$(this).data("matiere").libelle_matiere);
				displayAllDepartementRightMenu();
			});

		}, "json");
	}else{
		$.post("controller/matiere/matieresByMatiere.php", { "id_matiere":idcateg }, function(matieres) {
			var ul = $("<ul id='categNum"+idcateg+"'/>");
			$("#idcateg"+idcateg+"").after(ul);
			$.each(matieres, function(i, matiere) {

				var li = $("<li "+themeColor2+"/>");
				li.data("matiere",matiere);
				li.addClass("LimatiereRightMenu");
				li.append("<span "+themeColor2+" class='nom'>"+matiere.libelle_matiere+"</span>");
				li.attr("id",matiere.id_matiere);
				li.attr("name",matiere.libelle_matiere);
				ul.append(li);
			});

			$('.LimatiereRightMenu').click(function(){
				displayQuestionsByMatiereContainer($(this).data("matiere").id_matiere,$(this).data("matiere").libelle_matiere);
				$('.LimatiereRightMenu').removeClass('selected');
				$(this).addClass("selected");
			});

		}, "json");
	}
}




function displayQuestionsByMatiereContainer(idmatiere, libellematiere) {
	$("nav li").removeClass("active");
	$(this).addClass("active");
	$("#contenu").empty();
	displayQuestionsByMatiere(idmatiere,libellematiere);


}


function DisplayAjoutMatiere(){
	$.post("controller/matiere/formulaireAjoutMatiere.php", {}, function(html){
		$("#contenu").html(html);
		
		 //Ajout d'un bouton retour dans le titre
		var backButton = $('.backButton');
		backButton.click(function(){
		  //On vide le contenu et on affiche l'interface de gestion
		  $('#contenu').empty();
		  displayInterfaceGestionContainer();

		});
		
		$('.btn_gestionMatiere').click(function(){
			var nom = $('#nom_matiere').val();
			var matiere = $('#nom_matiere').val();
			var depts = [];
			var checkboxes = $('.checkDept');
			$.each(checkboxes, function(i, check){
				if(check.checked){
					depts[depts.length] = check.dataset.id;
				}
			});
			AjouterMatiere(nom, depts, matiere);
			//On vide et on affiche l'interface de gestion
			$('#contenu').empty();
			displayInterfaceGestionContainer();
		});
	
	});
}

function AjouterMatiere(nom, departements, matiere){
	$.post("controller/matiere/newMatiere.php", {nom : nom, depts : departements, matiere : matiere}, function(){});
}
function DisplayConsulterMatiere()
{
	$.post("controller/matiere/afficherAllMatieres.php", {}, function(html){
		$("#contenu").html(html);
		
		 //Ajout d'un bouton retour dans le titre
		var backButton = $('.backButton');
		backButton.click(function(){
		  //On vide le contenu et on affiche l'interface de gestion
		  $('#contenu').empty();
		  displayInterfaceGestionContainer();

		});
		
		$('.modifier').click(function(){
			var id = $(this).data('id');
			DisplayModifierMatiere(id);
		});
	
	});
}

function DisplayModifierMatiere(id){
	$.post("controller/matiere/formulaireModifierMatiere.php", {id : id}, function(html){
		$("#contenu").html(html);
		
		 //Ajout d'un bouton retour dans le titre
		var backButton = $('.backButton');
		backButton.click(function(){
		  //On vide le contenu et on affiche l'interface de gestion
		  $('#contenu').empty();
		  displayInterfaceGestionContainer();

		});
		
		$('.btn_gestionMatiere').click(function(){
			/*var nom = $('#nom_matiere').val();
			var matiere = $('#nom_matiere').val();
			var depts = [];
			var checkboxes = $('.checkDept');
			$.each(checkboxes, function(i, check){
				if(check.checked){
					depts[depts.length] = check.dataset.id;
				}
			});
			ModifierMatiere(nom, depts, matiere);
			//On vide et on affiche l'interface de gestion
			$('#contenu').empty();
			displayInterfaceGestionContainer();*/
		});
	
	});
}