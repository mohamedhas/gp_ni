function formRecherche(){


	var div = $("<div id='barre_recherche'/>");
	$('header').append(div);
	var search = $("<input id='input_search' type='search' placeholder='Rechercher'></input>");
	div.prepend(search);
    var btn = $("<button id='btn_search' type='button'</button>")
    div.append(btn );
	moveSearch(1, true);

	$('#input_search').keyup(function(event){
		if(event.which == 13){

			lastSearch(search.val());
		}

	});
	$('#btn_search').click(function(){

		DisplayRecherche(search.val());


	});







 
}

function DisplayRecherche(texte){
	var barre = $('#barre_recherche')[0];
	if(barre.offsetLeft < 0){
		moveSearch(200000, false);
	}
	else{
		moveSearch(200000, true);
	}
}
function moveSearch(time, hide){
	var div = $('#barre_recherche')[0];
	var barre = $('#input_search')[0];
	var freq = barre.clientWidth/(time);
	var offset = 0;
	var move = setInterval(function(){
		if(hide){
			offset = div.offsetLeft - barre.clientWidth*freq
		}
		else{
			offset = div.offsetLeft + barre.clientWidth*freq
		}
		div.style.left = offset + 'px';
		if(div.offsetLeft + barre.clientWidth  <= 0 && hide){
			div.style.left = -barre.clientWidth + 'px';
			clearInterval(move);
		}
		if(div.offsetLeft >= 0 && !hide){
			div.style.left= '5%';
			clearInterval(move);
		}
	}, freq);
}


function lastSearch(value) {
	provenance = 'search';
	$.post(
		"controller/recherche/recherche.php",
		{
			'valeur':value,
			'page' : 1
		},/*
		function(valeurs){
			if(valeurs.length != 0){
						$('#contenu').empty();
				var div_titre_main = $('<div '+themeColor2+' id="div_titre"></div>');
				var titre = $('<h1 '+themeColor2+' class="titre_main">RESULTATS DE LA RECHERCHE : '+value+'</h1>');
				div_titre_main.append(titre);
				$("#contenu").append(div_titre_main);
			var ul = $("<ul class='scroll_recherche'/>");
			$('#contenu').append(ul);
				$.each(valeurs, function(i, valeur){

					var li = $('<li/>');
				li.addClass("myquestion");
				li.data("valeur", valeur);

				var profil_question = $('<div/>');
				profil_question.addClass('profil_question');
				profil_question.append("<img src='https://graph.facebook.com/"+valeur.id_facebook+"/picture?type=large'  class='imageQuestion'/>")
				profil_question.append(valeur.nom);
				li.append(profil_question);
				var contenu_question = $('<div/>');
				contenu_question.addClass('contenu_question');
				contenu_question.append("<span "+themeColor1+" class='titre'>"+valeur.titre+"</span></br>");
				contenu_question.append("<span class='date'>"+valeur.date_post+"</span>");
				li.append(contenu_question);


					ul.append(li);
				});
				$(".myquestion").click(function() {
					questionReponse($(this).data("valeur").id_question);
						lastSearch(search.val());
				});

			}else{
				$('#contenu').empty();
				var div_titre_main = $('<div id="div_titre"></div>');
				var titre = $('<h1 class="titre_main">PAS DE RESULTATS</h1>');
				div_titre_main.append(titre);
				$("#contenu").append(div_titre_main);

			}
			badgeLoupe(idfacebook);
*/
		function(html){
			$('#contenu').html(html);
			var backButton = $('<img src="icon/backButton.png" class="backButton"></img>');
			$('#contenu').append(backButton);

			//Gestion du clic du bouton retour
			backButton.click(function(){
				//On vide le contenu et on affiche l'interface de gestion
				$('#contenu').empty();
				if(provenance == 'search'){
					lastSearch(search.val());
				}

			});
			
				$(".myprofil").click(function() {
					loadProfile($(this).data("profil"));
				});
				$(".myquestion").click(function() {
					questionReponse($(this).data("question"));
				});


	}).fail(function(a,b,c){
		console.log(a,b,c);

	});
}

					