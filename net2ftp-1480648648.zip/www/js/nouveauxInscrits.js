function displayAllNouveauxInscrits()
{
	$("#contenu").empty();
		var div_titre_main = $('<div '+themeColor2+' id="div_titre"></div>');
		var titre = $('<h1 '+themeColor2+'  class="titre_main">NOUVEAUX INSCRITS</h1>');
		div_titre_main.append(titre);
		$("#contenu").append(div_titre_main);
	$.post("controller/nouveaux/allNouveaux.php", { }, function(nouveaux) {
		var ul = $("<ul/>")
		ul.addClass("listeQuestionsAbusives");
		$('#contenu').append(ul);


		 //Ajout d'un bouton retour dans le titre
    var backButton = $('<img src="icon/backButton.png" class="backButton"></img>');
    $('#contenu').append(backButton);

    //Gestion du clic du bouton retour
    backButton.click(function(){
      //On vide le contenu et on affiche l'interface de gestion
      $('#contenu').empty();
      displayInterfaceGestionContainer();

    });

		$.each(nouveaux, function(i, nouveau) {
			
			var li = $("<li/>");
			li.data("nouveau",nouveau);
			li.addClass("questionAbusive");

			var profil_question = $('<div/>');
			profil_question.addClass('profil_question');
			profil_question.append("<img src='https://graph.facebook.com/" + nouveau.id_facebook + "/picture?type=large' style='width:50px; height:50px;' class='image_reponse'></br>");
			profil_question.append(nouveau.libelle_dept);
			profil_question.append(nouveau.prenom + " " + nouveau.nom);
			li.append(profil_question);
			
			ul.append(li);

			var id = nouveau.id_facebook;

			var div_btn = $('<div class="boutons_nouveaux"/>');
			var btn_refuser = $("<button class='btn_refuser' value='"+id+"'>Refuser</button>");
			div_btn.append(btn_refuser);

			var btn_accepter = $("<button class='btn_accepter' value='"+id+"'>Accepter</button>");
			div_btn.append(btn_accepter);


			li.append(div_btn);
			
		});

		$(".btn_accepter").click(function() {
			accepterNouveau($(this).val());
		});

		$(".btn_refuser").click(function() {

			refuserNouveau($(this).val());
		});

		


	}, "json");

}

function accepterNouveau(id, redirection)
{
	if(typeof redirection == 'undefined')
		redirection = true;
	//$("#contenu").empty();
	$.post("controller/nouveaux/accepterNouveau.php", { "id":id}, function(nouveau) {


	}, "json");
	if(redirection)
		displayAllNouveauxInscrits();
}
function refuserNouveau(id, redirection)
{
	if(typeof redirection == 'undefined')
		redirection = true;
	//$("#contenu").empty();
	$.post("controller/nouveaux/refuserNouveau.php", { "id":id}, function(nouveau) {


	}, "json");
	
	if(redirection)
		displayAllNouveauxInscrits();
}


function displayWelcomeNouveau(nom, prenom, erreur)
{
        if(erreur == 'undefined') erreur = false;
	var box = popup();
	
	var texte = $("<p class='welcomeText'/>");
    if(erreur){texte.append("Le pseudo est deja pris</br>");}
	else{texte.append("Bonjour " + prenom + ",<br/>Ton chef de departement doit t'accepter pour que tu continue à utiliser OPORA!<br/>Merci de renseigner ton pseudo et ton département :");}
	var input = $("<input type='text' id='inputPseudo' name='pseudo' placeholder='Pseudo'/>");
	var selectDept = $("<select id='selectDept' />");
	$.ajax({
		url:"./controller/departement/allDepartement.php",
		type:'get',
		success:function(depts){
			depts = JSON.parse(depts);
			$.each(depts, function(i, dept){
				var options = $("<option />");
				options.append(dept.libelle_dept);
				options.attr('id', dept.id_dept);
				selectDept.append(options);
			});
		}
	});
	
	var ok = $("<button id='btn_welcome'>S'inscrire!</button>");
	box.append(texte);
        box.append(input);
	box.append(selectDept);
	box.append(ok);
	
	
	ok.click(function(){
		var dept = selectDept[0].options[selectDept[0].selectedIndex].id;
                var pseudo = input.val();
		console.log(nom + "   " + prenom + " ("+ pseudo +") " + dept);
		closePopup(box);
		var retour;
		insertNewProfile(nom, prenom, pseudo, dept, function(val){retour = val;});
		
		if(retour == true)
		{
			displayInfosProfile();
			displayWaitingNouveau();
		}
		else
		{
			displayWelcomeNouveau(nom, prenom, true); //Il y a une erreur
		}
	});
}


function displayWaitingNouveau()
{
	var box = popup();
	
	var texte = $("<p class='welcomeText'/>");
	texte.append("Salut à toi!<br/>Tu vas bientôt pouvoir goûter à l'entraide présente dans OPORA, mais il faut attendre que ton chef de département accepte ton inscription...<br/>Par contre, tu peux venir voir ce qu'il se passe ici!");
	
	var ok = $("<button id='btn_welcome'>Jeter un coup d'oeil!</button>");
	box.append(texte);
	box.append(ok);
	
	
	
	ok.click(function(){
		closePopup(box);
		startingTuto();
	});
}